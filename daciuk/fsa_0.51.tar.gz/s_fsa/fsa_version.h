/***	fsa_version.h	***/

const char *VERSION =
	"Ver. 0.51, January 21th, 2011, (c) Jan Daciuk, jandac@eti.pg.gda.pl";

/***	EOF fsa_version.h	***/
