/*	adfa.hh		*/

/*	Copyright (C) Jan Daciuk, 2001, 2002	*/

#include	<vector>

using namespace std;

class state;

typedef char mychar;


class transition {
  mychar	label;
  state		*target;
#ifdef HASH
  int		weight;
#endif
public:
  transition(const mychar l, state *t
#ifdef HASH
	     , const int w = 0	// weight
#endif
	     ) : label(l), target(t)
#ifdef HASH
    , weight(w)
#endif
  {}
  mychar get_label(void) const { return label; }
  state *get_target(void) const { return target; }
#ifdef HASH
  int get_weight(void) const { return weight; }
  void set_weight(const int w) { weight = w; }
  int add_weight(const int w) { return weight += w; }
#endif
  void set_target(state *t) { target = t; }
  bool operator==(const transition &t) const {
    return label == t.label && target == t.target;
  }
  bool operator!=(const transition &t) const {
    return label != t.label || target != t.target;
  }
  bool operator<(const transition &t) const {
    return (label == t.label ? target < t.target : label < t.label);
  }
};

typedef vector<transition>	trans_vec;
class state {
protected:
  trans_vec	out_trans;		// outgoing transitions
  int			in_count;	// number of incoming transitions
  bool			final;		// accepting state
  int			state_no;	// state number
  int			height;		// for Revuz only
  static int		total_states; 	// number of states in the automaton
#ifdef STATS
  static int		max_states;	// max states during construction
#endif
#ifdef HASH
  trans_vec::iterator	last_trans;	// last transition traversed by next()
#endif
public:

  // Create new state with no transitions
  state(void) : in_count(0), final(false), height(-1)  {
    total_states++; state_no = -1;
#ifdef STATS
    if (total_states > max_states)
      max_states = total_states;
#endif
  }

  // Clone a state
  state(state &s) : out_trans(s.out_trans), in_count(0),
		    final(s.final), height(-1) {
    for (trans_vec::iterator t = out_trans.begin();
	 t != out_trans.end(); t++) {
      t->get_target()->hit();
    }
    total_states++;
#ifdef STATS
    if (total_states > max_states)
      max_states = total_states;
#endif
    state_no = -1;
  }

  // Delete a state
  ~state(void) {
    for (trans_vec::iterator t = out_trans.begin();
	 t != out_trans.end(); t++) {
      if (t->get_target()->hit(-1) == 0) {
	delete t->get_target();
      }
    }
    --total_states;
  }

  // True if the state is final
  bool is_final(void) const { return final; }

  // Make the state final
  void set_final(void) { final = true; }

  // Get number of outgoing transitions
  int fan_out(void) const { return out_trans.size(); }

  // Get number of incoming transitions
  int fan_in(void) const { return in_count; }

  // Get outgoing transitions
  trans_vec &get_transitions(void) { return out_trans; }

  // Get outgoing transitions for a constant state
  const trans_vec &get_transitions(void) const { return out_trans; }

  // Increase the counter of ingoing transitions (by 1 by default)
  int hit(const int i = 1) { return (in_count += i); }

  // Set state number (e.g. for Hopcroft minimization)
  void set_number(const int n) { state_no = n; }

  // Get state number
  int get_number(void) const { return state_no; }

  // Set state height (the length of the longest word in its right language)
  // This is needed by Revuz's algorithm
  void set_height(const int n) { height = n; }

  // Get state height (the length of the longest word in its right language)
  // This is needed by Revuz's algorithm
  int get_height(void) const { return height; }

  // Traverse a transition
  state *next(mychar label) {
    for (trans_vec::iterator p = out_trans.begin();
	 p != out_trans.end(); p++) {
      if (p->get_label() == label) {
#ifdef HASH
	last_trans = p;
#endif
	return p->get_target();
      }
    }
#ifdef HASH
    last_trans = out_trans.end();
#endif
    return NULL;
  }

  // Find transition with the given label
  transition *find_trans(mychar label) {
    for (trans_vec::iterator p = out_trans.begin();
	 p != out_trans.end(); p++) {
      if (p->get_label() == label) {
	return &(*p);
      }
    }
    return NULL;
  }

  // Create a transition
  // Note: target MUST be different
  void set_next(const mychar label, state *target
#ifdef HASH
		, const int w = 0	// weight (-1 - don't change existing)
#endif
		) {
    trans_vec::iterator p;
    for (p = out_trans.begin();
	 p != out_trans.end() && p->get_label() < label; p++)
      ;
    if (p != out_trans.end() && p->get_label() == label) {
      bool del = false;
      state *s;
      if ((s = p->get_target())->hit(-1) == 0) {
	del = true;
      }
      p->set_target(target);
      if (del) {
	delete s;
      }
#ifdef HASH
      if (w >= 0) {
	p->set_weight(w);
      }
#endif
    }
    else {
      out_trans.insert(p, transition(label, target
#ifdef HASH
				     , w // weight
#endif
				     ));
    }
    target->hit();
  }


#ifdef HASH
  int last_weight(void) const {
    if (last_trans == out_trans.end()) {
      return -1;
    }
    else {
      return last_trans->get_weight();
    }
  }
#endif

#if defined(STATS) || defined(GRAPH)
#ifdef STATS
  int get_max_states(void) const { return max_states; }
#endif
  int get_total_states(void) const {return total_states; }
#endif
};//class state

class automaton {
  state		*initial_state;
public:
  state		*get_init(void) const { return initial_state; }
};

typedef pair<state *, int>	prefix_pair;

/*	EOF adfa.hh	*/
