/*	adfa.cc		*/

/* Copyright (C) Jan Daciuk, 2001, 2002 */

#include	<string>
#include	<iostream>
#include	<fstream>
#include	<algorithm>
#include	<map>
#include	"adfa.hh"
#include	"myhash.hh"

int state::total_states = 0;
#ifdef STATS
int state::max_states = 0;
#endif

typedef		basic_string<mychar>	mystr;

enum const_type {sorted, unsorted, watson, revuz, triehop, triepost, trielex,
                 dynahash, psevuz, pseudosorted, pseudowatson, pseudounsorted};

class hash_pointer {
public:
  state		*p;
  hash_pointer(state *s) : p(s) {}
  bool operator==(hash_pointer &s) { return key_eq(p, s.p); }
  bool operator <(const hash_pointer &s) const {
    if (p->is_final() == s.p->is_final()) {
      if (p->fan_out() == s.p->fan_out()) {
#ifdef HASH
	trans_vec &tp = p->get_transitions();
	trans_vec &ts = s.p->get_transitions();
	for (unsigned int i = 0; i < tp.size(); i++) {
	  if (tp[i] != ts[i]) {
	    return (tp[i] < ts[i]);
	  }
	  if (tp[i].get_weight() != ts[i].get_weight()) {
	    return (tp[i].get_weight() < ts[i].get_weight());
	  }
	}
	return false;
#else
	return (p->get_transitions() < s.p->get_transitions());
#endif
      }
      else {
	return p->fan_out() < s.p->fan_out();
      }
    }
    else {
      return p->is_final() < s.p->is_final();
    }
  }
  operator state *(void) { return p; }
};
  
struct stack_item {
  transition	*t;
  stack_item	*next;

  stack_item(transition *t1, stack_item *i) : t(t1), next(i) {}
};

/*	Globals		*/

// Later change to a pointer initialized in main()
hash_table<hash_pointer>	Register(10001, NULL);

/* Specializations of functions from templates */


/* Name:	hash
 * Class:	None (specialization of a template).
 * Purpose:	Computes hash function for a pointer to state.
 * Parameters:	p	- (i) wrapper around pointer to state.
 * Returns:	Hash function.
 * Globals:	None.
 * Remarks:	Specialization of a template.
 */
int
hash(const hash_pointer p)
{
  int sum = p.p->is_final();
  trans_vec::iterator t = p.p->get_transitions().begin();
  for (int i = 0; i < p.p->fan_out(); i++) {
    sum += (t->get_label()*7 + ((long(t->get_target())>>2)*101)) * (11 + 2*i);
  }
  return sum;
}//hash

bool
key_eq(/*const*/ state *p1, /*const*/ state *p2)
{
  if (p1->fan_out() != p2->fan_out() || p1->is_final() != p2->is_final()) {
    return false;
  }
#ifdef HASH
  trans_vec &t1 = p1->get_transitions();
  trans_vec &t2 = p2->get_transitions();
  for (unsigned int i = 0; i < t1.size(); i++) {
    if (t1[i] != t2[i]) {
      return false;
    }
    if (t1[i].get_weight() != t2[i].get_weight()) {
      return false;
    }
  }
  return true;
#else
  return equal(p1->get_transitions().begin(), p1->get_transitions().end(),
	       p2->get_transitions().begin());
#endif
}//key_eq

/* Internal prototypes */

state *sorted_construction(istream &input);
prefix_pair common_prefix(state *s, mystr input_line);
state *repl_or_reg(state *parent);
state *pseudo_repl_or_reg(state *s, bool *divergent);
state *add_suffix(state *origin, mystr &suffix);
state *unsorted_construction(istream &input);
state *pseudo_unsorted_construction(istream &input);
state *watson_construction(istream &input);
stack_item *build_stack(transition *ini_tr, stack_item *ini_stack);
transition *add_iter(mystr word, state *start);
transition *pseudo_add_iter(mystr word, state *start);
void remove_equiv(stack_item *q);
void pseudo_remove_equiv(stack_item *q);
state *build_trie(istream &input);
int number_states(state *s, const int n);
state **fill_state_vec(state *s, const int n);
void fill_state_cell(state **v, state *s);
state *minim_trie(istream &input);
state *hopcroft_minim(state **v, const int n);
state *trie_postorder(istream &input);
state *postorder_minim(state *start);
state *revuz_construction(istream &input);
state *trie_lex(istream &input);
state *dynamic_hash(istream &input);
void lex_sort(state **v, const int n, const int h);
state **sort_on_fanout(state **v, const int bstart, const int bsize,
		       const int max_fanout, const int num_states);
state **sort_on_label(state **v, const int bstart, const int bsize,
		      const int tr_no, const int num_states);
state **sort_on_target(state **v, const int bstart, const int bsize,
		       const int tr_no, const int num_states);
state **sort_on_final(state **v, const int bstart, const int bsize);
int find_height(state *s);
state *pseudo_revuz(istream &input);
void usage(void);
int apply_method(istream &input, const const_type construction,
		 const bool expand);
#ifdef DEBUG
void print_automaton(state *s, mystr &ss);
#endif
#ifdef STATS
int count_transitions(state *s, const int isum);
#endif
state *expand2pseudo(state *start, bool was_convergent);
int find_divergent(state *start);
void reset_height(state *start);

/* Functions */

/* Name:	sorted_construction
 * Class:	None.
 * Purpose:	Constructs the minimal, acyclic, finite-state automaton
 *		from a sorted collection of strings in a file.
 * Parameters:	input		- (i) input stream.
 * Returns:	The initial state of the automaton.
 * Globals:	None.
 * Remarks:	No duplicates allowed.
 */
state *
sorted_construction(istream &input)
{
  mystr	input_line;
  state		*start = new state;
#ifdef GRAPH
  int		wordno = 0;
  int		charno = 0;
#endif

  while (getline(input, input_line)) {
    prefix_pair end_pref = common_prefix(start, input_line);
    if (end_pref.first->fan_out()) {
      transition &lt = end_pref.first->get_transitions().back();
      lt.set_target(repl_or_reg(lt.get_target()));
    }
    mystr suffix(input_line, end_pref.second);
    add_suffix(end_pref.first, suffix);
#ifdef GRAPH
    charno += input_line.length();
    cout << "Word " << wordno++ << " chars " << charno
	 << " states " << start->get_total_states() << "\n";
#endif
  }
  repl_or_reg(start);
  return start;
}//sorted_construction

/* Name:	pseudo_sorted_construction
 * Class:	None.
 * Purpose:	Constructs the pseudo-minimal, acyclic, finite-state automaton
 *		from a sorted collection of strings in a file.
 * Parameters:	input		- (i) input stream.
 * Returns:	The initial state of the automaton.
 * Globals:	None.
 * Remarks:	No duplicates allowed.
 */
state *
pseudo_sorted_construction(istream &input)
{
  mystr	input_line;
  bool		divergent;
  state		*start = new state;
#ifdef GRAPH
  int		wordno = 0;
  int		charno = 0;
#endif

  while (getline(input, input_line)) {
    prefix_pair end_pref = common_prefix(start, input_line);
    if (end_pref.first->fan_out()) {
      transition &lt = end_pref.first->get_transitions().back();
      divergent = false;
      lt.set_target(pseudo_repl_or_reg(lt.get_target(), &divergent));
    }
    mystr suffix(input_line, end_pref.second);
    add_suffix(end_pref.first, suffix);
#ifdef GRAPH
    charno += input_line.length();
    cout << "Word " << wordno++ << " chars " << charno
	 << " states " << start->get_total_states() << "\n";
#endif
  }
  divergent = false;
  pseudo_repl_or_reg(start, &divergent);
  return start;
}//pseudo_sorted_construction

/* Name:	common_prefix
 * Class:	None.
 * Purpose:	Finds the longest common prefix of a string and all strings
 *		in the automaton.
 * Parameters:	s		- (i) initial state where the search
 *					should start;
 *		input_line	- (i) the string compared to the automaton.
 * Returns:	A pair containing the last state on the common prefix path,
 *		and the length of the prefix.
 * Globals:	None.
 * Remarks:	None.
 */
prefix_pair
common_prefix(state *s, mystr input_line)
{
  int hops = 0;
  for (state *n = s; (n = s->next(input_line[hops])) != NULL; s = n)
    hops++;
  return prefix_pair(s, hops);
}//common_prefix

/* Name:	repl_or_reg
 * Class:	None.
 * Purpose:	If an isomorphic state is found in the register,
 *		the last child of the argument state is replaced by it,
 *		otherwise the last child is registered.
 * Parameters:	parent		- (i) parent state whose last child
 *					is to be replaced or registered.
 * Returns:	The unique state in the register.
 * Globals:	Register (i/o).
 * Remarks:	The last child of a state is the target of the transition
 *		that was added as the last to the parent state.
 *		It should be the transition with the greatest label
 *		in lexicographical order.
 */
state *
repl_or_reg(state *s)
{
  if (s->fan_out()) {
    transition &last_trans = s->get_transitions().back();
    last_trans.set_target(repl_or_reg(last_trans.get_target()));
  }
  state *s1 = Register.get_or_put(s);
  if (s1 != s) {
    delete s;
    s = s1;
    s->hit();			// this is not really necessary (compat)
  }
  return s;
}

/* Name:	pseudo_repl_or_reg
 * Class:	None.
 * Purpose:	If an isomorphic state is found in the register,
 *		the last child of the argument state is replaced by it,
 *		otherwise the last child is registered.
 * Parameters:	parent		- (i) parent state whose last child
 *					is to be replaced or registered.
 * Returns:	The unique state in the register.
 * Globals:	Register (i/o).
 * Remarks:	The last child of a state is the target of the transition
 *		that was added as the last to the parent state.
 *		It should be the transition with the greatest label
 *		in lexicographical order.
 */
state *
pseudo_repl_or_reg(state *s, bool *divergent)
{
  if (s->fan_out()) {
    transition &last_trans = s->get_transitions().back();
    last_trans.set_target(pseudo_repl_or_reg(last_trans.get_target(),
					     divergent));
    *divergent |= (s->fan_out() > 1);
  }
  state *s1;
  s1 = Register.get_or_put(s);
  if (s1 != s && !*divergent) {
    delete s;
    s = s1;
    s->hit();			// this is not really necessary (compat)
  }
  return s;
}//pseudo_repl_or_reg

/* Name:	add_suffix
 * Class:	None.
 * Purpose:	Creates a chain of states and transitions recognizing
 *		the argument string, and attaches it to the state.
 * Parameters:	origin		- (i) initial state to which the chain
 *					should be attached;
 *		suffix		- (i) labels on the chain to be added.
 * Returns:	The initial state (origin).
 * Globals:	None.
 * Remarks:	There should be no transition labeled with the first character
 *		of the string going out of the state origin.
 */
state *
add_suffix(state *origin, mystr &suffix)
{
  state *tail = new state;	// NULL state to simplify processing
  tail->set_final();
  for (int i = suffix.length() - 1; i > 0; --i) {
    state *s = new state;
    s->get_transitions().push_back(transition(suffix[i], tail));
    tail->hit();		// this is not really necessary (compat)
    tail = s;
  }
  origin->get_transitions().push_back(transition(suffix[0], tail));
  tail->hit();			// this is not really necessary (compat)
  return origin;
}//add_suffix

/* Name:	unsorted_construction
 * Class:	None.
 * Purpose:	Reads strings from input and constructs an DAFSA from them.
 * Parameters:	input		- (i) input stream.
 * Returns:	The initial state of the automaton.
 * Globals:	None.
 * Remarks:	One string is one line. Duplicates allowed.
 */
state *
unsorted_construction(istream &input)
{
  mystr		input_line;	// string read from input
  state			*start = new state; // start state of the automaton
  vector<state *>	path;		    // states visited while adding
                                            // a new string
#ifdef GRAPH
  int		wordno = 0;	// word number
  int		charno = 0;	// character number
#endif

  while (getline(input, input_line)) {
    path.clear();
    path.push_back(start);
    state *s = start;
    int unreg_from = -1;   // from which state in the path states are modified
    for (unsigned int p = 0; p < input_line.size(); p++) {
      state *s1;
      if ((s1 = s->next(input_line[p])) == NULL) {
	// End of prefix - the rest of the string must be added
	if (p > 0 && unreg_from == -1) {
	  Register.remove(s);
	}
	if (unreg_from == -1) {
	  unreg_from = p;
	}
	// Add the rest of the string
	for (unsigned int p1 = p; p1 < input_line.length(); p1++) {
	  s1 = new state;
	  s->set_next(input_line[p1], s1);
	  path.push_back(s1);
	  s = s1;
	}
	break;
      }
      if (s1->fan_in() > 1) {
	// Clone and redirect
	if (unreg_from == -1 && p > 0) {
	  Register.remove(s);
	}
	s->set_next(input_line[p], (s1 = new state(*s1)));
	if (unreg_from == -1) {
	  unreg_from = p;
	}
      }
      s = s1;
      path.push_back(s);
    }//for all characters of the input line
    if (unreg_from == -1) {
      // We recognized the whole string - the whole string is in fsa
      if (!(s->is_final())) {
	// It is a substring of another string
	Register.remove(s);
	unreg_from = input_line.size();
      }
      else			// It is already as such in the fsa 
	continue;
    }
    s->set_final();
    // Register or replace states from the path
    for (int p2 = input_line.length() - 1; p2 >= 0; --p2) {
      state *s2 = path[p2+1];
      state *s3;
      if ((s3 = Register.get_or_put(s2)) != s2) {
	// There is an equivalent state somewhere else in the automaton
	//path[p2]->set_next(s3);
	if (p2 < unreg_from && p2 > 0) {
	  Register.remove(path[p2]);
	}
	path[p2]->set_next(input_line[p2], s3); // redirect transition to s3
      }
      // Else state s2 is unique and it has just got registered
      else if (p2 < unreg_from) {
	break;			// the rest of the states are registered
      }
    }//for states in the path
#ifdef GRAPH
    charno += input_line.length();
    cout << "Word " << wordno++ << " chars " << charno
	 << " states " << start->get_total_states() << "\n";
#endif
  }//while the are strings at the input
  return start;
}//unsorted_construction

/* Name:	pseudo_unsorted_construction
 * Class:	None.
 * Space:	None.
 * Purpose:	Constructs a pseudo-minimal automaton using
 *		unsorted construction.
 * Parameters:	input		- (i) input stream.
 * Returns:	The initial state of the automaton.
 * Globals:	None.
 * Remarks:	States with the cardinality of the right language greater
 *		than one are marked with the feature height set to 1.
 */
state *
pseudo_unsorted_construction(istream &input)
{
  mystr	input_line;
  state		*start = new state;
  vector<state *> path;
  int		wordno = 0;
#ifdef GRAPH
  int		charno = 0;
#endif

  Register.get_or_put(start);
  while (getline(input, input_line)) {
    path.clear();
    path.push_back(start);
    state *s = start;
    int l = input_line.length();
    int i = 0;
    state *p = NULL;
    int unreg_from = -1;
    // Traverse the prefix
    while (i < l && (p = s->next(input_line[i])) != NULL) {
      if (p->fan_in() > 1) {
	// Clone convergent states
	if (unreg_from == -1) {
	  // Changes propagate towards the initial state
	  unreg_from = i;
	  Register.remove(s);
	}
	s->set_next(input_line[i], p = new state(*p));
      }
      s = p;
      path.push_back(s);
      i++;
    }
    if (unreg_from == -1) {
      unreg_from = i;
      Register.remove(s);
    }
    // Create suffix
    while (i < l) {
      s->set_next(input_line[i], new state);
      s = s->next(input_line[i]);
      path.push_back(s);
      i++;
    }
    s->set_final();

    // Local minimization
    bool divergent = false;
    while (i >= unreg_from) {
      divergent |= (path.back()->fan_out() > 1);
      state *s1 = NULL;
      s1 = Register.get_or_put(path.back());
      if (!divergent && s1 != path.back()) {
	if (i == unreg_from && i > 0) {
	  Register.remove(path[i-1]);
	  --unreg_from;
	}
	path[i-1]->set_next(input_line[i-1], s1);
      }
      else if (i == unreg_from) {
	break;
      }
      path.pop_back();
      --i;
    }//while
//     if (divergent) {
//       while (path.size() > 0 && path.back()->get_height() != 1) {
// 	path.back()->set_height(1);
// 	path.pop_back();
//       }
//     }
#ifdef GRAPH
    charno += input_line.length();
    cout << "Word " << wordno << " chars " << charno
	 << " states " << start->get_total_states() << "\n";
#endif
    wordno++;
  }
  return start;
}//pseudo_unsorted_construction

/* Name:	watson_construction
 * Class:	None.
 * Purpose:	Implements semi-incremental construction by Bruce Watson.
 * Parameters:	input		- (i) input stream.
 * Returns:	The start state of the automaton.
 * Globals:	Register(i/o).
 * Remarks:	None.
 */
state *
watson_construction(istream &input)
{
  mystr	w;
  state		*start = new state;
#ifdef GRAPH
  int		wordno = 0;
  int		charno = 0;
#endif

  while (getline(input, w)) {
    remove_equiv(build_stack(add_iter(w, start), NULL));
#ifdef GRAPH
    charno += w.length();
    cout << "Word " << wordno++ << " chars " << charno
	 << " states " << start->get_total_states() << "\n";
#endif
  }
  
  for (trans_vec::iterator p = start->get_transitions().begin();
       p != start->get_transitions().end(); p++) {
    remove_equiv(build_stack(&*p, NULL));
  }
  return start;
}//watson construction

/* Name:	pseudo_watson_construction
 * Class:	None.
 * Purpose:	Implements semi-incremental construction by Bruce Watson
 *		adapted for pseudo-minimal automata.
 * Parameters:	input		- (i) input stream.
 * Returns:	The start state of the automaton.
 * Globals:	Register(i/o).
 * Remarks:	None.
 */
state *
pseudo_watson_construction(istream &input)
{
  mystr	w;
  state		*start = new state;
#ifdef GRAPH
  int		wordno = 0;
  int		charno = 0;
#endif

  while (getline(input, w)) {
    pseudo_remove_equiv(build_stack(pseudo_add_iter(w, start), NULL));
#ifdef GRAPH
    charno += w.length();
    cout << "Word " << wordno++ << " chars " << charno
	 << " states " << start->get_total_states() << "\n";
#endif
  }
  
  for (trans_vec::iterator p = start->get_transitions().begin();
       p != start->get_transitions().end(); p++) {
    pseudo_remove_equiv(build_stack(&*p, NULL));
  }
  return start;
}//pseudo_watson construction

/* Name:	build_stack
 * Class:	None
 * Purpose:	Builds stack of states reachable from the given state.
 * Parameters:	init_tr		- (i) initial transition;
 *		ini_stack	- (i) intial stack.
 * Returns:	Pointer to the first item on the stack.
 * Globals:	None.
 * Remarks:	None.
 */
stack_item *
build_stack(transition *ini_tr, stack_item *ini_stack)
{
  stack_item	*x = new stack_item(ini_tr, ini_stack);
  state		*s = ini_tr->get_target();
  trans_vec::iterator p = s->get_transitions().begin();
  for (int i = 0; i < s->fan_out(); i++, p++) {
    if (!(p->get_target()->is_final())) {
      x = build_stack(&(*p), x);
    }
  }
  return x;
}//build_stack

/* Name:	add_iter
 * Class:	None.
 * Purpose:	Adds a word to the automaton for Watson construction.
 * Parameters:	word		- (i) the word to be added;
 *		start		- (i) the initial state to which the word
 *					should be added.
 * Returns:	The last transition in the path of the word.
 * Globals:	None.
 * Remarks:	None.
 */
transition *
add_iter(mystr word, state *start)
{
  unsigned int i = 0;
  state *s = start;
  transition *last_trans = NULL;
  // Follow common prefix
  while (i < word.size() && s->next(word[i])) {
    last_trans = s->find_trans(word[i]);
    s = s->next(word[i++]);
  }
  // Add suffix
  while (i < word.size()) {
    state *s1 = new state;
    s->set_next(word[i], s1);
    last_trans = s->find_trans(word[i++]);
    s = s1;
  }
  s->set_final();
  return last_trans;
}//add_iter

/* Name:	psedo_add_iter
 * Class:	None.
 * Purpose:	Adds a word to the automaton for Watson construction
 *		of a pseudo-minimal automaton.
 * Parameters:	word		- (i) the word to be added;
 *		start		- (i) the initial state to which the word
 *					should be added.
 * Returns:	The last transition in the path of the word.
 * Globals:	None.
 * Remarks:	The only difference with the original function is that we
 *		mark states with cardinality of the right language greater
 *		than one with the feature hight set to 1.
 */
transition *
pseudo_add_iter(mystr word, state *start)
{
  unsigned int i = 0;
  state *s = start;
  transition *last_trans = NULL;
  // Follow common prefix
  while (i < word.size() && s->next(word[i])) {
    last_trans = s->find_trans(word[i]);
    s = s->next(word[i++]);
  }
  state *divergent = s;
  // Add suffix
  while (i < word.size()) {
    state *s1 = new state;
    s->set_next(word[i], s1);
    last_trans = s->find_trans(word[i++]);
    s = s1;
  }
  s->set_final();
  // Mark states
  if (divergent->fan_out() > 1) {
    // We are not dealing with a non-prefix
    for (s = start, i = 0; true; s = s->next(word[i++])) {
      s->set_height(1);
      if (s == divergent) {
	break;
      }
    }
  }
  return last_trans;
}//pseudo_add_iter

/* Name:	remove_equiv
 * Class:	None.
 * Purpose:	Replaces redundant states with their equivalents.
 * Parameters:	q		- (i) top of stack of states to process.
 * Returns:	Nothing.
 * Remarks:	None.
 */
void
remove_equiv(stack_item *q)
{
  while (q) {
    state *s = q->t->get_target();
    state *r;
    if ((r = Register.get_or_put(s)) != s) {
      q->t->set_target(r);
      r->hit();
      delete s;
    }
    stack_item *t = q->next;
    delete q;
    q = t;
  }
}//remove_equiv

/* Name:	pseudo_remove_equiv
 * Class:	None.
 * Purpose:	Replaces redundant states with their equivalents
 *		if the cardinality of the right language of the states
 *		is greater than 1.
 * Parameters:	q		- (i) top of stack of states to process.
 * Returns:	Nothing.
 * Remarks:	States with with the cardinality of the right language
 *		greater than 1 are marked with the feature height set to 1.
 */
void
pseudo_remove_equiv(stack_item *q)
{
  while (q) {
    state *s = q->t->get_target();
    state *r = Register.get_or_put(s);
    if (r != s && r->get_height() != 1) {
      q->t->set_target(r);
      r->hit();
      delete s;
    }
    stack_item *t = q->next;
    delete q;
    q = t;
  }
}//pseudo_remove_equiv

/* Name:	build_trie
 * Class:	None.
 * Purpose:	Builds a trie from input strings.
 * Parameters:	input		- (i) input stream.
 * Returns:	Root of the trie.
 * Globals:	None.
 * Remarks:	None.
 */
state *
build_trie(istream &input)
{
  state *start = new state;
  mystr w;
#ifdef GRAPH
  int		wordno = 0;
  int		charno = 0;
#endif

  while (getline(input, w)) {
    state *s = start;
    unsigned int p = 0;
    state *s1;
    while (p < w.size() && (s1 = s->next(w[p])) != NULL) {
      s = s1; p++;
    }
    while (p < w.size()) {
      s->set_next(w[p], (s1 = new state));
      p++; s = s1;
    }
    s->set_final();
#ifdef GRAPH
    charno += w.length();
    cout << "Word " << wordno++ << " chars " << charno
	 << " states " << start->get_total_states() << "\n";
#endif
  }
  return start;
}//build_trie

/* Name:	number_states
 * Class:	None.
 * Purpose:	Assigns numbers to states.
 * Parameters:	s		- (i) initial state to be numbered;
 *		n		- (i) initial state number.
 * Returns:	Number of states numbered.
 * Globals:	None.
 * Remarks:	States not yet numbered have number -1.
 */
int
number_states(state *s, const int n)
{
  if (s->get_number() != -1) {
    return n;
  }
  int total = n + 1;
  s->set_number(n);
  for (int i = 0; i < s->fan_out(); i++) {
    total = number_states(s->get_transitions()[i].get_target(), total);
  }
  return total;
}//number_states

/* Name:	fill_state_vec
 * Class:	None.
 * Purpose:	Creates a vector filled with pointers to states in automaton.
 * Parameters:	s		- (i) initial state of the automaton;
 *		n		- (i) number of states in the automaton.
 * Returns:	The vector.
 * Globals:	None.
 * Remarks:	The vector is created in dynamic memory.
 */
state **
fill_state_vec(state *s, const int n)
{
  state **v = new state *[n];
  for (int i = 0; i < n; i++) {
    v[i] = NULL;
  }
  v[0] = s;
  for (trans_vec::iterator p = s->get_transitions().begin();
       p != s->get_transitions().end(); p++) {
    fill_state_cell(v, p->get_target());
  }
  return v;
}//fill_state_vec

/* Name:	fill_state_cell
 * Class:	None.
 * Purpose:	Fills one cell in a vector of states.
 * Parameters:	v		- (i/o) the vector of states;
 *		s		- (i) state to put into the vector.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	States should already be numbered.
 */
void
fill_state_cell(state **v, state *s)
{
  if (v[s->get_number()] != s) {
    v[s->get_number()] = s;
    for (trans_vec::iterator p = s->get_transitions().begin();
       p != s->get_transitions().end(); p++) {
      fill_state_cell(v, p->get_target());
    }
  }
}//fill_state_cell

/* Name:	minim_trie
 * Class:	None.
 * Purpose:	Builds an automaton by constructing a trie and minimizing it.
 * Parameters:	input		- (i) input stream.
 * Returns:	The initial state of the automaton.
 * Globals:	None.
 * Remarks:	Hopcroft minimization algorithm is used.
 */
state *
minim_trie(istream &input)
{
  state *start = build_trie(input);
  int n = number_states(start, 0);
  start = hopcroft_minim(fill_state_vec(start, n), n);
  return start;
}//minim_trie

class block_item {
public:
  int		state_no;	// state number
  block_item	*prev;		// previous item
  block_item	*next;		// next item
  block_item(const int i, block_item *n = NULL)
    : state_no(i), prev(NULL), next(n) { if (n) { n->prev = this; }}
};//block_item

class block_start {
public:
  int		items;		// counter
  block_item	*first;		// first item
  block_start(void) : items(0), first(NULL) {}
  void put(const int i) { first = new block_item(i, first); items++; }
};//block_start

/* Name:	hopcroft_minim
 * Class:	None.
 * Purpose:	Implements Hopcroft minimalization algorithm.
 * Parameters:	v		- (i) vector of states;
 *		n		- (i) number of states.
 * Returns:	The start state of the automaton.
 * Globals:	None.
 * Remarks:	None.
 */
state *
hopcroft_minim(state **v, const int n)
{
  // Calculate the number of transitions
  int num_trans = 0;
  for (int i = 0; i < n; i++) {
    num_trans += v[i]->fan_out();
  }
  struct btrans {
    mychar	label;
    int		target;
  };
  btrans *backtrans = new btrans[num_trans];	//back transitions
  int *backstart = new int[n];  // indexes of back transitions
  vector<bool> inwaiting(n);
  block_start *block = new block_start[n];
  int *inblock = new int[n];
  set<mychar> labels;
  // Compute where the back transitions start for each state
  int back_st = 0;
  for (int s1 = 0; s1 < n; s1++) {
    backstart[s1] = back_st;
    back_st += v[s1]->fan_in();
  }
  // Create back transitions
  block_item **bip = new block_item *[n];
  for (int s2 = 0; s2 < n; s2++) {
    mychar l;
    trans_vec &t1 = v[s2]->get_transitions();
    for (trans_vec::iterator t2 = t1.begin();
	 t2 != t1.end(); t2++) {
      backtrans[backstart[t2->get_target()->get_number()]].label =
	(l = t2->get_label());
      // We have to change backstart here
      backtrans[backstart[t2->get_target()->get_number()]++].target = s2;
      labels.insert(l);
    }
    // Put the state to the appropriate block and set inblock correctly
    block[(inblock[s2] = (v[s2]->is_final() ? 1 : 0))].put(s2);
    bip[s2] = block[inblock[s2]].first;
  }
  // Restore backstart
  back_st = 0;
  for (int s3 = 0; s3 < n; s3++) {
    backstart[s3] = back_st;
    back_st += v[s3]->fan_in();
  }
  int *waiting = new int[n];
  int *inverse = new int[n]; // because inverse can be > block[i]
  waiting[0] = 0; inwaiting[0] = true;
  waiting[1] = 1; inwaiting[1] = true;
  int *jcount = new int[n];
  for (int jc1 = 0; jc1 < n; jc1++) jcount[jc1] = 0;
  int w_start = 0;
  int q = 2;
  while (w_start < q) {
    inwaiting[waiting[w_start]] = false;
    for (set<mychar>::iterator lptr = labels.begin(); lptr != labels.end();
	 lptr++) {
      mychar ll = *lptr;
      int inv_count = 0;
      vector<bool> in_inverse(n);
      for (block_item *bs = block[waiting[w_start]].first; bs; bs = bs->next) {
	int bst = backstart[bs->state_no];
	for (int tn1 = bst; tn1 < bst + v[bs->state_no]->fan_in(); tn1++) {
	  // Construct inverted
	  if (backtrans[tn1].label == ll &&
	      !in_inverse[backtrans[tn1].target]) {
	    inverse[inv_count++] = backtrans[tn1].target;
	    in_inverse[backtrans[tn1].target] = true;
	  }
	}
      }//for bs
      // Construct jlist
      if (inv_count) {
	int jn = 0;
	int *jlist = new int[inv_count];
	for (int ic = 0; ic < inv_count; ic++) {
	  if (jcount[inblock[inverse[ic]]]++ == 0) {
	    jlist[jn++] = inblock[inverse[ic]];
	  }
	}
	// For each j such that B[j] & INVERSE != 0 and B[j] not in INVERSE
	for (int jl = 0; jl < jn; jl++) {
	  if (jcount[jlist[jl]] < block[jlist[jl]].items) {
	    int j = jlist[jl];
	    for (int ic1 = 0; ic1 < inv_count; ic1++) {
	      if (inblock[inverse[ic1]] == j) {
		// Element in intersection
		// Move to B[q]
		block_item *bp = bip[inverse[ic1]];
		block[q].items++;
		if (bp->next) {
		  bp->next->prev = bp->prev;
		}
		if (bp->prev) {
		  bp->prev->next = bp->next;
		}
		else {
		  block[inblock[bp->state_no]].first = bp->next;
		}
		--block[inblock[bp->state_no]].items;
		inblock[bp->state_no] = q;
		bp->next = block[q].first; bp->prev = NULL;
		block[q].first = bp;
		if (bp->next) {
		  bp->next->prev = bp;
		}
	      }//if element in intersection
	    }//for ic1
	    // Update waiting list
	    if (inwaiting[j]) {
	      waiting[q] = q; inwaiting[q] = true;
	    }
	    else if (block[j].items <= block[q].items) {
	      waiting[q] = j; inwaiting[j] = true;
	    }
	    else {
	      waiting[q] = q; inwaiting[q] = true;
	    }
	    q++;
	  }//if
	  jcount[jlist[jl]] = 0;
	}//for jl
	delete [] jlist;
      }//if inv_count
    }// for ll
    w_start++;
  }//while w_start < q
  delete [] jcount;
  delete [] inverse;
  delete [] waiting;
  delete [] bip;
  delete [] inblock;

  // Remove redundant states
  for (int bn = 0; bn < q; bn++) {
    block_item *bp2 = block[bn].first;
    int representative = bp2->state_no;
    // Remove all equivalent states
    block_item *bp1next;
    for (block_item *bp1 = bp2->next; bp1; bp1 = bp1next) {
      // Replace all links to *bp1 with links to representative
      bp1next = bp1->next;
      int bs_base = backstart[bp1->state_no];
      for (int bs9 = bs_base; bs9 < bs_base + v[bp1->state_no]->fan_in();
	   bs9++) {
	int pointing_state = backtrans[bs9].target;
	trans_vec &t9 = v[pointing_state]->get_transitions();
	for (trans_vec::iterator p9 = t9.begin(); p9 != t9.end();
	     p9++) {
	  if (p9->get_target() == v[bp1->state_no]) {
	    p9->set_target(v[representative]);
	  }
	}
      }
      // Replace targets of back transitions
      for (trans_vec::iterator p8 =
	     v[bp1->state_no]->get_transitions().begin();
	   p8 != v[bp1->state_no]->get_transitions().end(); p8++) {
	state *target_state = p8->get_target();
	target_state->hit();	// because deletion is cascaded
	int bs_base2 = backstart[target_state->get_number()];
	for (int bs7 = bs_base2;
	     bs7 < bs_base2 + v[target_state->get_number()]->fan_in(); bs7++) {
	  if (backtrans[bs7].target == bp1->state_no) {
	    backtrans[bs7].target = representative;
	  }
	}
      }
      //v[bp1->state_no] = v[representative];
      delete v[bp1->state_no];
      v[bp1->state_no] = NULL;
      delete bp1;
    }
  }
  delete [] block;
  delete [] backstart;
  delete [] backtrans;
  return v[0];
}//hopcroft_minim

/* Name:	trie_postorder
 * Class:	None.
 * Purpose:	Implements trie construction and postorder minimization.
 * Parameters:	input		- (i) input stream.
 * Returns:	The initial state of the automaton.
 * Globals:	Register	- (i/o) register of states.
 * Remarks:	None.
 */
state *
trie_postorder(istream &input)
{
  state *start = build_trie(input);
  return postorder_minim(start);
}//trie_postorder

/* Name:	postorder_minim
 * Class:	None.
 * Purpose:	Minimizes a trie in postorder.
 * Parameters:	start		- (i) root of a (sub)trie.
 * Returns:	The root.
 * Globals:	Register(i/o).
 * Remarks:	Incoming transition counter is not maintained. Sorry.
 */
state *
postorder_minim(state *start)
{
  trans_vec &t = start->get_transitions();
  for (trans_vec::iterator p = t.begin(); p != t.end(); p++) {
    p->set_target(postorder_minim(p->get_target()));
  }
  return Register.get_or_put(start);
}//postorder_minim

/* Name:	revuz_construction
 * Class:	None.
 * Purpose:	Implements semi-incremental construction by Dominique Revuz.
 * Parameters:	input		- (i) input stream.
 * Returns:	The initial state of the automaton.
 * Globals:	None.
 * Remarks:	None.
 */
state *
revuz_construction(istream &input)
{
  state *s = pseudo_revuz(input);
  int h = find_height(s);
  int no_states = number_states(s, 0);
  state **v = fill_state_vec(s, no_states);
  lex_sort(v, no_states, h);
  delete [] v;			// we no longer need it
#ifdef DEBUG
  mystr ss;
  print_automaton(s, ss);
#endif
  return s;
}//revuz_construction

/* Name:	trie_lex
 * Class:	None.
 * Purpose:	Implements trie-construction followed by lexicographical sort.
 * Parameters:	input		- (i) input stream.
 * Returns:	The initial state of the automaton.
 * Globals:	None.
 * Remarks:	This is Revuz minus pseudo-minimization.
 */
state *
trie_lex(istream &input)
{
  state *s = build_trie(input);
  int h = find_height(s);
  int no_states = number_states(s, 0);
  state **v = fill_state_vec(s, no_states);
  lex_sort(v, no_states, h);
  delete [] v;			// we no longer need it
#ifdef DEBUG
  mystr ss;
  print_automaton(s, ss);
#endif
  return s;
}//trie_lex

/* Name:	lex_sort
 * Class:	None.
 * Purpose:	Implements bucket sort on vector of states, and removes
 *		redundant (equivalent) states.
 * Parameters:	v		- (i/o) vector of states;
 *		n		- (i) number of states in the automaton;
 *		h		- (i) maximal height.
 * Returns:	Nothing.
 * Remarks:	The vector is sorted in situ.
 *		States are first sorted on height, then on the number
 *		of transitions, then on transitions: first labels,
 *		then targets.
 *		States are sorted by layers of increasing height.
 *		Once one layer is sorted, equivalent states in the vector
 *		are replaced with a unique representative.
 *		Before sorting the next layer, all transitions to redundant
 *		states are redirected to the unique representatives.
 *		After sorting, the vector may contain multiple occurences
 *		of representative states.
 */
void
lex_sort(state **v, const int n, const int h)
{
  vector<state *> *bucket = new vector<state *>[h + 1];
  int *size = new int[h + 1];
  int max_fanout = -1;
  for (int i = 0; i < n; i++) {
    bucket[v[i]->get_height()].push_back(v[i]);
    if (v[i]->fan_out() > max_fanout) {
      max_fanout = v[i]->fan_out();
    }
  }

  int bucket_start = 0;
  for (int b1 = 0; b1 < h + 1; b1++) {
    int curr_bucket_size = bucket[b1].size();
    size[b1] = curr_bucket_size;
    for (int b2 = 0; b2 < curr_bucket_size; b2++) {
      v[bucket_start + b2] = bucket[b1][b2];
      v[bucket_start + b2]->set_number(bucket_start + b2);
    }
    bucket[b1].clear();
    bucket_start += curr_bucket_size;
  }
  delete [] bucket;
  bucket_start = 0;
  for (int b3 = 0; b3 < h + 1; b3++) {
    int curr_bsize = size[b3];
    // Change targets of transitions so that they point to unique states
    if (b3 > 0) {
      for (int b6 = bucket_start; b6 < bucket_start + curr_bsize; b6++) {
	// We start with 1 because there is nothing below 0
	for (int b7 = 0; b7 < v[b6]->fan_out(); b7++) {
	  state *tg7 = v[b6]->get_transitions()[b7].get_target();
	  if (v[tg7->get_number()] != tg7) {
	    v[b6]->get_transitions()[b7].set_target(v[tg7->get_number()]);
	    v[tg7->get_number()]->hit();
	    if (tg7->hit(-1) == 0 && tg7->get_height() == -1) {
	      delete tg7;
	    }
	  }
	}
      }
    }
    if (curr_bsize > 1) {
      // Sort
      sort_on_fanout(v, bucket_start, curr_bsize, max_fanout, n);
    }
    bucket_start += curr_bsize;
  }
#ifdef DEBUG
  for (int dd1 = 0; dd1 < n - 1; dd1++) {
    state *dd2 = v[dd1];
    for (int dd3 = dd1 + 1; dd3 < n; dd3++) {
      if (dd2 != v[dd3] && key_eq(dd2, v[dd3])) {
	cerr << "state " << dd2->get_number() << " height "
	     << dd2->get_height() << " at " << dd1 << " with transitions:\n";
	for (int dd4 = 0; dd4 < dd2->fan_out(); dd4++) {
	  cerr << dd2->get_transitions()[dd4].get_label() << " -> "
	       << dd2->get_transitions()[dd4].get_target()->get_number()
	       << "\n";
	}
	cerr << "equivalent to state " << v[dd3]->get_number()
	     << " height " << v[dd3]->get_height()
	     << " at " << dd3
	     << " with transitions:\n";
	for (int dd5 = 0; dd5 < v[dd3]->fan_out(); dd5++) {
	  cerr << v[dd3]->get_transitions()[dd5].get_label() << " -> "
	       << v[dd3]->get_transitions()[dd5].get_target()->get_number()
	       << "\n";
	}
      }
    }
  }
#endif
  delete [] size;
}//lex_sort

/* Name:	sort_on_fanout
 * Class:	None.
 * Purpose:	Implements bucket sort on a vector of states, sorting on fanout
 * Parameters:	v		- (i/o) vector of states;
 *		bstart		- (i) start index of the part of v
 *					to be sorted;
 *		bsize		- (i) size of chunk to be sorted;
 *		max_fanout	- (i) max number of out transitions;
 *		num_states	- (i) number of states in the automaton.
 * Returns:	A vector where the chunk has been sorted.
 * Globals:	None.
 * Remarks:	None.
 */
state **
sort_on_fanout(state **v, const int bstart, const int bsize,
	       const int max_fanout, const int num_states)
{
  vector<state *> *bucket = new vector<state *>[max_fanout + 1];
  int *size = new int[max_fanout + 1];
  for (int s1 = bstart; s1 < bstart + bsize; s1++) {
    bucket[v[s1]->fan_out()].push_back(v[s1]);
  }
  int bucket_start = bstart;
  for (int b1 = 0; b1 < max_fanout + 1; b1++) {
    int curr_bucket_size = bucket[b1].size();
    size[b1] = curr_bucket_size;
    for (int b2 = 0; b2 < curr_bucket_size; b2++) {
      v[bucket_start + b2] = bucket[b1][b2];
      v[bucket_start + b2]->set_number(bucket_start + b2);
    }
    bucket[b1].clear();
    bucket_start += curr_bucket_size;
  }
  delete [] bucket;
  bucket_start = bstart;
  for (int b3 = 0; b3 < max_fanout + 1; b3++) {
    int curr_bsize = size[b3];
    if (curr_bsize > 1 && v[bucket_start]->fan_out() > 0) {
      sort_on_label(v, bucket_start, curr_bsize, 0, num_states);
    }
    else if (curr_bsize > 1) {
      sort_on_final(v, bucket_start, curr_bsize);
    }
    bucket_start += curr_bsize;
  }
  delete [] size;
  return v;
}//sort_on_fanout

/* Name:	sort_on_label
 * Class:	None.
 * Purpose:	Sorts a part of a vetcor of states on their nth transition.
 * Parameters:	v		- (i/o) vector of states to be sorted;
 *		bstart		- (i) starting index of the part;
 *		bsize		- (i) size of the part;
 *		tr_no		- (i) transition number to be sorted;
 *		num_states	- (i) number of states int the automaton.
 * Returns:	Sorted vector.
 * Globals:	None.
 * Remarks:	Bucket sort.
 */
state **
sort_on_label(state **v, const int bstart, const int bsize, const int tr_no,
	      const int num_states)
{
  map<mychar, int>	lab_map;
  vector<mychar>	lab_vec;

  // Map labels into consecutive integers to save space
  for (int b1 = bstart; b1 < bstart + bsize; b1++) {
    mychar l = v[b1]->get_transitions()[tr_no].get_label();
    if (lab_map.find(l) == lab_map.end()) {
      lab_map[l] = lab_vec.size();
      lab_vec.push_back(l);
    }
  }

  // Sort
  vector<state *> *bucket = new vector<state *>[lab_vec.size()];
  int *size = new int[lab_vec.size()];
  for (int b2 = bstart; b2 < bstart + bsize; b2++) {
    mychar l1 = v[b2]->get_transitions()[tr_no].get_label();
    bucket[lab_map[l1]].push_back(v[b2]);
  }
  int bucket_start = bstart;
  for (unsigned int b3 = 0; b3 < lab_vec.size(); b3++) {
    unsigned int curr_bucket_size = bucket[b3].size();
    size[b3] = curr_bucket_size;
    for (unsigned int b4 = 0; b4 < curr_bucket_size; b4++) {
      v[bucket_start + b4] = bucket[b3][b4];
      v[bucket_start + b4]->set_number(bucket_start + b4);
    }
    bucket[b3].clear();
    bucket_start += curr_bucket_size;
  }
  delete [] bucket;

  bucket_start = bstart;
  for (unsigned int b5 = 0; b5 < lab_vec.size(); b5++) {
    int curr_bsize = size[b5];
    if (curr_bsize > 1) {
      sort_on_target(v, bucket_start, curr_bsize, tr_no,
		     num_states);
    }
    bucket_start += curr_bsize;
  }
  return v;
}//sort_on_label

/* Name:	sort_on_target
 * Class:	None.
 * Purpose:	Sorts part of a vector of states on the targets
 *		of their nth transitions.
 * Parameters:	v		- (i) vector of states;
 *		bstart		- (i) start index of the part;
 *		bsize		- (i) size of the part;
 *		tr_no		- (i) transition number;
 *		num_states	- (i) number of states in the automaton.
 * Returns:	Vector with sorted part.
 * Globals:	None.
 * Remarks:	The vector is sorted in situ.
 *		Because the range of state numbers can be huge,
 *		they are sorted byte by byte. This stinks, but
 *		the whole Revuz's algorithm is only theoretically sound.
 *		It is one of the crappiest algorithms I have ever seen.
 */
state **
sort_on_target(state **v, const int bstart, const int bsize, const int tr_no,
	       const int num_states)
{
  // Sort
  vector<state *> *bucket = new vector<state *>[256];
  int *size = new int[256];
  int shift = 0;
  int bucket_start = bstart;
  for (int nos = num_states; nos; nos >>= 8, shift++) {
    for (int b2 = bstart; b2 < bstart + bsize; b2++) {
      int t1 = v[b2]->get_transitions()[tr_no].get_target()->get_number();
      int t2 = ((t1 >> (8 * shift)) & 0xff);
      bucket[t2].push_back(v[b2]);
    }
    bucket_start = bstart;
    for (int b3 = 0; b3 < 256; b3++) {
      int curr_bucket_size = bucket[b3].size();
      size[b3] = curr_bucket_size;
      for (int b4 = 0; b4 < curr_bucket_size; b4++) {
	v[bucket_start + b4] = bucket[b3][b4];
	v[bucket_start + b4]->set_number(bucket_start + b4);
      }
      bucket[b3].clear();
      bucket_start += curr_bucket_size;
    }
  }
  delete [] bucket;

  bucket_start = bstart;
  int b6;
  for (int b5 = bstart; b5 < bstart + bsize; b5 = b6) {
    int tn = v[b5]->get_transitions()[tr_no].get_target()->get_number();
    for (b6 = b5 + 1;
	 b6 < bstart + bsize &&
	   v[b6]->get_transitions()[tr_no].get_target()->get_number() == tn;
	 b6++)
      ;
    int max_fan = v[b5]->fan_out();
    if (b6 - b5 > 1 && tr_no + 1 < max_fan) {
      sort_on_label(v, b5, b6 - b5, tr_no + 1, num_states);
    }
    else if (tr_no + 1 >= max_fan) {
      sort_on_final(v, b5, b6 - b5);
    }
  }
  return v;
}//sort_on_target

/* Name:	sort_on_final
 * Class:	None.
 * Purpose:	Sorts states in a part of a vector on their finality.
 * Parameters:	v		- (i/o) vector of states;
 *		bstart		- (i) start of the part;
 *		bsize		- (i) size of the part.
 * Returns:	Vector with the part sorted.
 * Remarks:	The vector is sorted in situ.
 *		This is the last stage of a bucket sort.
 *		Therefore, series of equivalent states are replaced with
 *		a series of one unique representative.
 */
state **
sort_on_final(state **v, const int bstart, const int bsize)
{
  vector<state *> *bucket = new vector<state *>[2];
  for (int b1 = bstart; b1 < bstart + bsize; b1++) {
    bucket[v[b1]->is_final() ? 1 : 0].push_back(v[b1]);
  }
  int bucket_start = bstart;
  for (int b2 = 0; b2 < 2; b2++) {
    int curr_size = bucket[b2].size();
    for (int b3 = 0; b3 < curr_size; b3++) {
      // Since the states were sorted on all criteria, all states in one
      // bucket are now equivalent
      v[bucket_start + b3] = bucket[b2][0];
      bucket[b2][b3]->set_number(bucket_start);
      if (b3 > 0) {
	bucket[b2][b3]->set_height(-1);
      }
    }
    bucket_start += curr_size;
  }
  return v;
}//sort_on_final

/* Name:	find_height
 * Class:	None.
 * Purpose:	Calculates height for each state.
 * Parameters:	s		- (i/o) initial state of a subautomaton.
 * Returns:	Height of the subautomaton.
 * Globals:	None.
 * Remarks:	The height of a state is the length of the longest path
 *		from the state to any of the final states.
 *		The function is called recursively for all children.
 */
int
find_height(state *s)
{
  if (s->get_height() != -1) {
    return s->get_height();
  }
  int mh = -1;
  for (trans_vec::iterator p = s->get_transitions().begin();
       p != s->get_transitions().end(); p++) {
    mh = max(mh, find_height(p->get_target()));
  }
  s->set_height(++mh);
  return mh;
}//find_height

/* Name:	pseudo_revuz
 * Class:	None.
 * Purpose:	Builds a pseudo-minimal automaton.
 * Parameters:	input		- (i) input stream.
 * Returns:	The pseudo-minimal automaton.
 * Remarks:	Words have to be sorted on their reversals.
 *		Common suffix is compressed (represented once).
 */
state *
pseudo_revuz(istream &input)
{
  state *start = new state;
  mystr w, w1;
  vector<state *>path[2];
#ifdef GRAPH
  int		wordno = 0;
  int		charno = 0;
#endif

  path[true].clear(); path[false].clear();
  bool odd_line = true;
  state *s1 = new state;
  s1->set_final();
  path[false].push_back(s1);
  state *tarpit = s1;
  w1 = "\0";			// This character should never appear
  while (getline(input, w)) {
    state *s = start;
    path[odd_line].clear();
    path[odd_line].push_back(start);
    // Follow common prefix to the first reentrant state if any
    unsigned int p;
    for (p = 0; p < w.length() && (s1 = s->next(w[p])) != NULL
	   && s1->fan_in() == 1; p++) {
      s = s1;
      s->set_height(-2);
      path[odd_line].push_back(s);
    }
    // Clone reentrant states
    for (; p < w.length() && s1 != NULL && s1->fan_in() > 1; p++) {
      s->set_next(w[p], (s1 = new state(*s1)));
      s = s1;
      path[odd_line].push_back(s);
      s1 = (p < w.length() ? s->next(w[p+1]) : NULL);
    }
    if (p == w.length()) {
      // The word is a prefix of another word
      s->set_final();
      // Unmark the prefix
      for (unsigned int j = 1; j < path[odd_line].size(); j++) {
	path[odd_line][j]->set_height(-1);
      }
    }
    else {
      // Now deal with the suffix
      // Find what the common suffix is
      int offset = w1.length() - w.length();
      unsigned int limit = max((int)p, -offset);
      unsigned int p1;
      state *sp = NULL;
      if (path[!odd_line].back()->fan_out() > 0) {
	// The last worded ended in the middle of the fsa!
	p1 = w.length() -1;
	path[!odd_line].pop_back();
	path[!odd_line].push_back(tarpit);
      }
      else {
	for (p1 = w.length() - 1;
	     p1 > limit && w[p1] == w1[p1 + offset] &&
	       (sp = path[!odd_line][p1 + offset])->get_height() == -1 &&
	       sp->fan_out() < 2 && !sp->is_final(); --p1)
	  ;
      }
      // Unmark the prefix
      for (unsigned int i = 1; i < path[odd_line].size(); i++) {
	path[odd_line][i]->set_height(-1);
      }
      // Build path from the common prefix to the common suffix
      while (p < p1) {
	s->set_next(w[p], (s1 = new state));
	s = s1;
	path[odd_line].push_back(s);
	p++;
      }
      if (p < w.length() - 1) {
	// Just append the suffix
	s->set_next(w[p], (s1 = path[!odd_line][p+1+offset]));
	s = s1;
	path[odd_line].push_back(s);
	p++;
	while (p < w.length()) {
	  path[odd_line].push_back(path[!odd_line][p+offset+1]);
	  p++;
	}
      }
      else {
	// There is no common suffix, just make the last transition to the last
	// state of the previous path
	s->set_next(w[p], (s1 = path[!odd_line].back()));
	path[odd_line].push_back(s1);
      }
    }
    odd_line = !odd_line;
    w1 = w;
#ifdef GRAPH
    charno += w.length();
    cout << "Word " << wordno++ << " chars " << charno
	 << " states " << start->get_total_states() << "\n";
#endif
  }
  return start;
}//pseudo_construction

/* Name:	usage
 * Class:	None.
 * Purpose:	Explains the usage of the program.
 * Parameters:	None.
 * Returns:	Nothing.
 * Remarks:	None.
 */
void
usage(void)
{
  cerr << "Usage:\nadfa [option] [-E] [datafile]\n\nwhere:\n"
       << "datafile is input file name (default: standard input)\n"
       << "option is:\n-u\t- unsorted construction\n"
       << "-w\t- Watson construction\n"
       << "-r\t- Revuz construction\n"
       << "-h\t- trie + Hopcroft minimization\n"
       << "-p\t- trie + postorder minimization\n"
       << "-l\t- trie + lexicographical (bucket) sort\n"
#ifdef HASH
       << "-d\t- dynamic hashing (words get subsequent numbers)\n"
#endif
       << "-R\t- pseudo-minimal automaton using Revuz's construction\n"
       << "-S\t- pseudo-minimal automaton using sorted construction\n"
       << "-W\t- pseudo-minimal automaton using Watson construction\n"
       << "-U\t- pseudo-minimal automaton using unsorted construction\n"
       << "Default is sorted construction.\n";
  cerr << "-E means expand minimal automaton to a pseudo-minimal one\n";
}//usage

int
main(const int argc, const char *argv[])
{
  const_type construction_type = sorted;
  const char *data_file_name = NULL;
  bool expand = false;
  if (argc >= 1 && argc <= 4) {
    for (int i = 1; i < argc; i++) {
      if (argv[i][0] == '-') {
	if (argv[i][1] == 'u') {
	  construction_type = unsorted;
	}
	else if (argv[i][1] == 'w') {
	  construction_type = watson;
	}
	else if (argv[i][1] == 'h') {
	  construction_type = triehop;
	}
	else if (argv[i][1] == 'p') {
	  construction_type = triepost;
	}
	else if (argv[i][1] == 'r') {
	  construction_type = revuz;
	}
	else if (argv[i][1] == 'l') {
	  construction_type = trielex;
	}
	else if (argv[i][1] == 'd') {
	  construction_type = dynahash;
	}
	else if (argv[i][1] == 'E') {
	  expand = true;
	}
	else if (argv[i][1] == 'R') {
	  construction_type = psevuz;
	}
	else if (argv[i][1] == 'S') {
	  construction_type = pseudosorted;
	}
	else if (argv[i][1] == 'W') {
	  construction_type = pseudowatson;
	}
	else if (argv[i][1] == 'U') {
	  construction_type = pseudounsorted;
	}
	else {
	  usage();
	  return 1;
	}
      }
      else {
	data_file_name = argv[i];
      }
    }
  }
  else {
    usage();
    return 1;
  }

  if (expand && (construction_type == revuz || construction_type == trielex)){
    cerr << "Option -E cannot be used with -r and -l" << endl;
    usage();
    return 1;
  }
  if (data_file_name) {
    ifstream data_file(data_file_name);
    if (!data_file) {
      cerr << "Cannot read from " << data_file_name << "\n";
      return 2;
    }
    return apply_method(data_file, construction_type, expand);
  }
  else {
    return apply_method(cin, construction_type, expand);
  }
}//main

/* Name:	apply_method
 * Class:	None.
 * Purpose:	Bypasses stupid restrictions imposed by libg++.
 * Parameters:	input		- (i) input stream;
 *		construction	- (i) construction type;
 *		expand		- (i) whether to expand the minimal
 *					automaton to a pseudominimal one.
 * Returns:	0 if OK, non-zero otherwise.
 * Globals:	None.
 * Remarks:	Since the following:
 *
 *		istream *inp = &cin;
 *		sorted_construction(*inp);
 *
 *		did not work (cin is not even istream!!!), even though
 *
 *		sorted_construction(cin)
 *
 *		did, I had a choice: either to have two calls per method,
 *		or to introduce this faky function.
 */
int
apply_method(istream &input, const const_type construction, const bool expand)
{
  state *s = NULL;;

  switch (construction) {

  case sorted:
    s = sorted_construction(input);
    break;

  case unsorted:
    s = unsorted_construction(input);
    break;

  case watson:
    s = watson_construction(input);
    break;

  case revuz:
    s = revuz_construction(input);
    break;

    // trie + Hopcroft minimization
  case triehop:
    s = minim_trie(input);
    break;

    // trie + register-based minimization from incremental algorithms
  case triepost:
    s = trie_postorder(input);
    break;

  case trielex:
    s = trie_lex(input);
    break;

  case psevuz:
    s = pseudo_revuz(input);
    break;

  case pseudosorted:
    s = pseudo_sorted_construction(input);
    break;

  case pseudowatson:
    s = pseudo_watson_construction(input);
    break;

  case pseudounsorted:
    s = pseudo_unsorted_construction(input);
    break;

  case dynahash:
#ifdef HASH
    s = dynamic_hash(input);
#else
    cerr << "adfa not compiled with -DHASH\n";
#endif
    break;

  default:
    cerr << "Unknown method!\n";
    exit(3);
  }
#ifdef STATS
  cout << "Max states: " << s->get_max_states() << "\n";
  cout << "Total states: " << s->get_total_states() << "\n";
  cout << "Total transitions: " << count_transitions(s, 0) << "\n";
  int calls = Register.get_calls();
  if (calls) {
    cout << "Register: calls: " << calls
	 << " including " << Register.get_removals() << " removals.\n"
	 << " hash(x) per call: " << Register.get_per_call()
	 << " filled: " << Register.fill_factor() << "\n";
  }
#endif
  if (expand) {
#ifdef STATS
    reset_height(s);
#endif
    find_divergent(s);
    expand2pseudo(s, false);
#ifdef STATS
    cout << "Pseudominimal automaton:\n";
    cout << "Total states: " << s->get_total_states() << "\n";
    cout << "Total transitions: " << count_transitions(s, 0) << "\n";
#endif
  }
  return 0;
}//apply_method

#ifdef DEBUG
/* Name:	print_automaton
 * Class:	None.
 * Purpose:	Prints words in an automaton.
 * Parameters:	s	- (i) initial state.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	I wish Revuz has never invented his crap.
 *		It is already one week of debugging that shit.
 */
void
print_automaton(state *s, mystr &ss)
{
  if (s->is_final()) {
    cout << ss << "\n";
  }
  for (int i = 0; i < s->fan_out(); i++) {
    ss += s->get_transitions()[i].get_label();
    print_automaton(s->get_transitions()[i].get_target(), ss);
    ss.erase(ss.length()-1);
  }
}//print_automaton
#endif

#ifdef STATS
/* Name:	count_transitions
 * Class:	None.
 * Purpose:	Counts transitions in an automaton.
 * Parameters:	s		- (i) where to start;
 *		isum		- (i) initial sum.
 * Returns:	Sum of transitions in part of the automaton reachable from s.
 * Globals:	None.
 * Remarks:	Height is set to -2 to mark states.
 */
int
count_transitions(state *s, const int isum)
{
  if (s->get_height() == -2) {
    return 0;
  }
  s->set_height(-2);
  int sum = isum + s->fan_out();
  for (int i = 0; i < s->fan_out(); i++) {
    sum += count_transitions(s->get_transitions()[i].get_target(), 0);
  }
  return sum;
}//count_transitions
#endif

#ifdef HASH
/* Name:	dynamic_hash
 * Class:	None.
 * Space:	None.
 * Purpose:	Constructs a dynamic perfect hashing automaton.
 * Parameters:	input		- (i) input stream.
 * Returns:	The initial state of the automaton.
 * Globals:	None.
 * Remarks:	This automaton associates subsequent words with subsequent
 *		integer numbers. Transitions have weights. The sum of weights
 *		for a given word gives the word number.
 *		Note that the weights affect equivalence of states. We not
 *		only have to take the labels into account, but weights as well.
 *
 *		The automaton built from sorted data is minimal.
 */
state *
dynamic_hash(istream &input)
{
  mystr	input_line;
  state		*start = new state;
  vector<state *> path;
  int		wordno = 0;
#ifdef GRAPH
  int		charno = 0;
#endif

  Register.get_or_put(start);
  while (getline(input, input_line)) {
    path.clear();
    path.push_back(start);
    state *s = start;
    int l = input_line.length();
    int i = 0;
    state *p = NULL;
    int path_cost = 0;
    int surplus = 0;
    int unreg_from = -1;
    // Traverse the prefix
    while (i < l && (p = s->next(input_line[i])) != NULL) {
      int c = s->last_weight();
      path_cost += c;
      if (p->fan_in() > 1) {
	// Clone convergent states
	if (unreg_from == -1) {
	  // Changes propagate towards the initial state
	  unreg_from = i;
	  Register.remove(s);
	}
	s->set_next(input_line[i], p = new state(*p), c);
      }
      s = p;
      path.push_back(s);
      i++;
    }
    if (unreg_from == -1) {
      unreg_from = i;
      Register.remove(s);
    }
    // Create suffix
    surplus = wordno - path_cost;
    while (i < l) {
      s->set_next(input_line[i], new state, surplus);
      s = s->next(input_line[i]);
      path.push_back(s);
      surplus = 0;
      i++;
    }
    s->set_final();

    // Local minimization
    while (i >= unreg_from) {
      state *s1 = Register.get_or_put(path.back());
      if (s1 != path.back()) {
	if (i == unreg_from && i > 0) {
	  Register.remove(path[i-1]);
	  --unreg_from;
	}
	path[i-1]->set_next(input_line[i-1], s1, -1); // don't change the weight
      }
      else if (i == unreg_from) {
	break;
      }
      path.pop_back();
      --i;
    }
#ifdef GRAPH
    charno += input_line.length();
    cout << "Word " << wordno << " chars " << charno
	 << " states " << start->get_total_states() << "\n";
#endif
    wordno++;
  }
  //  repl_or_reg(start);
  return start;
}//dynamic_hash
#endif

enum state_type {regular, convergent, divergent, condivergent};

/* Name:	expand2pseudo
 * Class:	None.
 * Space:	None.
 * Purpose:	Exands a minimal automaton to a pseudo-minimal one.
 * Parameters:	start		- (i/o) start state of the minimal automaton.
 * Returns:	The start state of the pseudo-minimal automaton.
 * Globals:	None.
 * Remarks:	The automaton is assumed to be minimal before this function
 *		call.
 *		It is equally assumed that every word in the language
 *		of the automaton has one special symbol at its end.
 *		Function find_divergent must be run before expand2pseudo.
 *
 *		The symbol marks the end of the word. The consequence
 *		of this is that the automaton hash only one final state.
 *		An automaton is pseudo-minimal if it contains no path
 *		where a state with more than one outgoing transition
 *		follows a state with more than one incoming transition,
 *		or it contains a state with more than one incoming transition
 *		and more than one outgoing transition. In other words,
 *		each word in the language of the automaton has a transition
 *		in its path that is not shared with any other word.
 *
 *		The height is set to 1 if the right language contains
 *		more than one string, and 0 if less. It is set to -1 if
 *		the state was not marked using find_divergent.
 */
state *
expand2pseudo(state *start, bool was_convergent)
{
  trans_vec &tt = start->get_transitions();
  for (trans_vec::iterator ti = tt.begin(); ti != tt.end(); ti++) {
    state *t = ti->get_target();
    bool next_convergent = (was_convergent | (t->fan_in() > 1));
    if (next_convergent && t->get_height() == 1) {
      start->set_next(ti->get_label(), new state(*t));
    }
    expand2pseudo(ti->get_target(), next_convergent);
  }
  return start;
}//expand2pseudo

/* Name:	find_divergent
 * Class:	None.
 * Space:	None.
 * Purpose:	Set state height to 1 if the state or any other state reachable
 *		from it has more than one outgoing transition.
 * Parameters:	start		- (i/o) start from this state.
 * Returns:	1 if the right language of the state has more than one member,
 *		and false otherwise.
 * Globals:	None.
 * Remarks:	States not yet visited have height set to -1.
 */
int
find_divergent(state *start)
{
  bool divergent = (start->get_transitions().size() > 1);
  trans_vec &tv = start->get_transitions();
  for (trans_vec::iterator ti = tv.begin(); ti != tv.end(); ti++) {
    switch (ti->get_target()->get_height()) {

    case -1:
      divergent |= (find_divergent(ti->get_target()) == 1);
      break;

    case 0:
      break;

    case 1:
      divergent = 1;
      break;

    default:
      cerr << "Unsupported height in find_divergent\n";
    }
  }
  if (divergent) {
    start->set_height(1);
  }
  else {
    start->set_height(0);
  }
  return divergent;
}//find_divergent

/* Name:	reset_height
 * Class:	None.
 * Space:	None.
 * Purpose:	Sets the height feature of a state to -1
 *		in the whole automaton.
 * Parameters:	start		- (i/o) the starting state.
 * Returns:	Nothing.
 * Remarks:	This is needed because counting transitions uses height
 *		for marking, and we use it for marking states with
 *		the cardinality of the right language greater than 1.
 */
void
reset_height(state *start)
{
  if (start->get_height() != -1) {
    start->set_height(-1);
    trans_vec &tv = start->get_transitions();
    for (trans_vec::iterator ti = tv.begin(); ti != tv.end(); ti++) {
      reset_height(ti->get_target());
    }
  }
}//reset_height

/*	EOF adfa.cc	*/
