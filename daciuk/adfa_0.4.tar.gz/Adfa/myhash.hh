/*	myhash.hh	*/

/*	Copyright (C) Jan Daciuk, 2002	*/

#include	<vector>
#include	<set>

class hash_tab_full {};

/* Class:	hash_table
 * Purpose:	Implements a hash table.
 */
template<class T> class hash_table {
 private:
  vector<set<T>*>	table;
  T			empty;
  const int		filled;
#ifdef STATS
  int		calls;
  int		per_call;
  int		removals;
#endif
 public:
  hash_table(const int initial_size, const T invalid)
    : table(initial_size), empty(invalid), filled((initial_size * 3) / 3)
#ifdef STATS
    , calls(0), per_call(0), removals(0)
#endif
  {}
  T get_or_put(const T item);
  void remove(const T item);
#ifdef STATS
  float fill_factor(void) {
    int filled_cells = 0;
    for (typename vector<set<T>*>::iterator p = table.begin();
	 p != table.end(); p++) {
      if (*p != NULL) {
	filled_cells++;
      }
    }
    return 1.0 * filled_cells / table.size();
  }
  int get_calls(void) const { return calls; }
  float get_per_call(void) const {
    return calls ? 1.0 * per_call / calls : 0.0;
  }
  int get_removals(void) const { return removals; }
#endif
};

template<class T> int hash(/*const*/ T p);
template<class T> bool key_eq(/*const*/ T p1, const T p2);

/* Name:	get_or_put
 * Class:	hash_table<T>
 * Purpose:	Finds an item in a hash table, or puts it there.
 * Parameters:	item		- (i) item to be found or stored.
 * Returns:	Equivalent item if found, the item otherwise.
 * Globals:	None.
 * Remarks:	An equivalent item is searched for in the table.
 *		If it is found, get_or_put() returns it.
 *		If it is not found, the original item is stored in the table
 *		and returned.
 *		In both cases a unique representative of its abstraction
 *		class in the table is returned.
 */
template<class T>
T
hash_table<T>::get_or_put(const T item)
{
  int	curr_pos;
  typename set<T>::iterator f;
#ifdef STATS
  calls++;
#endif
  if (table[curr_pos = hash(item) % table.size()] == NULL) {
    table[curr_pos] = new set<T>;
    table[curr_pos]->insert(item);
    return item;
  }
  else if ((f = table[curr_pos]->find(item)) == table[curr_pos]->end()) {
#ifdef STATS
    per_call += table[curr_pos]->size();
#endif
    table[curr_pos]->insert(item);
    return item;
  }
  else {
#ifdef STATS
    per_call += table[curr_pos]->size();
#endif
    return *f;
  }
};//hash_table<T>::get_or_put

/* Name:	remove
 * Class:	hash_table<T>
 * Purpose:	Removes an item from the hash table.
 * Parameters:	item		- (i) item to be removed.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	None.
 */
template<class T>
void
hash_table<T>::remove(const T item)
{
#ifdef STATS
  per_call += table[hash(item) % table.size()]->size();
  removals += table[hash(item) % table.size()]->size();
#endif
  table[hash(item) % table.size()]->erase(item);
};//hash_table<T>::remove

/*	EOF myhash.hh	*/
