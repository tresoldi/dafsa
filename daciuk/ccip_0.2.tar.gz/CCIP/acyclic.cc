/***	acyclic.cc	***/

/*
  This file contains two algorithms for adding strings to cyclic
  finite-state automata:
  1. An algorithm by Rafael C. Carrasco and Mikel L. Forcada published
     in Computational Linguistics 28(2), June 2002. This algorithm
     is used when compile-time option CARFOR is defined, and
     the declaration Acyclic is used in the description of data.
  2. My generalized algorithm for sorted data. This algorithm is used
     when compile-time option SORTED is defined, and the declaration
     Acyclic is used in the description of data.
  3. The generalized algorithm for unsorted data, i.e. Carrasco
     and Forcada without the need to reprocess prefix states.
     This algorithm is used when compile-time option UNSORTED is defined,
     and the declaration Acyclic is used in the description of data.
*/

#ifdef SORTED
/* Name:	lcp
 * Class:	None.
 * Space:	None.
 * Purpose:	Finds the longest common prefix path of two words.
 * Parameters:	root		- (i) start state;
 *		w1		- (i) first word;
 *		w2		- (i) second word;
 *		len		- (o) length of the prefix.
 * Returns:	The last state in the longest common prefix path of two words.
 * Globals:	None.
 * Remarks:	None.
 */
inline state *
lcp(state *root, mystr &w1, mystr &w2, int &len)
{
  len = min(w1.length(), w2.length());
  state *s = root;
  state *q = NULL;
  for (int i = 0; i < len; i++) {
    if (w1[i] != w2[i] || (q = s->next(w1[i])) == NULL) {
      len = i;
      return s;
    }
    s = q;
  }
  return s;
}//lcp


/* Name:	minim_path
 * Class:	None.
 * Space:	None.
 * Purpose:	Minimizes a chain of states on a path of a word.
 * Parameters:	p		- (i) last state of the prefix;
 *		w		- (i) labels on the path to be minimized;
 *		l		- (i) length of the common prefix.
 * Returns:	Nothing.
 * Globals:	Register - (i/o) a set of unique states.
 * Remarks:	Contents of dictionary and cycle_{name,address}
 *		are disregarded.
 */
inline void
minim_path(state *p, mystr &w, const int l)
{
  static vector<state *> path;
  signed int i = l;
  state *q = p;
  for (; i < (signed int)(w.length()); i++) {
    path.push_back(q);
    q = q->next(w[i]);
  }
  path.push_back(q);
  for (i = path.size() - 1; i > 0; --i) {
    if ((q = Register.get_or_put(path[i])) != path[i]) {
      path[i - 1]->set_next(w[i + l - 1], q); //the state in path[i] is deleted
    }
  }
  path.clear();
}//minim_path

/* Name:	add_suffix
 * Class:	None.
 * Space:	None.
 * Purpose:	Adds a chain of states representing a suffix of a word
 *		to the specified state.
 * Parameters:	p		- (i) state to which the chain must be added;
 *		w		- (i) word whose suffix is to be added;
 *		l		- (i) length of the prefix.
 * Returns:	Nothing.
 * Globals:	Register - (i/o) set of unique states in the automaton.
 * Remarks:	Contents of variables dictionary and cycle_{name,address}
 *		are ignored.
 */
void
add_suffix(state *p, mystr &w, const int l)
{
  unsigned int i = l;
  state *q = p;
  state *r = NULL;
  // Follow existing path
  for (; i < w.length() && (r = q->next(w[i])) != NULL && r->fan_in() <= 1;
       i++) {
    q = r; Register.remove(r);
  }
  // Clone reentrant states if any
  for (; i < w.length() && (r = q->next(w[i])) != NULL; i++) {
    q->set_next(w[i], (r = new state(*(q->next(w[i])))));
    q = r;
  }
  // Add new states if any
  for (; i < w.length(); i++) {
    q->set_next(w[i], (r = new state));
    q = r;
  }
  q->set_final();
}//add_suffix

/* Name:	add_sorted
 * Class:	None.
 * Space:	None.
 * Purpose:	Adds a sequence of morphemes to the continuation class Root.
 * Parameters:	input		- (i) input stream;
 *		root		- (i) initial state of the automaton.
 * Returns:	The initial state of the automaton.
 * Globals:	Register	- (i/o) set of unique states.
 * Remarks:	Implements my generalized algorithm for sorted data.
 *		Called when declaration keyword Acyclic is recognized.
 *		The syntax is:
 *		<AcyclicDecl> ::= "Acyclic" ":" <Morpheme>... ";".
 *		The function is called after the keyword and the subsequent
 *		colon were read.
 *		Contents of variables dictionary and cycle_{name,address}
 *		are disregarded, except for the entry for root in dictionary.
 */
state *
add_sorted(istream &input, state *root)
{
  using namespace lex;

  if (root->fan_in() > 1) {	// 1 is for continuation class
    // Root has incoming transitions
    root = new state(*root);
  }
  mystr w_prim;
  state *p = NULL;
  int l = 0;
  symbol sym;
  while ((sym = get_symbol(input)) == morpheme) {
    mystr w = get_string(false);
#ifdef DEBUG
    cout << "    morpheme `" << w << "'\n";
    cout.flush();
#endif
    p = lcp(root, w, w_prim, l);
    minim_path(p, w_prim, l);
    add_suffix(p, w, l);
    w_prim = w;
#ifdef DETAILED_PROGRESS
    cout << "      states: " << root->get_total_states() << "\n";
#endif
  }
  minim_path(root, w_prim, 0);
  if ((p = Register.get_or_put(root)) != root) {
    delete root;
    root = p;
  }
  return root;
}//add_sorted
#endif

#ifdef CARFOR
/* Name:	carfor_add
 * Class:	None.
 * Space:	None.
 * Purpose:	Adds strings to a cyclic automaton using Carrasco-Forcada
 *		algorihtm.
 * Parameters:	input		- (i) input stream;
 *		root		- (i) initial state of the automaton.
 * Returns:	The initial state of the automaton.
 * Globals:	Register - (i) set of unique states in the automaton.
 * Remarks:	Called when declaration keyword Acyclic is recognized.
 *		The syntax is:
 *		<AcyclicDecl> ::= "Acyclic" ":" <Morpheme>... ";".
 *		The function is called after the keyword and the subsequent
 *		colon were read.
 *		Contents of variables dictionary and cycle_{name,address}
 *		are disregarded, except for the entry for root in dictionary.
 *		One loop from Carrasco & Forcada is implemented in two loops,
 *		as I don't have an absorption state.
 */
state *
carfor_add(istream &input, state *root)
{
  using namespace lex;

  vector<state *> path;
  symbol sym;
#ifdef DEBUG
  cout << "Adding acyclic morphemes\n";
  cout.flush();
#endif
  while ((sym = get_symbol(input)) == morpheme) {
    state *new_root = new state(*root);
    state *q_last = new_root;
    unsigned int i = 0;
    mystr w = get_string(false);
#ifdef DEBUG
    cout << "    morpheme `" << w << "'\n";
    cout.flush();
#endif
    state *r = NULL;
    path.clear();
    path.push_back(q_last);
    // Create cloned states
    for (; i < w.length() && (r = q_last->next(w[i])) != NULL; i++) {
      state *q = new state(*r);
      path.push_back(q);
      q_last->set_next(w[i], q);
      q_last = q;
    }
    // Create queue states
    for (; i < w.length(); i++) {
      state *q = new state;
      path.push_back(q);
      q_last->set_next(w[i], q);
      q_last = q;
    }
    q_last->set_final();
    state *q_curr = root;
    if (root->fan_in() == 0) {
      Register.remove(root);
      for (i = 0;
	   i < w.length() && ((q_curr = q_curr->next(w[i]))) &&
	     q_curr->fan_in() <= 1;
	   i++) {
	Register.remove(q_curr);
      }
      delete root;
    }
    for (i = path.size() - 1; i > 0; --i) {
      q_last = path[i];
      if ((r = Register.get_or_put(q_last)) != q_last) {
	path[i - 1]->set_next(w[i - 1], r);
      }
    }
    if ((r = Register.get_or_put(new_root)) != new_root) {
      delete new_root;
      new_root = r;
    }
    root = new_root;
#ifdef DETAILED_PROGRESS
    cout << "      states: " << root->get_total_states() << "\n";
#endif
  }
  if (sym != semicolon) {
    complain(sym, "Morpheme or semicolon expected");
    exit(1);
  }
  return root;
}//carfor_add
#endif

#ifdef UNSORTED
/* Name:	add_unsorted
 * Class:	None.
 * Space:	None.
 * Purpose:	Adds strings to a cyclic automaton using the Carrasco-Forcada
 *		algorithm with no unnnecessary cloning.
 * Parameters:	input		- (i) input stream;
 *		root		- (i) initial state of the automaton.
 * Returns:	The initial state of the automaton.
 * Globals:	Register - (i) set of unique states in the automaton.
 * Remarks:	Called when declaration keyword Acyclic is recognized.
 *		The syntax is:
 *		<AcyclicDecl> ::= "Acyclic" ":" <Morpheme>... ";".
 *		The function is called after the keyword and the subsequent
 *		colon were read.
 *		Contents of variables dictionary and cycle_{name,address}
 *		are disregarded, except for the entry for root in dictionary.
 */
state *
add_unsorted(istream &input, state *root)
{
  using namespace lex;

  vector<state *> path;
  symbol sym;
#ifdef DEBUG
  cout << "Adding acyclic morphemes\n";
  cout.flush();
#endif
  if (root->fan_in() > 1) {	// 1 for a continuation class
    root = new state(*root);
  }
  else {
    Register.remove(root);
  }
  state *q = NULL;
  // Add new strings
  while ((sym = get_symbol(input)) == morpheme) {
    unsigned int i = 0;
    mystr w = get_string(false);
#ifdef DEBUG
    cout << "    morpheme `" << w << "'\n";
    cout.flush();
#endif
    path.clear();
    state *p = root;
    //path.push_back(p);
    // Follow existing path
    for (; i < w.length() && (q = p->next(w[i])) != NULL && q->fan_in() <= 1;
	 i++) {
      path.push_back(p);
      p = q;
    }
    if (i > 0) {
      Register.remove(p);
    }
    unsigned int unreg_from = i;
    // Clone reentrant states
    for (; i < w.length() && (q = p->next(w[i])) != NULL; i++) {
      p->set_next(w[i], (q = new state(*q)));
      path.push_back(p);
      p = q;
    }
    // Add new states
    for (; i < w.length(); i++) {
      p->set_next(w[i], (q = new state));
      path.push_back(p);
      p = q;
    }
    path.push_back(p);
    p->set_final();
    for (i = path.size() - 1; i > 0; --i) {
      p = path[i];
      if ((q = Register.get_or_put(p)) != p) {
	if (i <= unreg_from && i > 1) {
	  Register.remove(path[i-1]);
	}
	path[i-1]->set_next(w[i-1], q);
      }
      else if (i < unreg_from) {
	break;
      }
    }//for
#ifdef DETAILED_PROGRESS
    cout << "      states: " << root->get_total_states() << "\n";
#endif
  }//while
  if (sym != semicolon) {
    complain(sym, "Morpheme or semicolon expected");
    exit(1);
  }
  if ((q = Register.get_or_put(root)) != root) {
    if (root->fan_in() <= 0) {
      delete root;
    }
    root = q;
  }
  return root;
}//add_unsorted
#endif //UNSORTED

#ifdef WATCYC
struct full_trans {
  state		*source;
  labelchar	label;
  state		*target;

  full_trans(state *s, labelchar l, state *t) : source(s), label(l), target(t)
  {}
};

vector<full_trans> Watstack;

void
build_stack(full_trans ini_tr);
full_trans
add_iter(mystr word, state *start);
void
remove_equiv(void);

/* Name:	add_watcyc
 * Class:	None.
 * Space:	None.
 * Purpose:	Adds strings to a cyclic automaton using a generalized
 *		semi-incremental Watson algorithm.
 * Parameters:	input		- (i) input stream;
 *		root		- (i) initial state of the automaton.
 * Returns:	The initial state of the automaton.
 * Globals:	Register - (i) set of unique states in the automaton.
 * Remarks:	Called when declaration keyword Acyclic is recognized.
 *		The syntax is:
 *		<AcyclicDecl> ::= "Acyclic" ":" <Morpheme>... ";".
 *		The function is called after the keyword and the subsequent
 *		colon were read.
 *		Contents of variables dictionary and cycle_{name,address}
 *		are disregarded, except for the entry for root in dictionary.
 */
state *
add_watcyc(istream &input, state *root)
{
  using namespace lex;
  symbol sym;
#ifdef DEBUG
  cout << "Adding acyclic morphemes\n";
  cout.flush();
#endif
  root = new state(*root);
  state *q = NULL;
  // Add new strings
  while ((sym = get_symbol(input)) == morpheme) {
    mystr w = get_string(false);
#ifdef DEBUG
    cout << "    morpheme `" << w << "'\n";
    cout.flush();
#endif
    build_stack(add_iter(w, root));
    remove_equiv();
  }
  if (sym != semicolon) {
    complain(sym, "Morpheme or semicolon expected");
    exit(1);
  }

  for (trans_vec::iterator p = root->get_transitions().begin();
       p != root->get_transitions().end(); p++) {
    if (!(p->get_target()->is_final()) && !(p->get_target()->fan_in() > 1)) {
      build_stack(full_trans(root, p->get_label(), p->get_target()));
      remove_equiv();
    }
  }

  if ((q = Register.get_or_put(root)) != root) {
    if (root->fan_in() <= 0) {
      delete root;
    }
    root = q;
  }
  return root;
}//add_watcyc

/* Name:	build_stack
 * Class:	None
 * Purpose:	Builds stack of states reachable from the given state.
 * Parameters:	init_tr		- (i) initial transition.
 * Returns:	Nothing.
 * Globals:	Watstack	- (i) stack of transitions on the path
 *				      of states considered for minimization.
 * Remarks:	None.
 */
void
build_stack(full_trans ini_tr)
{
  Watstack.push_back(ini_tr);
  state *s = ini_tr.target;
  trans_vec::iterator p = s->get_transitions().begin();
  for (int i = 0; i < s->fan_out(); i++, p++) {
    if (!(p->get_target()->is_final() || p->get_target()->fan_in() > 1)) {
      build_stack(full_trans(s, p->get_label(), p->get_target()));
    }
  }
}//build_stack

/* Name:	add_iter
 * Class:	None.
 * Purpose:	Adds a word to the automaton for Watson construction.
 * Parameters:	word		- (i) the word to be added;
 *		start		- (i) the initial state to which the word
 *					should be added.
 * Returns:	The last transition in the path of the word.
 * Globals:	None.
 * Remarks:	This is a modified version of the original.
 *		We need to check whether a state is confluence/reentrant.
 *		Those that are come from the pre-existing automaton.
 *		Note that there are no confluence/reentrant states among
 *		the newly created once, since add_iter() does not create
 *		them, and new confluence/reentrant states are created
 *		by remove_equiv() only at the end of paths at least as long
 *		as |w|. However, confluence/reentrant states can be
 *		on out-transitions from cloned states. Actually, since
 *		a cloned state has exactly the same transitions as
 *		an exisiting state, all targets of those transitions
 *		are confluence/reentrant. Encountering a confluence/reentrant
 *		state means we are moving into a pre-existing part
 *		of the automaton where all states are registered.
 *		We do not need to deregister them because we use the clones.
 */
full_trans
add_iter(mystr word, state *start)
{
  unsigned int i = 0;
  state *s = start;
  state *q;
  transition *last_trans = NULL;
  state *last_s = start;
  // Follow the common prefix in the newly created part of the automaton
  while (i < word.size() && (q = s->next(word[i])) &&
	 q->fan_in() < 2) {
    last_trans = s->find_trans(word[i]);
    last_s = s;
    s = q; i++;
  }
  // Follow the common prefix in the pre-existing part of the automaton
  while (i < word.size() && (q = s->next(word[i]))) {
    last_trans = s->find_trans(word[i]);
    last_s = s;
    state *q1 = new state(*q);
    s->set_next(word[i], q1);
    s = q1; i++;
  }
  // Add suffix
  while (i < word.size()) {
    state *s1 = new state;
    s->set_next(word[i], s1);
    last_trans = s->find_trans(word[i++]);
    last_s = s;
    s = s1;
  }
  s->set_final();
  return full_trans(last_s, last_trans->get_label(), s);
}//add_iter

/* Name:	remove_equiv
 * Class:	None.
 * Purpose:	Replaces redundant states with their equivalents.
 * Parameters:	None.
 * Returns:	Nothing.
 * Globals:	Watstack	- (i) stack of transitions on the path
 *				      of states considered for minimization.
 * Remarks:	None.
 */
void
remove_equiv(void)
{
  while (Watstack.size() > 0) {
    full_trans ft = Watstack.back();
    Watstack.pop_back();
    state *s = ft.target;
    state *r;
    if ((r = Register.get_or_put(s)) != s) {
      ft.source->set_next(ft.label, r);
    }
  }
}//remove_equiv
#endif //WATCYC
/***	EOF acyclic.cc	***/
