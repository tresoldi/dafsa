/***	ccip.cc		***/

/*	Copyright (c) Jan Daciuk, 2003		*/

/*	This is a compiler for continuation classes.

	A personal comment for the cyclic version:
	I wish software could be kicked. Especially this software.
 */

#include	<string>
#include	<iostream>
#include	<fstream>
#include	<vector>
#include	<map>
#include	<list>
#ifdef DMALLOC
#include	"dmalloc.h"
#endif
#ifdef MCHECK
#include	<mcheck.h>
#endif
#include	"myhash.hh"

using namespace std;

const int	CONTCL	= 0;	// continuation class
const int	CYCLIC	= 1;	// cyclic continuation class

const int	IS_FINAL = 1;	// state is final
const int	IS_CYCLIC = 2;	// state is a cyclic continuation class
const int	IS_MARKED = 4;	// state is marked
const int	IS_BLOCKED = 8;	// state cannot be deleted

typedef char mychar;		// the choice between short and wide chars
typedef basic_string<mychar> mystr;
#if defined(TRANSDUCER) || defined(NFA)
const mychar EPSILON = '\0';
#endif
#ifdef TRANSDUCER
const mychar EPS_PRINT = "_"; // printable version of epsilon
const mychar LEVEL_SEP = "/"; // level separator
typedef pair<mychar,mychar> charpair;
typedef charpair labelchar;	// type of label symbols (single or composite)
#else
typedef mychar labelchar;	// type of label symbols (single or composite)
#endif
typedef basic_string<labelchar> labelstr; // string of label symbols

#ifdef TRANSDUCER
const labelchar EMPTY_TRANS = charpair(EPSILON, EPSILON);
#else
#ifdef NFA
const labelchar EMPTY_TRANS = EPSILON;
#endif
#endif

#ifdef TRANSDUCER
ostream &
operator <<(ostream &s, const labelstr &ms)
{
  for (int i = 0; i < ms.length(); i++) {
    if (ms[i].first != EPSILON) {
      s << ms[i];
    }
  }
  s << " " << LEVEL_SEP << " ";
  for (int j = 0; j < ms.length(); j++) {
    if (ms[j].second != EPSILON) {
      s << ms[j];
    }
  }
  return s;
}//operator <<

ostream &
operator <<(ostream &s, const charpair &mc)
{
  s << (s.first == EPSILON ? EPS_PRINT : s.first) << " " << LEVEL_SEP
    << (s.second == EPSILON ? EPS_PRINT : s.second);
  return s;
}

/* Name:	make_label_string
 * Class:	None.
 * Space:	None.
 * Purpose:	Combines two morphemes to form a string on two levels.
 * Parameters:	w1		- (i) first morpheme;
 *		w2		- (i) second morpheme.
 * Returns:	A string combining both morphemes on two-levels.
 * Globals:	None.
 * Remarks:	The resulting strings consists of composed characters.
 *		One character comes from one word, the other one - from
 *		the other word. If the words have different length,
 *		the shorter word is padded with epsilons at the end.
 *		Words are passed by reference to avoid costly copying.
 */
labelstr
make_label_str(mystr &w1, mystr &w2)
{
  labelstr result;
  unsigned int m = min(w1.length(), w2.length());
  for (int i = 0; i < m; i++) {
    result.append(charpair(w1[i], w2[i]));
  }
  if (w1.length() > m) {
    for (int j = m; j < w1.length(); j++) {
      result.append(charpair(w1[j], EPSILON));
    }
  }
  else {
    for (int k = m; k < w2.length(); k++) {
      result.append(charpair(EPSILON, w2[j]));
    }
  }
  return result;
}
#endif //TRANSDUCER

namespace lex {
  const mychar COMMENT_CHAR = '#';
  const mychar INCLUDE_CHAR = '<';
  enum symbol {
    unrecognized, identifier, morpheme, colon, semicolon, comment,
    comma, left_brace, right_brace, end_of_description, minus
  };
  mystr input_buffer;
  unsigned int bufp = 0;
  unsigned int string_start = 0;
  int line_no = 0;
  unsigned int next_nonblank(void);
  symbol get_symbol(istream &input);
  mystr get_string(const bool is_id);
  void complain(const symbol sym, const mychar *messg);
};

class state;

#ifdef	WITH_CYCLES
set<state*>	to_be_dealt_with;
#endif



#ifdef WITH_CYCLES
// This shit seems to be necessary
void ensure_removed_from_register(state *s);
void delete_cyclic(state *q);
#endif

class transition {
  labelchar        label;
  state         *target;
public:
  transition(const mychar l, state *t) : label(l), target(t) {}
#if defined(WITH_CYCLES)
  transition(void) : label(0), target(0) {} // necessary because of resize!!!
#endif
  labelchar get_label(void) const { return label; }
  state *get_target(void) const { return target; }
  void set_target(state *t) { target = t; }
  bool operator==(const transition &t) const {
    return label == t.label && target == t.target;
  }
  bool operator<(const transition &t) const {
    return (label == t.label ? target < t.target : label < t.label);
  }
};

typedef vector<transition>      trans_vec;


class state {

protected:

  trans_vec     	out_trans;      // outgoing transitions
  int                   in_count;       // number of ingoing transitions
  char                  features;          // accepting state
  static int            total_states;   // number of states in the automaton
#if defined(GERTJAN)
  int			state_no; // state number
#endif
#ifdef STATS
  static int            max_states;     // max states during construction
#endif
#if defined(WITH_CYCLES)
  trans_vec		in_trans;	// incoming transitions
#endif

public:

  // Construct a state without transitions
  state(void) : in_count(0), features(0)
#if defined(GERTJAN)
    , state_no(-1)		// not set
#endif
  {
    total_states++;
#ifdef STATS
    if (total_states > max_states)
      max_states = total_states;
#endif
  }

  // Clone state
  state(const state &s) : out_trans(s.out_trans), in_count(0),
			  features(s.features)
#if defined GERTJAN
			  , state_no(-1)
#endif
  {
    unmark();
    for (trans_vec::iterator t = out_trans.begin();
         t != out_trans.end(); t++) {
      t->get_target()->hit();
#if defined(WITH_CYCLES)
      t->get_target()->set_prev(t->get_label(), this);
#endif
    }
    total_states++;
#ifdef STATS
    if (total_states > max_states)
      max_states = total_states;
#endif
  }

  // Destroy state and update in-transitions of other states
  // Note: other states are deleted if they no longer have in-transitions
  ~state(void) {
    for (trans_vec::iterator t = out_trans.begin();
         t != out_trans.end(); t++) {
      if (t->get_target()->hit(-1) == 0) {
#ifdef CHECK_REGISTER
	if (t->get_target()->fan_in() == -1) {
	  cerr << "Trying to delete an already deleted state\n";
	  exit(4);
	}
#endif
        delete t->get_target();
      }
#if defined(WITH_CYCLES)
      else {
	t->get_target()->rem_intrans(t->get_label(), this);
      }
#endif
    }
    --total_states;
#ifdef CHECK_REGISTER
    in_count = -1;
#endif
  }

  // True if the state is final, false otherwise
  bool is_final(void) const { return ((features & IS_FINAL) != 0); }

  // Mark the state as final
  void set_final(void) { features |= IS_FINAL; }

  // True if the state is marked with a special marker
  bool is_marked(void) const { return ((features & IS_MARKED) != 0); }

  // Mark the state with a special marker
  void mark(void) { features |= IS_MARKED; }

  // Remove a special marker from the state
  void unmark(void) { features &= ~IS_MARKED; }

#ifdef WITH_CYCLES
  // True if the state is marked as cyclic (representing a cyclic class)
  bool is_cyclic(void) const { return ((features & IS_CYCLIC) != 0); }

  // Mark the state as cyclic
  void set_cyclic(void) { features |= IS_CYCLIC; }

  // Remove cyclicity marker from the state
  void unset_cyclic(void) { features &= ~IS_CYCLIC; }

  // True if the state is blocked, false otherwise
  bool blocked(void) const { return ((features & IS_BLOCKED) != 0); }

  // Block the state
  void block(void) { features |= IS_BLOCKED; }

  // Remove the block from the state
  void unblock(void) { features &= ~IS_BLOCKED; }
#endif

  // Number of out-transitions
  int fan_out(void) const { return out_trans.size(); }

  // Number of in-transitions
  int fan_in(void) const { return in_count; }

  // Transitions
  trans_vec &get_transitions(void) { return out_trans; }
  const trans_vec &get_transitions(void) const { return out_trans; }

  // Change in-transitions counter
  int hit(const int i = 1) { return (in_count += i); }

  // Delta
  state *next(labelchar label) {
    for (trans_vec::iterator p = out_trans.begin();
         p != out_trans.end(); p++) {
      if (p->get_label() == label) {
        return p->get_target();
      }
    }
    return NULL;
  }

  // Delta star
  state *next(labelstr str) {
    state *q = this;
    for (unsigned int i = 0; i < str.length(); i++) {
      if ((q = q->next(str[i])) == NULL) {
	break;
      }
    }
    return q;
  }

  transition *find_trans(labelchar label) {
    for (trans_vec::iterator p = out_trans.begin();
         p != out_trans.end(); p++) {
      if (p->get_label() == label) {
        return &(*p);
      }
    }
    return NULL;
  }

  // Set delta
  void set_next(const labelchar label, state *target) {
    trans_vec::iterator p;
    target->hit();
    for (p = out_trans.begin();
         p != out_trans.end() && p->get_label() < label; p++)
      ;
    if (p != out_trans.end() && p->get_label() == label) {
      if (p->get_target() != target) {
	bool del = false;
	state *s;
	if ((s = p->get_target())->hit(-1) == 0) {
	  del = true;
	}
	p->set_target(target);
	if (del) {
	  delete s;
	}
#if defined(WITH_CYCLES)
	else {
	  s->rem_intrans(label, this);
	}
#endif
      }
      else {
	target->hit(-1);	// target has not changed, restore hit count
      }
    }
    else {
      out_trans.insert(p, transition(label, target));
    }
#if defined(WITH_CYCLES)
    target->set_prev(label, this);
#endif
  }

#ifdef NFA
  // Set delta for NFA - multiple transitions with the same label allowed
  // Returns target
  state *
  nfa_set_next(const labelchar label, state *target) {
    trans_vec::iterator p;
    target->hit();
    for (p = out_trans.begin();
         p != out_trans.end() && p->get_label() < label; p++) {
      if (p->get_label() == label && p->get_target() == target) {
	return target;
      }
    }
    out_trans.insert(p, transition(label, target));
#if defined(WITH_CYCLES)
    target->set_prev(label, this);
#endif
    return target;
  }
#endif

#if defined(WITH_CYCLES)
  // Add in-transition
  void set_prev(const labelchar label, state *source) {
    in_trans.push_back(transition(label, source));
  }

  // Remove in-transition
  void rem_intrans(const labelchar label, state *source) {
#ifdef CHECK_REGISTER
    bool transition_found = false;
#endif
    for (unsigned int i = 0; i < in_trans.size(); i++) {
      if (in_trans[i].get_label() == label &&
	  in_trans[i].get_target() == source) {
#ifdef CHECK_REGISTER
	transition_found = true;
#endif
	for (unsigned int j = i; j < in_trans.size() - 1; j++) {
	  in_trans[j] = in_trans[j+1];
	}
	break;
      }
    }
#ifdef CHECK_REGISTER
    if (!transition_found) {
      cerr << "Trying to remove a non-existing in-transition!!!\n";
      exit(4);
    }
#endif
    in_trans.resize(in_trans.size()-1);
  }

  // Return in-transitions
  trans_vec &get_intransitions(void) { return in_trans; }
#endif
#ifdef STATS
  int get_max_states(void) const { return max_states; }
#endif
#if defined(STATS) || defined(WITH_CYCLES) || defined(GERTJAN)
  int get_total_states(void) const {return total_states; }
#endif
#if defined(GERTJAN)
  int get_state_no(void) const { return state_no; }
  void set_state_no(const int n) { state_no = n; }
#endif
#ifdef CHECK_REGISTER
  // Return true if state in inconsistent state
  bool check_state(void) {
    if (in_count < 0 || features < 0 || out_trans.size() > 256)
      return true;
    for (trans_vec::iterator it = in_trans.begin(); it != in_trans.end();
	 it++) {
      if (it->get_target()->next(it->get_label()) != this) {
	long int l = (long int)this;
	long int l2 = (long int)(it->get_target());
	long int l3 = (long int)(it->get_target()->next(it->get_label()));
	cerr << "Trouble: " << l << " (" << hex << l << dec << ") has <-("
	     << it->get_label() << ", " << l2 << " (" << hex << l2 << dec
	     << ") ), but " << l2 << " has ->(" << it->get_label() << ", "
	     << l3 << " (" << hex << l3 << ") ).\n";
	return true;
      }
    }
    return false;
  }
#endif
};//class state

#ifdef WITH_CYCLES
typedef pair<state*,state*>	state_pair;
#endif

#ifdef STATS
int state::max_states = 0;
#endif

map<state*,set<int>*> cycle_number;// state to class number mapping

//class gen_print_state {
//private:
//  const state *s;
//public:
//  gen_print_state(const state *ss) : s(ss) {};
//};//gen_print_state



/* Name:	key_less
 * Class:	None.
 * Space:	None.
 * Purpose:	Checks whether first state precedes the second one
 *		in our ordering.
 * Parameters:	p1		- (i) first state;
 *		p2		- (i) second state.
 * Result:	True if p1 precedes p1, false otherwise.
 * Globals:	cycle_number	- (i) maps states to cyclic class numbers.
 * Remarks:	None.
 */
template<> bool
key_less(/*const*/ state *p1, /*const*/ state *p2)
{
  if (p1->is_final() == p2->is_final()) {
#ifdef WITH_CYCLES
    if (p1->is_cyclic() == p2->is_cyclic()) {
      if (p1->is_cyclic() && p2->is_cyclic()) {
	if (!(*(cycle_number[(state *)p1]) == *(cycle_number[(state *)p2]))) {
	  return (*(cycle_number[(state *)p1]) < *(cycle_number[(state *)p2]));
	}
      }
#endif
      if (p1->fan_out() == p2->fan_out()) {
	return (p1->get_transitions() < p2->get_transitions());
      }
      else {
	return p1->fan_out() < p2->fan_out();
      }
#ifdef WITH_CYCLES
    }
    else {
      return p1->is_cyclic() < p2->is_cyclic();
    }
#endif
  }
  else {
    return p1->is_final() < p2->is_final();
  }
}//key_less

class hash_pointer {
public:
  state		*p;
  hash_pointer(state *s) : p(s) {}
  bool operator==(hash_pointer &s) { return key_eq(p, s.p); }
  bool operator <(const hash_pointer &s) const { return key_less(p, s.p); }
  bool operator <(hash_pointer &s) { return key_less(p, s.p); }
    /*const {
    if (p->is_final() == s.p->is_final()) {
#ifdef WITH_CYCLES
      if (p->is_cyclic() == s.p->is_cyclic()) {
#endif
	if (p->fan_out() == s.p->fan_out()) {
	  return (p->get_transitions() < s.p->get_transitions());
	}
	else {
	  return p->fan_out() < s.p->fan_out();
	}
#ifdef WITH_CYCLES
      }
      else {
	return p->is_cyclic() < s.p->is_cyclic();
      }
#endif
    }
    else {
      return p->is_final() < s.p->is_final();
    }
    }*/
  operator state *(void) { return p; }
};

#if defined(PRINT_DICT) || defined(PRINT_AUT)
ostream &
operator <<(ostream &s, const hash_pointer &hp)
{
  long int l = (long int)(hp.p);
  s << dec << l << "(" << hex << l << dec << ")";
  return s;
}//operator <<
#endif

int state::total_states = 0;
hash_table<hash_pointer>        Register(10001, NULL);

/* Name:	ensure_removed_from_register
 * Class:	None.
 * Space:	None.
 * Purpose:	Makes sure the state is not in the register
 * Parameters:	s		- (i) state to be removed from the register.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	Cyclicity sucks!
 */
void
ensure_removed_from_register(state *s)
{
  if (Register.get_or_put(s) == s) {
    Register.remove(s);
  }
}

/* Specializations of functions from templates */


/* Name:	hash
 * Class:	None (specialization of a template).
 * Purpose:	Computes hash function for a pointer to state.
 * Parameters:	p	- (i) wrapper around pointer to state.
 * Returns:	Hash function.
 * Globals:	None.
 * Remarks:	Specialization of a template.
 */
int
hash(const hash_pointer p)
{
#ifdef CHECK_REGISTER
  // Although this is checked in remove(), a function call can change it
  if (p.p->check_state()) {
    long int l = (long int)p.p;
    cerr << "Trouble: state " << l <<  "(" << hex << l << dec
	 << ") used but deleted\n";
    exit(4);
  }
#endif
  int sum = p.p->is_final();
  vector<transition>::iterator t = p.p->get_transitions().begin();
  for (int i = 0; i < p.p->fan_out(); i++) {	/*!*/
    sum += (t->get_label()*7 + ((long(t->get_target())>>2)*101)) * (11 + 2*i);
  }
  return sum;
}//hash


#ifdef WITH_CYCLES
/***	Global variables	***/
//map<state*,set<mystr>*> cycle_name;// state to cont. classes mapping
//map<mystr,set<state*>*> cycle_addr;// cont. class name to state addrs mapping
vector<set<state*>*> cycle_addr;// class number to state addrs mapping
map<mystr,int> class_number;	// class name to class number mapping
vector<mystr> cycle_name;	// class name to class number mapping
set<state *> *unproc_cycle_addr; // states from cycle_addr that
				// need to be processed by adding a morpheme
string current_class;		// current continuation class name
int current_class_no;		// current cyclic continuation class number
set<state *> already_deleted;	// set of states deleted in redirection
#endif

/* Name:	key_eq
 * Class:	None.
 * Space:	None.
 * Purpose:	Checks equality of two states.
 * Parameters:	p1		- (i) first state;
 *		p2		- (i) second state.
 * Result:	true if p1 = p2, false otherwise.
 * Globals:	cycle_number	- (i) maps states to cyclic class numbers.
 * Remarks:	None.
 */
bool
key_eq(/*const*/ state *p1, /*const*/ state *p2)
{
  if (p1->fan_out() != p2->fan_out() || p1->is_final() != p2->is_final()) {
    return false;
  }
#ifdef WITH_CYCLES
  if (p1->is_cyclic() != p2->is_cyclic()) {
    return false;
  }
  if (p1->is_cyclic() && p2->is_cyclic()) {
    // See if they belong to the same classes
    if (!(cycle_number[p1] == cycle_number[p2])) {
      return false;
    }
  }
#endif
  return equal(p1->get_transitions().begin(), p1->get_transitions().end(),
	       p2->get_transitions().begin());
}//key_eq




#ifdef PRINT_DICT
void print_dict(ostream &outp, map<mystr,pair<state *,int> > &dict);
#ifdef WITH_CYCLES
void print_cycles(ostream &outp);
#endif
#endif
#if defined(NFA)|defined(MINIMIZE)
state *
minimize(vector<state *> &states);
#endif


/* Name:	next_nonblank
 * Class:	None.
 * Space:	lex
 * Purpose:	Moves the buffer pointer to the next non-blank non-comment
 *		character.
 * Parameters:	None.
 * Returns:	Current buffer pointer.
 * Globals:	input_buffer	- (i) holds last line read from input;
 *		bufp		- (i/o) buffer pointer.
 * Remarks:	Works only on the buffer, does not read from input.
 */
unsigned int
lex::next_nonblank(void)
{
//  cerr << input_buffer << "\n" << string(bufp, ' ') << "^<next_nonblank\n";
  while (bufp < input_buffer.size() &&
	 (isspace(input_buffer[bufp]) || input_buffer[bufp] == COMMENT_CHAR )){
    if (input_buffer[bufp] == COMMENT_CHAR ) {
      bufp = input_buffer.size();
    }
    else {
      bufp++;
    }
  }
//  cerr << input_buffer << "\n" << string(bufp, ' ') << "^>next_nonblank\n";
  return bufp;
}//lex::next_nonblank

/* Name:	get_symbol
 * Class:	None.
 * Space:	lex
 * Purpose:	Gets next symbol from input.
 * Parameters:	input		- (i) input stream.
 * Returns:	Symbol identifier.
 * Globals:	input_buffer	- (i/o) holds last line read from the input;
 *		bufp		- (i/o) buffer pointer;
 *		string_start	- (o) start of morpheme or name.
 * Remarks:	Morpheme name starts right after double quote.
 */
lex::symbol
lex::get_symbol(istream &input)
{
//  cerr << input_buffer << "\n" << string(bufp, ' ') << "^<get_symbol\n";
#ifdef ENABLE_INCLUDE
  static vector<ifstream *> iv;
  static vector<mystr> ivn;
#endif
  while (next_nonblank() >= input_buffer.size()) {
    istream &inp =
#ifdef ENABLE_INCLUDE
      (iv.size() == 0) ?
#endif
      input
#ifdef ENABLE_INCLUDE
      : *(iv.back())
#endif
      ;
    while (next_nonblank() >= input_buffer.size() &&
	   getline(inp, input_buffer)) {
//      cerr << "Read:\n";
//      cerr << input_buffer << "\n";
      line_no++;
      bufp = 0;
    }
#ifdef ENABLE_INCLUDE
    if (input_buffer[0] == INCLUDE_CHAR) {
      // Include directive
      for (bufp = 1; bufp < input_buffer.size() && isspace(input_buffer[bufp]);
	   bufp++)
	;
      for (string_start = bufp; bufp < input_buffer.size()
	     && !isspace(input_buffer[bufp]); bufp++)
	;
      if (bufp <= string_start) {
	cerr << "Include directive without file name:\n"
	     << ((iv.size() == 0) ? mystr("") : ivn.back())
	     << " " << line_no << ":\n"
	     << input_buffer << "\n"
	     << mystr(" ", string_start) << "^ here\n";
	exit(1);
      }
      ivn.push_back(mystr(input_buffer,string_start, bufp - string_start));
      ifstream *ifp = new ifstream(ivn.back().c_str());
      if (*ifp) {
	iv.push_back(ifp);
      }
      else {
	delete ifp;
	cerr << "Cannot open include file " << ivn.back() << ":\n";
	ivn.pop_back();
	cerr << ((iv.size() == 0) ? mystr("") : ivn.back())
	     << " " << line_no << ":\n" << input_buffer << "\n"
	     << mystr(" ", string_start) << "^ here\n";
	exit(1);
      }
    }
    else
#endif
    if (next_nonblank() >= input_buffer.size()) {
#ifdef ENABLE_INCLUDE
      if (iv.size() == 0) {
#endif
	return end_of_description;
#ifdef ENABLE_INCLUDE
      }
      else {
	cerr << "Closing " << ivn.back() << "\n";
	iv.back()->close();
	delete iv.back();
	iv.pop_back();
	ivn.pop_back();
      }
#endif
    }
  }
  switch (input_buffer[bufp]) {

  case ':':
    bufp++;
    return colon;

  case ';':
    bufp++;
    return semicolon;

  case '{':
    bufp++;
    return left_brace;

  case '}':
    bufp++;
    return right_brace;

#ifdef DELETE
  case '-':
    bufp++;
    return minus;
#endif

  case '"':
    for (string_start = ++bufp;
	 bufp < input_buffer.size() && input_buffer[bufp] != '"'; bufp++)
      ;
    if (bufp >= input_buffer.size()) {
      cerr << "No matching double quote in the same line for the one:\n"
	   << line_no << ":\n"
	   << input_buffer << "\n"
	   << string(" ", string_start) << "^ here\n";
      exit(1);
    }
    if (input_buffer[bufp] == '"') {
      bufp++;
      return morpheme;
    }
    else {
      cerr << "No matching double quote in the same line for the one:\n"
	   << line_no << ":\n"
	   << input_buffer << "\n"
	   << mystr(" ", string_start) << "^ here\n";
      exit(1);
    }

  default:
    if (isalpha(input_buffer[bufp]) && true) {
//      cerr << "Line is:\n" << input_buffer << "\nbufp is " << bufp << "\n";
      // I should put a check on characters with diacritics instead of true
      for (string_start = bufp;
	   bufp < input_buffer.size() &&
	     (isalnum(input_buffer[bufp]) || input_buffer[bufp] == '_')
	     && true;
	   bufp++)
	;
      return identifier;
    }
    return unrecognized;
  }
}//lex::get_symbol

/* Name:	get_string
 * Class:	None.
 * Space:	lex
 * Purpose:	Returns a string being either a morpheme or an identifier.
 * Parameters:	is_id		- (i) true if identifier, false otherwise.
 * Returns:	The string representing either a morpheme or an identifier.
 * Globals:	string_start	- (i) pointer to start of the identifier
 *					in input buffer;
 *		bufp		- (i) buffer pointer.
 * Remarks:	In case of morphemes:
 *		the string between double quotes is returned (without quotes),
 *		bufp points after the closing double quote.
 */
mystr
lex::get_string(const bool is_id)
{
  return string(input_buffer, string_start,
		bufp - string_start - (is_id ? 0 : 1));
}//lex::get_string

/* Name:	complain
 * Class:	None.
 * Space:	lex
 * Purpose:	Prints an error message along with a source line.
 * Parameters:	sym		- (i) last symbol read;
 *		messg		- (i) message to be printed.
 * Returns:	Nothing.
 * Globals:	string_start	- (i) start of last string in buffer;
 *		input_buffer	- (i) input buffer (one line);
 *		bufp		- (i) buffer pointer (points after the last
 *					symbol)
 *		line_no		- (i) source line number.
 * Remarks:	The output is on standard error.
 */
void
lex::complain(const symbol sym, const mychar *messg)
{
  cerr << "string_start is " << string_start << ", bufp is " << bufp << "\n";
  int pos = (sym == identifier || sym == morpheme) ? string_start : bufp - 1;
  int len = 0;
  for (int i = 0; i < pos; i++) {
    if (input_buffer[i] == '\t') {
      len = ((len / 8) + 1) * 8;
    }
    else {
      len++;
    }
  }
  mystr p = mystr(len, ' ');
  cerr << "ccip: " << messg << "\n"
       << line_no << ":\n"
       << input_buffer << "\n"
       << p << "^ here\n";
}//complain

#ifdef WITH_CYCLES
/* Name:	delete_cyclic
 * Class:	None.
 * Space:	None.
 * Purpose:	Removes a state from cycle_number, cycle_addr,
 *		and unproc_cycle_addr.
 * Parameters:	q		- (i) state to be removed.
 * Returns:	Nothing.
 * Globals:	cycle_number	- (i/o) cyclic state to class number mapping;
 *		cycle_addr	- (i/o) cyclic class number to states mapping;
 *		unproc_cycle_addr
 *				- (i/o) unprocessed states from cycle_addr;
 *		current_class	- (i) current continuation class name.
 * Remarks:	None.
 */
void
delete_cyclic(state *q)
{
  if (q->is_cyclic()) {
    // Delete q from cycle_number, cycle_addr, and unproc_cycle_addr
    if (cycle_number.find(q) == cycle_number.end())
      return;
    set<int> *ms1 = cycle_number[q];
    if (ms1 == NULL)
      return;
    for (set<int>::iterator dp = ms1->begin(); dp != ms1->end();
	 dp++) {
      if (*dp == current_class_no) {
	if (unproc_cycle_addr) {
	  set<state*>::iterator dp2 = unproc_cycle_addr->find(q);
	  if (dp2 != unproc_cycle_addr->end()) {
	    unproc_cycle_addr->erase(dp2);
	  }
	  else {
	    cycle_addr[*dp]->erase(q);
	  }
	}
	else {
	  cycle_addr[*dp]->erase(q);
	}
      }
      else {
	cycle_addr[*dp]->erase(q);
      }
    }
    delete cycle_number[q];
    cycle_number.erase(q);
    q->unset_cyclic();
  }
}//delete_cyclic

/* Name:	add_cyclic
 * Class:	None.
 * Space:	None.
 * Purpose:	Adds a state to cyclic dictionaries.
 * Parameters:	s		- (i) the state to be added;
 *		m		- (i) model state.
 * Returns:	Nothing.
 * Globals:	cycle_number	- (i/o) cyclic state to class number mapping;
 *		cycle_addr	- (i/o) cyclic class number to states mapping;
 *		unproc_cycle_addr
 *				- (i/o) unprocessed states from cycle_addr.
 * Remarks:	The state m should be cyclic.
 */
void
add_cyclic(state *s, const state *m)
{
  if (s->is_cyclic()) {
    if (m->is_cyclic()) {
      map<state*,set<int>*>::iterator mp1 = cycle_number.find((state *)m);
      set<int> *sp1 = mp1->second;
      for (set<int>::iterator i1 = sp1->begin(); i1 != sp1->end(); i1++) {
	if (*i1 == current_class_no) {
	  if (unproc_cycle_addr->find(s) == unproc_cycle_addr->end()) {
	    unproc_cycle_addr->insert(s);
	  }
	}
	else {
	  set<state *> *sp = cycle_addr[*i1];
	  if (sp->find(s) == sp->end()) {
	    sp->insert(s);	// cycle_addr[*i1]->insert(s);
	  }
	}
	if ((mp1 = cycle_number.find(s)) == cycle_number.end()
	    || mp1->second == NULL) {
	  cycle_number[s] = new set<int>;
	}
	cycle_number[s]->insert(*i1);
      }
#ifdef COUNT_CYCLIC
#endif
    }
    else {
      cerr << "Non-cyclic state " << m << " (" << hex << m << dec
	   << " given as a model cyclic state\n";
    }
  }
}//add_cyclic
#endif

bool closing_cycles_phase = false;
#ifdef WITH_CYCLES
map<state_pair,state *> union_stack;
set<state *> union_set;
#endif


/* Name:	state_union
 * Class:	None.
 * Space:	None.
 * Purpose:	Constructs a union of two automata.
 * Parameters:	s1		- (i) start state of the first automaton;
 *		s2		- (i) start state of the second automaton.
 * Returns:	The start state of the resulting automaton.
 * Globals:	cycle_addr	- (i/o) cyclic class to states mapping;
 *		cycle_name	- (i/o) cyclic state to class mapping;
 *		unproc_cycle_addr
 *				- (i/o) unprocessed states from cycle_addr;
 *		current_class	- (i) current continuation class name.
 * Remarks:	None.
 */
state *
state_union(const state *s1, const state *s2)
{
//#ifdef PRINT_DICT
//	cout << "Before union:\n";
//	print_cycles(cout);
//#endif
#if defined(WITH_CYCLES)
  state *s;
  state_pair minmax;
  minmax = state_pair(min((state *)s1, (state *)s2),
		      max((state *)s1, (state *)s2));
  map<state_pair,state *>::iterator usp;
  if ((usp = union_stack.find(minmax)) != union_stack.end()) {
    return usp->second;
  }
  s = new state(*s1);
  union_stack[minmax] = s;
  union_set.insert(s);
#else
  state *s = new state(*s1);
#endif //!WITH_CYCLES
  state *q = NULL;
  if (s2->is_final()) {
    s->set_final();
  }
#ifdef WITH_CYCLES
  if (s2->is_cyclic()) {
    s->set_cyclic();
  }
  if (s->is_cyclic()) {
    // Insert s into cycle_name, cycle_addr, and unproc_cycle_addr
//    add_cyclic(s, s2);
    if (s2->is_cyclic()) {
	map<state*,set<int>*>::iterator mp1 = cycle_number.find((state *)s2);
	set<int> *sp1 = mp1->second;
	for (set<int>::iterator i1 = sp1->begin(); i1 != sp1->end(); i1++) {
	  set<state*> *p1 = cycle_addr[*i1];
	  if (*i1 == current_class_no && p1->find((state *)s1) == p1->end() &&
	      p1->find((state *)s2) == p1->end()) {
	    unproc_cycle_addr->insert(s);
	  }
	  else {
	    cycle_addr[*i1]->insert(s);
	  }
	  if (cycle_number.find(s) == cycle_number.end()) {
	    cycle_number[s] = new set<int>;
	  }
	  cycle_number[s]->insert(*i1);
	}
    }
    if (s1->is_cyclic()) {
      map<state*,set<int>*>::iterator mp2 = cycle_number.find((state *)s1);
      set<int> *sp2 = mp2->second;
      for (set<int>::iterator i2 = sp2->begin(); i2 != sp2->end(); i2++) {
	set<state*> *p2 = cycle_addr[*i2];
	if (*i2 == current_class_no && p2->find((state *)s1) == p2->end() &&
	    p2->find((state *)s2) == p2->end()) {
	  if (unproc_cycle_addr->find((state *)s) == unproc_cycle_addr->end()){
	    unproc_cycle_addr->insert(s);
	  }
	}
	else {
	  if (p2->find(s) == p2->end()) {
	    p2->insert(s);
	  }
	}
	map<state*,set<int>*>::iterator mp4 = cycle_number.find(s);
	if (mp4 == cycle_number.end()) {
	  cycle_number[s] = new set<int>;
	  cycle_number[s]->insert(*i2);
	}
	else if (mp4->second->find(*i2) == mp4->second->end()) {
	  mp4->second->insert(*i2);
	}
      }
    }
  }
#endif //WITH_CYCLES
  for (int i = 0; i < s2->fan_out(); i++) {
    const transition &tr = s2->get_transitions()[i];
    if ((q = s->next(tr.get_label())) == NULL) {
      s->set_next(tr.get_label(), tr.get_target());
    }
    else if (q != tr.get_target()) {
      state *q1 = state_union(q, tr.get_target());
      if (q->fan_in() <= 1 && q != q1) {
	Register.remove(q);
#ifdef WITH_CYCLES
	delete_cyclic(q);
#endif
      }
// #if defined(WITH_CYCLES) && !defined(EARLY_START)
//       if (closing_cycles_phase && union_set.find(q1) != union_set.end()) {
// 	// Do not replace with equivalent, as it will still be modified
//       }
//       else
// #endif
      if ((q = Register.get_or_put(q1)) != q1) {
#ifdef WITH_CYCLES
	if (union_set.find(q1) == union_set.end()) {
	  delete_cyclic(q1);
	  delete q1;
	}
#else
	delete q1;
#endif//!WITH_CYCLES
	q1 = q;
      }
      s->set_next(tr.get_label(), q1);
    }
  }
//#ifdef PRINT_DICT
//	cout << "After union:\n";
//	print_cycles(cout);
//#endif
#if defined(WITH_CYCLES)
  union_stack.erase(minmax);
  union_set.erase(s);
#endif
  return s;
}//state_union

/* Name:	add_if_different_unreg
 * Class:	None.
 * Space:	None.
 * Purpose:	Compares two states, and if the first one contains transitions
 *		not present in the second one, they are added to the second.
 * Parameters:	s1		- (i) first state;
 *		s2		- (i/o) second state.
 * Returns:	The second state with new transitions if needed.
 * Globals:	Register	- (i/o) set of unique states.
 * Remarks:	s2 cannot be registered.
 *		Adding may result in state unions, and s2 is marked
 *		to prevent being updated twice.
 */
state *
add_if_different_unreg(const state *s1, state *s2)
{
//#ifdef PRINT_DICT
//  cout << "add_if_different\n";
//  print_cycles(cout);
//  cout.flush();
//#endif
  if (s2->is_marked()) {
    // Well, it's a cyclic automaton, and we're back at square one
    return s2;
  }
  s2->mark();
  if (key_eq((state *)s1, s2)) {
    return s2;
  }
  for (int i = 0; i < s1->fan_out(); i++) {
    const transition &tt = s1->get_transitions()[i];
    mychar c = tt.get_label();
    if (s2->next(c) != tt.get_target()) {
      if (s2->next(c) == NULL) {
	s2->set_next(c, tt.get_target());
      }
      else {
	closing_cycles_phase = true;
	state *q = state_union(s2->next(c), tt.get_target());
	closing_cycles_phase = false;
	state *r;
	if ((r = Register.get_or_put(q)) != q) {
#ifdef WITH_CYCLES
	  delete_cyclic(q);
#endif
	  delete q;
	}
	if (s2->next(c)->fan_in() <= 1) {
	  Register.remove(s2->next(c));
#ifdef WITH_CYCLES
	  delete_cyclic(s2->next(c));
#endif
	}
	s2->set_next(c, r);
      }
    }
  }
  s2->unmark();
  return s2;
}//add_if_different_unreg


#if defined(WITH_CYCLES)
/* Name:	tracked_delete
 * Class:	None.
 * Space:	None.
 * Purpose:	Deletes a state, and all states that are reachable only
 *		from this state, taking care of the register, cyclic
 *		structures, etc., and records deleted states.
 * Parameters:	s		- (i) the state to be deleted.
 * Returns:	Nothing.
 * Globals:	already_deleted	- (o) states deleted here.
 * Remarks:	None.
 */
void
tracked_delete(state *s)
{
  if (already_deleted.find(s) == already_deleted.end()) {
    ensure_removed_from_register(s); // done in delete(s)
    if (s->is_cyclic()) {
      delete_cyclic(s);
      s->unset_cyclic();
    }
    already_deleted.insert(s);
    trans_vec &tr = s->get_transitions();
    for (trans_vec::iterator t = tr.begin(); t!= tr.end(); t++) {
      t->get_target()->rem_intrans(t->get_label(), s);
      if (t->get_target()->hit(-1) == 0) {
	tracked_delete(t->get_target());
      }
    }
    s->get_transitions().clear();
#ifdef WITH_CYCLES
    if (to_be_dealt_with.find(s) != to_be_dealt_with.end()) {
      to_be_dealt_with.erase(s);
    }
#endif
    delete s;
  }
}//tracked_delete

/* Name:	redirect
 * Class:	None.
 * Space:	None.
 * Purpose:	Redirects all transitions leading to one state to another one.
 * Parameters:	s		- (i/o) state with incoming transitions;
 *		t		- (i/o) state where those transitions should
 *					go to.
 * Returns:	Nothing.
 * Globals;	None.
 * Remarks:	This could be implemented efficiently only with
 *		backtransitions.
 *		Redirecting transitions from s to t does not change
 *		hash function for either s or t unless they have transitions
 *		pointing to each other or pointing to themselves.
 *		State s should not be in the register, because otherwise
 *		it might become itself the target for a redirection.
 */
void
redirect(state *s, state *t)
{
#ifdef CHECK_REGISTER
  if (s->check_state()) {
    long l = (long int)s;
    cerr << "Trouble while redirecting " << l << " - state already deleted\n";
    exit(4);
  }
#endif
  if (s == t) {
    return;
  }
  s->hit();			// protect it from being deleted by set_next
  trans_vec &it = s->get_intransitions();
  // For each transition coming to the source state of the redirection
  // unregister its source, change its target to the target
  // of the redirection, and reregister it
  for (trans_vec::reverse_iterator ti = it.rbegin(); ti != it.rend();
       ti = it.rbegin()) {
    state *source = ti->get_target();
    state *r;
    // Ensure source is in the register before attempting to remove
    // the state from the register
    if ((r = Register.get_or_put(source)) == source) {
      // target might have been removed from the register,
      // and an equivalent state in the register prevents its reregistering
      Register.remove(source);
    }
    source->set_next(ti->get_label(), t);
    if (to_be_dealt_with.find(source) == to_be_dealt_with.end() &&
	source != s) {
      to_be_dealt_with.insert(source);
    }
  }
  delete_cyclic(s);
  s->hit(-1);			// remove protection
  // It cannot be simply delete, as we must keep track of deleted states
  tracked_delete(s);
  // delete s;
  for (set<state*>::iterator tbdw = to_be_dealt_with.begin();
       tbdw != to_be_dealt_with.end(); tbdw = to_be_dealt_with.begin()) {
    state *source1 = *tbdw;
    state *r1;
    to_be_dealt_with.erase(source1);
    if ((r1 = Register.get_or_put(source1)) != source1) {
      redirect(source1, r1);
    }
  }
}//redirect

typedef list<state_pair>	plist;

struct pstruct {
  int		level;		// recursion depth
  state_pair	repr;		// representative pair
  plist		deps;		// dependencies
};

vector<state_pair>	pair_stack; // pairs under examination
set<state_pair>		ineq;	// pairs found to be inequivalent
set<state_pair>		eq_pairs; // equivalent pairs
vector<pstruct*>	dep_pointers; // dependency info on representatives
map<state_pair,pstruct*>possibly_eq; // dependency info on dependants
unsigned int result_conclusive = 0;

/* Name:	equiv_pair
 * Class:	None.
 * Space:	None.
 * Purpose:	Finds out if a pair of states is equivalent and deletes
 *		one of the states if yes.
 * Parameters:	s1		- (i/o) first state;
 *		s2		- (i/o) second state;
 *		level		- (i) recursion level.
 * Returns:	True if states equivalent, false otherwise.
 * Globals:	Register	- (i/o) set of equivalent states;
 *		result_conclusive
 *				- (i/o) level at which the result becomes true;
 *		pair_stack	- (i/o) arguments of equiv_pair() calls;
 *		ineq		- (i/o) inequivalent pairs;
 *		possibly_eq	- (i/o) potentially equivalent pairs;
 *		eq_pairs	- (i/o) pairs known to be equivalent.
 * Remarks:	This is the pairwise comparison from incremental minimization.
 *		The difference is that two states differ if only one of them
 *		is cyclic, or if both are cyclic, but belong to different
 *		sets of classes.
 */
bool
equiv_pair(state *s1, state *s2, const int level)
{
  if (s1 == s2) {
    return true;
  }
  if ((s1->is_final() != s2->is_final()) || (s1->fan_out() != s2->fan_out())) {
    return false;
  }
  for (int i = 0; i < s1->fan_out(); i++) {
    if (s1->get_transitions()[i].get_label() !=
	s2->get_transitions()[i].get_label()) {
      return false;
    }
  }
  if (level == 0) {
    result_conclusive = 0;
    return true;
  }
  // Cyclic and acyclic states are considered different
  if (s1->is_cyclic() != s2->is_cyclic()) {
    return false;
  }
  // Cyclic states must belong to the same set of classes
  if (s1->is_cyclic()) {
    if (!(*(cycle_number[(state *)s1]) == *(cycle_number[(state *)s2]))) {
      return false;
    }
  }
  state_pair min_pair = state_pair(min(s1,s2),max(s1,s2));
  // Do we already know the states are inequivalent?
  if (ineq.find(min_pair) != ineq.end()) {
    return false;
  }
  // Do we already know they are equivalent?
  if (eq_pairs.find(min_pair) != eq_pairs.end()) {
    return true;
  }
  // Is it a loop?
  for (unsigned j = 0; j < pair_stack.size(); j++) {
    if (pair_stack[j] == min_pair) {
      result_conclusive = j;
      return true;
    }
  }
  // Is it a potentially equivalent pair already visited?
  map<state_pair,pstruct *>::iterator pe1 = possibly_eq.find(min_pair);
  if (pe1 != possibly_eq.end()) {
    result_conclusive = pe1->second->level;
    return true;
  }
  // Save the pair on stack
  bool pushed = (s1->fan_in() > 1 || s2->fan_in() > 1
		 || pair_stack.size() == 0);
  if (pushed) {
    pair_stack.push_back(min_pair);
    dep_pointers.push_back(NULL);
  }
  // Check children, compute dependencies
  bool eq = true;
  unsigned int rc = s1->get_total_states() + 1;// highest possible value
  for (int k = 0; k < s1->fan_out(); k++) {
    result_conclusive = s1->get_total_states() + 1;
    if (!(equiv_pair(s1->get_transitions()[k].get_target(),
		     s2->get_transitions()[k].get_target(),
		     level - 1))) {
      eq = false;
      break;
    }
    if (result_conclusive < rc) {
      rc = result_conclusive;
    }
  }
  result_conclusive = rc;
  // Pop the last pair from the stack
  if (pushed) {
    pair_stack.pop_back();
    if (result_conclusive == pair_stack.size()) {
      result_conclusive = s1->get_total_states() + 1;
    }
  }
  // Use the result (merge the states etc.)
  if (eq) {
    if (result_conclusive == (unsigned int)(s1->get_total_states()) + 1) {
      // Real equivalence - merge the states
      eq_pairs.insert(min_pair);
    }
    else {
      // The pair depends on another pair
      if (dep_pointers[result_conclusive] == NULL) {
	pstruct *pp = new pstruct;
	pp->level = result_conclusive;
	pp->repr = pair_stack[result_conclusive];
	dep_pointers[result_conclusive] = pp;
      }
      dep_pointers[result_conclusive]->deps.push_back(min_pair);
      possibly_eq[min_pair] = dep_pointers[result_conclusive];
    }
  }
  else {
    ineq.insert(min_pair);
  }
  // Deal with pairs that depend on the current pair
  if (pushed) {
    if (dep_pointers.back() != NULL) {
      // There are pairs that depend on the current pair
      if (eq) {
	if (result_conclusive == (unsigned int)(s1->get_total_states()) + 1) {
	  // The current pair does not depend on any other pair
	  // Remember dependent pairs as equivalent
	  for (plist::iterator pi1 = dep_pointers.back()->deps.begin();
	       pi1 != dep_pointers.back()->deps.end(); pi1++) {
	    eq_pairs.insert(*pi1);
	    possibly_eq.erase(*pi1);
	  }
	  dep_pointers.back()->deps.clear();
	  delete dep_pointers.back();
	}
	else {
	  // The current pair depends on another pair
	  pstruct *dpr = dep_pointers[result_conclusive];
	  if (dep_pointers.back()->deps.size() <= dpr->deps.size()) {
	    // Append the list for the current pair to the list of dependencies
	    // for the pair the current pair depends on
	    for (plist::iterator pi2 = dep_pointers.back()->deps.begin();
		 pi2 != dep_pointers.back()->deps.end(); pi2++) {
	      possibly_eq[*pi2] = dpr;
	    }
	    dpr->deps.splice(dpr->deps.end(), dep_pointers.back()->deps);
	  }
	  else {
	    for (plist::iterator pi3 = dpr->deps.begin();
		 pi3 != dpr->deps.end(); pi3++) {
	      possibly_eq[*pi3] = dep_pointers.back();
	    }
	    dep_pointers.back()->repr = pair_stack[result_conclusive];
	    dep_pointers.back()->level = result_conclusive;
	    dep_pointers.back()->deps.splice(dep_pointers.back()->deps.end(),
					     dpr->deps);
	    delete dep_pointers[result_conclusive];
	    dep_pointers[result_conclusive] = dep_pointers.back();
	  }
	}
      }
      else {
	// Remember dependent pairs as inequivalent
	for (plist::iterator pi4 = dep_pointers.back()->deps.begin();
	     pi4 != dep_pointers.back()->deps.end(); pi4++) {
	  ineq.insert(*pi4);
	  possibly_eq.erase(*pi4);
	}
	dep_pointers.back()->deps.clear();
	delete dep_pointers.back();
      }
    }
    dep_pointers.pop_back();
  }
  // Return the result
  return eq;
}//equiv_pair


/* Name:	cyclic_equiv
 * Class:	None.
 * Space:	None.
 * Purpose:	Finds an equivalent cyclic state if such exists.
 * Parameters:	s		- (i) state under examination.
 * Returns:	The same state or an equivalent if found.
 * Globals:	cycle_addr	- (i/o) cyclic class number to states mapping;
 *		cycle_number	- (i/o) cyclic state to class number mapping;
 *		unproc_cycle_addr
 *				- (i/o) unprocessed states from cycle_addr;
 *		current_class_no- (i) current continuation class number;
 * Remarks:	Pairwise equivalence test (from incremental minimization)
 *		is used. The register is not used here at all.
 *
 *		This function is necessary because there may be equivalent
 *		states in the automaton that have different targets
 *		of transitions. The equivalent state is in the same cycle.
 */
state *
cyclic_equiv(state *s)
{
  if (s->is_cyclic()) {
    int n = *(cycle_number[s]->begin());
    // Watch out: it looks strange, but we need a copy, not the original
    set<state *> *sp1 = new set<state *>;
    *sp1 = *(cycle_addr[n]);
    sp1->insert(unproc_cycle_addr->begin(), unproc_cycle_addr->end());
    sp1->erase(s);
    eq_pairs.clear();
    ineq.clear();
    possibly_eq.clear();
    for (set<state *>::iterator si1 = sp1->begin(); si1 != sp1->end(); si1++) {
#ifdef CHECK_REGISTER
      if ((*si1)->check_state()) {
	long l = (long int)(*si1);
	cerr << "Trouble in cyclic states for class no " << n << ": "
	     << "State " << dec << l << "(" << hex << l << ")" << dec
	     << " bogus\n";
	exit(4);
      }
#endif
      if (equiv_pair(s, *si1, s->get_total_states())) {
	eq_pairs.clear();
	ineq.clear();
	possibly_eq.clear();
	return *si1;
      }
    }
    delete sp1;
    // s is not in the Register, otherwise it would have been equivalent above
    eq_pairs.clear();
    ineq.clear();
    possibly_eq.clear();
  }
  return s;
}//minim_cyclic
#endif

/* Name:	delete_branch
 * Class:	None.
 * Space:	None.
 * Purpose:	Deletes a chain of states removing them from the register
 *		if necessary.
 * Parameters:	s		- (i/o) first state of the branch.
 * Returns:	true if branch deleted, false otherwise.
 * Globals:	Register	- (i/o) set of unique states.
 * Remarks:	The state should be registered.
 */
bool
delete_branch(state *s)
{
  if (s->hit(-1) <= 0) {
    Register.remove(s);
    for (int i = 0; i < s->fan_out(); i++) {
      state *t = s->get_transitions()[i].get_target();
      if (!(delete_branch(t))) {
	t->rem_intrans(s->get_transitions()[i].get_label(), s);
      }
    }
    s->get_transitions().clear();
#ifdef WITH_CYCLES
    if (s->is_cyclic()) {
      for (set<int>::iterator cai = cycle_number[s]->begin();
	   cai != cycle_number[s]->end(); cai++) {
	set<state *> *sp = cycle_addr[*cai];
	if (sp->find(s) != sp->end()) {
	  cycle_addr[*cai]->erase(s);
	}
	else {
	  unproc_cycle_addr->erase(s);
	}
      }
      delete cycle_number[s];
      cycle_number.erase(s);
    }
#endif
    delete s;
    return true;
  }
  return false;
}//delete_branch

/* Name:	add_string_with_root
 * Class:	None.
 * Space:	None.
 * Purpose:	Adds a string to the automaton.
 * Parameters:	start		- (i/o) the initial state of the automaton;
 *		str		- (i) string to be added;
 *		dp		- (i) state representing the next continuation
 *					class;
 *		cyc_off		- (i) 1 if start is a cyclic state,
 *					0 otherwise.
 * Returns:	The initial state of the new automaton.
 * Globals:	Register	- (i/o) set of unique states;
 *		cycle_number	- (i/o) cyclic state to class number mapping;
 *		cycle_addr	- (i/o) cyclic class number to states mapping.
 * Remarks:	The intial state is never minimized.
 *		Other states are minimized - if an equivalent state is
 *		found in the register, it replaces the current state,
 *		otherwise the current state is put into the register.
 *		Strings can be empty.
 *
 *		Cases:
 *		1. The continuation class is NULL
 *		1.a. The string is non-empty
 *		1.a.1. There is no continuation class in the path
 *			-> Use the algorithm for unsorted data.
 *		1.a.2. There are some continuation classes in the path
 *			-> Clone classes, proceed as in 1.a.1.
 *		1.b. The string is empty
 *			-> Make the initial state final.
 *		2. The continuation class is not NULL, and not CYCLIC
 *		2.a. The string is empty
 */
state *
add_string_with_root(state *start, labelstr str, state *target, 
		     const int cyc_off)
{
#if defined(WITH_CYCLES) && !defined(EARLY_START)
  if (target->is_cyclic()) {
    state *t1 = start->next(str);
    if (t1 != NULL && t1->is_cyclic()) {
      set<int> *tcn = cycle_number[t1];
      if (tcn->find(*(cycle_number[target]->begin())) != tcn->end()) {
	// Morpheme already present in the language
	if (cyc_off) {
	  unproc_cycle_addr->erase(start);
	  cycle_addr[current_class_no]->insert(start);
	}
	return start;
      }
    }
  }
#endif //WITH_CYCLES&&!EARLY_START

  if (str.length() == 0) {
#ifdef EARLY_START
    Register.remove(start);
#endif
    add_if_different_unreg(target, start);
#ifdef EARLY_START
    state *r1 = Register.get_or_put(start);
    if (r1 != start) {
      redirect(start, r1);
      start = r1;
    }
#endif
  }
  else {
    state *p = start;
    p->hit();			// to clone the state if in the path
    state *q;
    static vector<state *> path;
    path.clear();
    path.push_back(p);
    // Go through common prefix
    unsigned int i;
#ifdef CHECK_REGISTER
    if (p->check_state()) {
      long int convl = (long int)p;
      cout << "Trouble: deleted start state " << convl << "\n";
      exit(4);
    }
#endif
    for (i = 0;
	 i < str.length() - 1 && (q = p->next(str[i])) != NULL &&
	   q->fan_in() <= 1; i++) {
      p = q;
#ifdef CHECK_REGISTER
      if (p->check_state()) {
	long int convl = (long int)p;
	cout << "Trouble: deleted prefix state " << convl << "\n";
	exit(4);
      }
#endif
      path.push_back(p);
    }
    if (p != start || cyc_off) {
      // p is an old, registered state, and we change its right language
      Register.remove(p);
    }
    unsigned int unreg_from = i;

    // Clone states
    for (; i < str.length() - 1 && (q = p->next(str[i])) != NULL;
	 i++) {
#ifdef CHECK_REGISTER
      if (p->check_state()) {
	long int convl = (long int)p;
	cout << "Trouble: deleted state " << convl << "\n";
	exit(4);
      }
#endif
#if defined(WITH_CYCLES) && !defined(EARLY_START)
      if (q->is_cyclic() && cycle_number[q]->size() == 1 &&
	  cycle_number[q]->find(current_class_no) != cycle_number[q]->end()) {
	state *q1 = new state;
	q1->set_cyclic();
	// add_cyclic(q1, q); removed, because done later again
	p->set_next(str[i], q1);
      }
      else {
	p->set_next(str[i], new state(*q));
      }
#else
      p->set_next(str[i], new state(*q));
#endif
      p = p->next(str[i]);
#ifdef WITH_CYCLES
      if (q->is_cyclic()) {
	add_cyclic(p, q);
      }
#endif
      path.push_back(p);
    }

    // Add new states
    for (; i < str.length() - 1; i++) {
      p->set_next(str[i], new state);
      p = p->next(str[i]);
      path.push_back(p);
    }

    // Add the last transition
    int union_off = 1;		// if target is old, don't register
    if (p->next(str[i]) != NULL) {
      if (p->next(str[i]) != target) {
#if defined(WITH_CYCLES) && !defined(EARLY_START)
	if (start->is_cyclic() &&
	    (target == start || p->next(str[i]) == start)) {
	  // Don't copy all transitions of start
	  state *q2 = p->next(str[i]);
	  state *q3 = target == start ? q2 : target;
	  q = new state(*q3);
	  q->set_cyclic();
	  add_cyclic(q, start);	// q should belong to the same classes as start
	  if (q3->is_cyclic()) {
	    add_cyclic(q, q3);	// and additionally to classes of q2
	  }
	}
	else {
	  q = state_union(p->next(str[i]), target);
	}
#else
	q = state_union(p->next(str[i]), target);
#endif
#if defined(WITH_CYCLES)
	if (p->next(str[i])->hit(0) <= 1) {
	  // Register.remove(p->next(str[i])); /* !!! consider delete_branch */
	  p->hit();		// protect p from removal
	  state *q3 = p->next(str[i]);
	  delete_branch(q3);
	  // set_next would access q3, which is already deleted
	  p->find_trans(str[i])->set_target(q);
	  q->set_prev(str[i], p);//back transition
	  q->hit();		// one in-transition more for q
	  p->hit(-1);		// remove protection
	}
	else {
	  p->set_next(str[i], q);
	}
#else
	if (p->next(str[i])->hit(0) <= 1) {
	  delete_branch(p->next(str[i]));
	  p->find_trans(str[i])->set_target(q);
	  q->hit();
	}
	else {
	  p->set_next(str[i], q);
	}
#endif
	union_off = 0;		// now target is a union, do register
      }
    }
    else {
      p->set_next(str[i], target);
    }
    p = p->next(str[i]);
    path.push_back(p);

    // Minimize
    for (i = str.length() - union_off; i + cyc_off > 0; --i) {
      state *r = NULL;
#ifdef WITH_CYCLES
      bool possibly_not_reentrant = false;
#endif
      if ((r = Register.get_or_put(path[i])) == path[i]) {
#ifdef WITH_CYCLES
	if (path[i]->is_cyclic()) {
	  if ((r = cyclic_equiv(path[i])) != path[i]) {
	    // The state has different transitions (targets) than any other
	    // state in the register, but there is an equivalent (cyclic) state
	    // in the automaton
	    Register.remove(path[i]);
	    // Because the state has different transitions than path[i],
	    // we can no longer assume that their targets all have 
	    // more than one in-transition. This means the targets
	    // can be deleted with set_next. This means they can be deleted
	    // without removal from the Register and cyclic registers.
	    possibly_not_reentrant = true;
	  }
	}
#endif
      }
      if (r != path[i]) {
	if (i <= unreg_from && i + cyc_off > 1) {
	  // We have moved in front of the common prefix
	  Register.remove(path[i-1]);
	}
#ifdef WITH_CYCLES
	if (i == 0) {
	  // This is start - the only case when the state can be reentrant
	  start->hit(-1);	// no longer protected
	  redirect(path[0], r);
	  already_deleted.clear();
	  start = r;
	  return start;		// necessary to avoid hitting the wrong state
	}
	else {
	  delete_cyclic(path[i]);
	  if (possibly_not_reentrant) {
	    // Check whether the targets of out-transitions of path[i]
	    // are registered. For those that are, use delete_branch,
	    // and remove the transitions before deleting path[i]
	    trans_vec &ot = path[i]->get_transitions();
	    int otn = path[i]->fan_out();
	    for (int k = 0; k < otn; k++) {
	      state *tot = ot[k].get_target();
	      if (tot->fan_in() <= 1) {
		delete_branch(tot);
	      }
	      else {
		tot->hit(-1);
		tot->rem_intrans(ot[k].get_label(), path[i]);
	      }
	    }
	    ot.clear();
	  }
	  path[i-1]->set_next(str[i-1],r);
	}
#else
	path[i-1]->set_next(str[i-1],r);
#endif
      }
      else if (i <= unreg_from) {
	break;
      }
    }
    if (start->hit(-1) == 0) {
#if defined(WITH_CYCLES) && defined(EARLY_START)
      if (start->is_cyclic()) {
	delete_cyclic(start);
	delete start;
	return NULL;
      }
#endif
    }
  }
#if defined(WITH_CYCLES) && defined(EARLY_START)
  if (cyc_off) {
    unproc_cycle_addr->erase(start);
    cycle_addr[current_class_no]->insert(start);
  }
#endif
  return start;
}//add_string_with_root

/* Name:	minim_root
 * Class:	None.
 * Space:	None.
 * Purpose:	Minimizes the initial state of an automaton.
 * Parameters:	root		- (i) the initial state.
 * Returns:	The new initial state.
 * Globals:	Register	- (i/o) set of unique states;
 *		cycle_name	- (i/o) cyclic state to class mapping;
 *		cycle_addr	- (i/o) cyclic class to states mapping.
 * Remarks:	None.
 */
state *
minim_root(state *root)
{
  state *r;
  if ((r = Register.get_or_put(root)) != root) {
#ifdef WITH_CYCLES
    if (root->is_cyclic()) {
#ifndef EARLY_START
      root->hit(-2);		// remove artificial incoming transitions
#endif
      redirect(root, r);
      already_deleted.clear();
      root = r;
    }
    else {
      delete root;
      root = r;
    }
#else
    delete root;
    root = r;
#endif
  }
  return root;
}//minim_root

#if defined(WITH_CYCLES) && !defined(EARLY_START)
/* Name:	add_if_different
 * Class:	None.
 * Space:	None.
 * Purpose:	Compares two states, and if the first one contains transitions
 *		not present in the second one, they are added to the second.
 * Parameters:	s1		- (i) first state;
 *		s2		- (i/o) second state.
 * Returns:	The second state with new transitions if needed.
 * Globals:	Register	- (i/o) set of unique states.
 * Remarks:	s2 must be registered.
 *		Adding may result in state unions, and s2 is marked
 *		to prevent being updated twice.
 */
state *
add_if_different(const state *s1, state *s2)
{
//#ifdef PRINT_DICT
//  cout << "add_if_different\n";
//  print_cycles(cout);
//  cout.flush();
//#endif
  if (s2->is_marked()) {
    // Well, it's a cyclic automaton, and we're back at square one
    return s2;
  }
  if (key_eq((state *)s1, s2)) {
    return s2;
  }
  s2->mark();
  Register.remove(s2);
  if (s1->is_final()) {
    s2->set_final();
  }
  for (int i = 0; i < s1->fan_out(); i++) {
    const transition &tt = s1->get_transitions()[i];
    mychar c = tt.get_label();
    if (s2->next(c) != tt.get_target()) {
      if (s2->next(c) == NULL) {
	s2->set_next(c, tt.get_target());
      }
      else {
	closing_cycles_phase = true;
	state *q1 = s2->next(c);
	state *q = state_union(q1, tt.get_target());
	closing_cycles_phase = false;
	state *r;
	if ((r = Register.get_or_put(q)) != q) {
	  delete_cyclic(q);
	  delete q;
	}
	else if (q->is_cyclic()) {
	  if ((r = cyclic_equiv(q)) != q) {
	    Register.remove(q);
	    delete_cyclic(q);
	    delete q;
	  }
	}
	if (q1->fan_in() <= 1 && q1 != r) {
	  Register.remove(q1);
	  delete_cyclic(q1);
	}
	s2->set_next(c, r);
      }
    }
  }
  s2->unmark();
  state *r1;
  bool redirected = false;
  if ((r1 = Register.get_or_put(s2)) == s2) {
    if (s2->is_cyclic()) {
      if ((r1 = cyclic_equiv(s2)) != s2) {
	redirected = true;
      }
    }
    else {
      redirected = true;
    }
  }
  else {
    redirected = true;
  }
  if (redirected) {
    redirect(s2, r1);
    s2 = r1;
  }
  else {
    // Move s2 from unproc_cycle_addr to cycle_addr
    unproc_cycle_addr->erase(s2);
    cycle_addr[current_class_no]->insert(s2);
  }
  return s2;
}//add_if_different
#endif

#ifdef PRINT_AUT
/* Name:	print_states
 * Class:	None.
 * Space:	None.
 * Purpose:	Prints information about states in the automaton.
 * Parameters:	s		- (i) initial state;
 *		dictionary	- (i) dictionary of class names.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	States printed are marked.
 *		This is only for diagnostic purposes.
 */
void
print_states(state *s, map<mystr,pair<state *,int> > &dictionary)
{
#ifdef CHECK_REGISTER
  if (s->check_state()) {
    cout << "Big trouble printing state " << hash_pointer(s)
	 << " - state already deleted!\n";
    cout.flush();
    exit(4);			// state deleted
  }
#endif
  if (!(s->is_marked())) {
    s->mark();
    cout << "State " << hash_pointer(s);
    if (s->is_final()) {
      cout << " final";
    }
#ifdef WITH_CYCLES
    if (s->is_cyclic()) {
      cout << " cyclic(";
      set<int> *si = cycle_number[s];
      for (set<int>::iterator ci = si->begin(); ci != si->end(); ) {
	cout << cycle_name[*ci];
	if (dictionary[cycle_name[*ci]].first == s) {
	  cout << "!";
	}
	if (++ci != si->end()) {
	  cout << ",";
	}
      }
      cout << ")";
    }
#endif
    cout << " <- " << s->fan_in() << "\n";
#if defined(WITH_CYCLES) && defined(PRINTIN)
    if (s->get_intransitions().size() > 0) {
      cout << " In transitions:\n";
      for (unsigned int j = 0; j < s->get_intransitions().size(); j++) {
	hash_pointer l1 = s->get_intransitions()[j].get_target();
	cout << "  " << s->get_intransitions()[j].get_label()
	     << " <- " << l1 << "\n";
      }
    }
    else {
      cout << " No in transitions\n";
    }
#endif
    if (s->fan_out() > 0) {
      cout << " Transitions:\n";
      for (int i = 0; i < s->fan_out(); i++) {
	hash_pointer l = s->get_transitions()[i].get_target();
	cout << "  " << s->get_transitions()[i].get_label()
	     << " -> " << l << "\n";
      }
      for (int j = 0; j < s->fan_out(); j++) {
	print_states(s->get_transitions()[j].get_target(), dictionary);
      }
    }
  }
  cout.flush();
}//print_states
#endif

#ifdef CHECK_REGISTER
/* Name:	check_states
 * Class:	None.
 * Space:	None.
 * Purpose:	Checks information about states in the automaton.
 * Parameters:	s		- (i) initial state.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	States checked are marked.
 *		This is only for diagnostic purposes.
 */
void
check_states(state *s)
{
  if (s->check_state()) {
    long int la1 = (long int)s;
    cerr << "Big trouble checking state " << la1
	 << " - state already deleted!\n";
    exit(4);			// state deleted
  }
  if (!(s->is_marked())) {
    s->mark();
    if (s->fan_out() > 0) {
      for (int j = 0; j < s->fan_out(); j++) {
	check_states(s->get_transitions()[j].get_target());
      }
    }
  }
}//check_states
#endif

/* Name:	unmark_states
 * Class:	None.
 * Space:	None.
 * Purpose:	Unmarks states in an automaton.
 * Parameters:	s		- (i) initial state.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	Recursive, diagnostic purposes.
 */
void
unmark_states(state *s)
{
  if (s->is_marked()) {
    s->unmark();
    for (int i = 0; i < s->fan_out(); i++) {
      unmark_states(s->get_transitions()[i].get_target());
    }
  }
}//unmark_states

#ifdef TEST
/* Name:	test_string
 * Class:	None.
 * Space:	None.
 * Purpose:	Tests whether a string is recognized by the automaton.
 * Parameters:	q		- (i) initial state;
 *		s		- (i) the string.
 * Returns:	True if string recognized, false otherwise.
 * Globals:	None.
 * Remarks:	None.
 */
bool
test_string(state * q, const char *s)
{
  if (*s == '\0') {
    return q->is_final();
  }
  state *p = q->next(*s);
  if (p) {
    return test_string(p, s + 1);
  }
  return false;
}//test_string
#endif


#ifdef CHECK_REGISTER
#ifdef WITH_CYCLES
/* Name:	check_cycles
 * Class:	None.
 * Space:	None.
 * Purpose:	Checks whether all states in cyclic state sets are valid.
 * Parameters:	None.
 * Returns:	Nothing.
 * Globals:	cycle_addr	- (i/o) cyclic class number to states mapping;
 *		cycle_name	- (i/o) cyclic state to class number mapping;
 *		unproc_cycle_addr
 *				- (i/o) unprocessed states from cycle_addr.
 * Remarks:	Execution is interrupted when an error if found.
 */
void
check_cycles(void)
{
  for (unsigned int i = 0; i < cycle_name.size(); i++) {
    set<state *> *sp1 = cycle_addr[i];
    if (sp1->size() == 0) {
      cerr << "Strange, cycle without states!!!\n";
    }
    for (set<state*>::iterator p1 = sp1->begin(); p1 != sp1->end(); p1++) {
      if ((*p1)->check_state()) {
	long l = (long int)(*p1);
	cerr << "Trouble checking cyclic state " << dec << l << "(" << hex
	     << l << dec << ") in class no " << i << "\n";
	exit(4);
      }
    }
  }
}//check_cycles
#endif
#endif


#ifdef PRINT_DICT
#ifdef WITH_CYCLES
/* Name:	print_cycles
 * Class:	None.
 * Space:	None.
 * Purpose:	Prints contents of two cyclic dictionaries.
 * Parameters:	outp		- (o) output stream.
 * Returns:	Nothing.
 * Globals:	cycle_number	- (i) cyclic state to class number mapping;
 *		cycle_addr	- (i) cyclic class number to states mapping.
 * Remarks:	None.
 */
void
print_cycles(ostream &outp)
{
  int entries_per_line = 0;
  outp << "cycle_addr:\n";
  for (unsigned int i = 0; i < cycle_name.size(); i++) {
    outp << "(" << i << " (" << cycle_name[i] << "):\n  ";
    set<state *> *sp1 = cycle_addr[i];
    if (sp1->size() == 0) {
      cerr << "Strange, cycle without states!!!\n";
    }
    for (set<state*>::iterator p1 = sp1->begin(); p1 != sp1->end(); p1++) {
      if (entries_per_line >= 4) {
	outp << "\n  ";
	entries_per_line = 0;
      }
      outp << " " << hash_pointer(*p1);
      entries_per_line++;
    }
    outp << ")\n";
    entries_per_line = 0;
  }
  outp << "cycle_number:\n";
  for (map<state*,set<int>*>::iterator p1 = cycle_number.begin();
       p1 != cycle_number.end(); p1++) {
    outp << "  (" << hash_pointer(p1->first) << ":\n    ";
    for (set<int>::iterator p11 = p1->second->begin();
	 p11 != p1->second->end();
	 p11++) {
      if (entries_per_line >= 4) {
	outp << "\n    ";
	entries_per_line = 0;
      }
      outp << *p11 << " (" << cycle_name[*p11] << ")";
      entries_per_line++;
    }
    outp << ")\n";
    entries_per_line = 0;
  }
  outp.flush();
}//print_cycles
#endif

/* Name:	print_dict
 * Class:	None.
 * Space:	None.
 * Purpose:	Prints contents of internal dictionaries (Register, cycle_*).
 * Parameters:	outp		- (o) output stream;
 *		dict		- (i) dictionary of classes;
 *		unproc_cycle_addr
 *				- (i) unprocessed states from cycle_addr.
 * Returns:	Nothing.
 * Globals:	Register	- (i) set of unique states;
 *		cycle_name	- (i) cyclic state to class mapping;
 *		cycle_addr	- (i) cyclic class to states mapping.
 * Remarks:	This is only for diagnostic purposes.
 */
void
print_dict(ostream &outp, map<mystr,pair<state *,int> > &dict)
{
  int entries_per_line = 0;
  outp << "Register:\n";
  outp << Register;
  outp << "Dictionary:\n";
  for (map<mystr,pair<state *,int> >::iterator p = dict.begin();
       p != dict.end(); p++) {
    if (entries_per_line >= 2) {
      outp << "\n";
      entries_per_line = 0;
    }
    outp << " (" << p->first << "," << hash_pointer(p->second.first)
	 << "," << (p->second.second ? "CYC" : "ACY") << ")";
    entries_per_line++;
  }
  outp << "\n";
#ifdef WITH_CYCLES
  print_cycles(outp);
  entries_per_line = 0;
  outp << "unproc_cycle_addr:\n";
  for (set<state*>::iterator p3 = unproc_cycle_addr->begin();
       p3 != unproc_cycle_addr->end(); p3++) {
    if (entries_per_line >= 5) {
      outp << "\n";
      entries_per_line = 0;
    }
    long int l3 = (long int)(*p3);
    outp << " " << l3;
    entries_per_line++;
  }
  outp << "\n";
#endif
}//print_dict
#endif

#ifdef STATS
/* Name:	reachable
 * Class:	None.
 * Space:	None.
 * Purpose:	Calculates the number of states reachable from the given state.
 * Parameters:	s		- (i) starting state.
 * Returns:	The number of reachable states.
 * Globals:	None.
 * Remarks:	The count includes the parameter if not marked.
 *		Counted states are marked.
 */
int
reachable(state *s)
{
  int sum = 0;
  if (!(s->is_marked())) {
    s->mark();
    sum++;
    for (trans_vec::iterator t = s->get_transitions().begin();
	 t != s->get_transitions().end(); t++) {
      sum += reachable(t->get_target());
    }
  }
  return sum;
}//reachable
#endif

#if defined(SORTED) || defined(CARFOR) || defined(UNSORTED) || defined(WATCYC)
#include "acyclic.cc"
#endif

#ifdef WITH_CYCLES
/* Name:	cyclic_dir
 * Class:	None.
 * Space:	None.
 * Purpose:	Handles directive "Cyclic:".
 * Parameters:	dictionary	- (i) dictionary of class names
 *					and the corresponding states;
 *		input		- (i) input stream.
 * Returns:	Nothing.
 * Globals:	cycle_number	- (o) state to cyclic class number mapping;
 *		cycle_addr	- (o) cyclic class number to set of states
 *				  mapping
 *		cycle_name	- (o) cylic class number to name mapping;
 *		Register	- (o) set of unique states.
 * Remarks:	Cyclic directive syntax:
 *		<CyclicDecl> ::= "Cyclic" ":" <Identifier>... ";".
 *
 *		Class names are identified as names of cyclic classes.
 *		For each class, a representative state is created.
 *		The state is marked as cyclic.
 *		The state is also associated with the class name in dictionary.
 */
void
cyclic_dir(map<mystr,pair<state *,int> > &dictionary, istream &input)
{
  using namespace lex;

  symbol symb;
  if ((symb = get_symbol(input)) == colon) {
    while ((symb = get_symbol(input)) == identifier) {
      if (dictionary.find(get_string(true)) != dictionary.end()) {
	complain(symb, "Continuation class already defined");
	exit(1);
      }
      state *s = new state;
      s->set_cyclic();
      s->hit(2);		// make it reentrant state that must be cloned
      mystr cyc_name = get_string(true);
      dictionary[cyc_name] = pair<state *, int>(s, CYCLIC);
      int cyc_no = cycle_name.size();
      class_number[cyc_name] = cyc_no;
      cycle_name.push_back(cyc_name);
      cycle_number[s] = new set<int>;
      cycle_number[s]->insert(cyc_no);
      cycle_addr.push_back(new set<state*>);
      cycle_addr[cyc_no]->insert(s);
      Register.get_or_put(s);
    }
    if (symb != semicolon) {
      complain(symb, "Semicolon expected");
      exit(1);
    }
  }
  else {
    complain(symb, "Colon expected");
    exit(1);
  }
}//cyclic_dir
#endif

/* Name:	forget_dir
 * Class:	None.
 * Space:	None.
 * Purpose:	Handles directive "Forget:".
 * Parameters:	dictionary	- (i/o) dictionary of class names
 *				  and the corresponding states;
 *		input		- (i) input stream.
 * Returns:	Nothing.
 * Globals:	Register	- (i/o) set of unique states in the automaton.
 * Remarks:	Syntax of the directive:
 *		<ForgetDecl> ::= "Forget" ":" <Identifier>... ";".
 *
 *		The directive removes the specified class names
 *		from the dictionary. If the states associated with the classes
 *		do not have true incoming transitions, they are removed
 *		along with sequences of states with only one incoming
 *		transition that follow the associated states.
 */
void
forget_dir(map<mystr,pair<state *,int> > &dictionary, istream &input)
{
  using namespace lex;

  symbol symb;
  if ((symb = get_symbol(input)) == colon) {
#ifdef PRINT_DICT
    print_dict(cout, dictionary);
#endif //PRINT_DICT
#ifdef CHECK_REGISTER
    Register.check();
#ifdef WITH_CYCLES
    check_cycles();
#endif //WITH_CYCLES
#endif //CHECK_REGISTER
    while ((symb = get_symbol(input)) == identifier) {
      map<mystr, pair<state *,int> >::iterator dp =
	dictionary.find(get_string(true));
      if (dp != dictionary.end()) {
	if (dp->second.first->hit(dp->second.second == CYCLIC ? -2 : -1)
	    <= 0) {
#ifdef WITH_CYCLES
	  delete_branch(dp->second.first);
#else
	  Register.remove(dp->second.first);
	  delete dp->second.first;
#endif
	}
	dictionary.erase(dp);
      }
      else {
	complain(symb, "Symbol not yet defined");
	exit(1);
      }
    }
    if (symb != semicolon) {
      complain(symb, "Semicolon expected");
      exit(1);
    }
  }
  else {
    complain(symb, "Colon expected");
    exit(1);
  }
}//forget_dir

#if defined(CARFOR) || defined(SORTED) || defined(UNSORTED) || defined(WATCYC)
/* Name:	acyclic_dir
 * Class:	None.
 * Space:	None.
 * Purpose:	Handles directive "Acyclic:".
 * Parameters:	dictionary	- (o) maps class names to states.
 *		input		- (i) input stream.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	Syntax of the directive "Acyclic:":
 *		<AcyclicDecl> ::= "Acyclic" ":" <Morpheme>... ";".
 *
 *		AcyclicDecl is recognized only when compile-time options
 *		CARFOR or SORTED are defined. Only one of them can be defined.
 *		If SORTED is defined, then morphemes on the list should be
 *		lexicographically sorted. The morphemes will be added
 *		to the class Root using either an algorithm
 *		by Rafael C. Carrasco and Mikel L. Forcada published
 *		in Computational Linguistics 28(2), June 2002 (with CARFOR),
 *		or my generalized algorithm for sorted data (with SORTED).
 *		The next class for those morphemes is assumed to be NULL.
 *		This declaration should be the last in the whole description.
 *		In addition, compile-time option WITH_CYCLES should be defined.
 */
void
acyclic_dir(map<mystr,pair<state *,int> > &dictionary, istream &input)
{
  using namespace lex;

  symbol symb;
  if ((symb = get_symbol(input)) != colon) {
    complain(symb, "Colon expected");
    exit(1);
  }
  // Remove everything except "Root" from the dictionary
  map<mystr,pair<state *,int> >::iterator ri;
  if ((ri = dictionary.find("Root")) == dictionary.end()) {
    cerr << "ccip: Root not defined\n";
    exit(1);
  }
  pair<state *,int> ipair = ri->second;
  for (ri = dictionary.begin(); ri != dictionary.end(); ri++) {
    ri->second.first->hit(ri->second.second == CYCLIC ? -2 : -1);
  }
  dictionary.clear();
  dictionary["Root"] = ipair;
#ifdef CARFOR
  dictionary["Root"].first = carfor_add(input, dictionary["Root"].first);
#elif defined(SORTED)
  dictionary["Root"].first = add_sorted(input, dictionary["Root"].first);
#elif defined(UNSORTED)
  dictionary["Root"].first = add_unsorted(input, dictionary["Root"].first);
#elif defined(WATCYC)
  dictionary["Root"].first = add_watcyc(input, dictionary["Root"].first);
#endif
}//acyclic_dir
#endif

#if defined(DETAILED_PROGRESS) || (defined(PRINT_MORPH) && (defined(PRINT_AUT) || defined(PRINT_DICT))) || defined(CHECK_REGISTER) || defined(SANITY_CHECK)
/* Name:	perform_checks1
 * Class:	None.
 * Space:	None.
 * Purpose:	Perform checks, printouts etc. after addition of a morpheme.
 * Parameters:	dictionary	- (i) class names to states mapping;
 *		morpheme_repeat	- (i) how many times the morpheme
 *					has already beeen added;
 *		s1		- (i) current start state.
 * Returns: 	Nothing.
 * Globals:	cycle_addr		- (i) cyclic class number to state
 *						mapping;
 *		unproc_cycle_addr	- (i) unprocessed cyclic states
 *						for current class;
 *		Register		- (i) set of unique states in the fsa.
 * Remarks:	Invoked in fully incremental addition.
 */
inline void
perform_checks1(map<mystr,pair<state *,int> > &dictionary,
	       const int morpheme_repeat, const state *s1)
{
  using namespace lex;
#ifdef DETAILED_PROGRESS
  cout << "  >morpheme `" << get_string(false) << "'/"
       << morpheme_repeat - 1 << " states: "
       << s1->get_total_states() << " cyclic: "
       << cycle_addr[current_class_no]->size()
       << "+" << unproc_cycle_addr->size() << "\n";
  cout.flush();
#endif //DETAILED_PROGRESS
#if defined(PRINT_AUT) && defined(PRINT_MORPH)
  cout << "After addition of morpheme `" << get_string(false)
       << "'\n";
  print_states(s1, dictionary);
  unmark_states(s1);
#else //!(PRINT_AUT&&PRINT_MORP)
#ifdef CHECK_REGISTER
  for (set<state*>::iterator dx1 = unproc_cycle_addr->begin();
       dx1 != unproc_cycle_addr->end();
       dx1++) {
    check_states(*dx1);
    unmark_states(*dx1);
  }
  set<state *> *spx1 = cycle_addr[current_class_no];
  for (set<state*>::iterator dx2 = spx1->begin();
       dx2 != spx1->end(); dx2++) {
    check_states(*dx2);
    unmark_states(*dx2);
  }
#endif //CHECK_REGISTER
#endif //!(PRINT_AUT&&PRINT_MORPH)
#if defined(PRINT_DICT) && defined(PRINT_MORPH)
  print_dict(cout, dictionary);
  cout.flush();
#else //!(PRINT_DICT&&PRINT_MORPH)
#endif //!(PRINT_DICT&&PRINT_MORPH)
#ifdef CHECK_REGISTER
  Register.check();
#ifdef WITH_CYCLES
  check_cycles();
#endif //WITH_CYCLES
#endif //CHECK_REGISTER
#ifdef SANITY_CHECK
  Register.sanity_check();
#endif //SANITY_CHECK
}//perform_checks1
#endif

#if defined(DETAILED_PROGRESS) || defined(CHECK_REGISTER) || (defined(PRINT_MORPH) && (defined(PRINT_AUT) || defined(PRINT_DICT)))
/* Name:	perform_checks2
 * Class:	None.
 * Space:	None.
 * Purpose:	Performs checks, printouts, etc., after addition of a morpheme.
 * Parameters:	dictionary	- (i) class name to state mapping;
 *		start		- (i) start state of the automaton.
 * Returns:	Nothing.
 * Globals:	Register	- (i) set of unique states in the automaton.
 * Remarks:	Invoked in the semi-incremental or non-cyclic part.
 */
inline void
perform_checks2(map<mystr,pair<state *,int> > &dictionary, state *start)
{
#ifdef DETAILED_PROGRESS
  int curr_no_cyclic = unproc_cycle_addr ?
    unproc_cycle_addr->size() : 0;
  for (vector<set<state*>*>::iterator cai1 = cycle_addr.begin();
       cai1 != cycle_addr.end(); cai1++) {
    curr_no_cyclic += (*cai1)->size();
  }
  cout << "      states: "
       << start->get_total_states() << " cyclic: "
       << curr_no_cyclic << "\n";
  cout.flush();
#endif //DETAILED_PROGRESS
#if defined(PRINT_AUT) && defined(PRINT_MORPH)
  cout << "After addition of morpheme `" << morph
       << "'\n";
  print_states(start, dictionary);
  unmark_states(start);
#endif //PRINT_AUT&&PRINT_MORPH
#if defined(PRINT_DICT) && defined(PRINT_MORPH)
  print_dict(cout, dictionary);
#endif //PRINT_DICT&&PRINT_MORPH
#ifdef CHECK_REGISTER
  Register.check();
#ifdef WITH_CYCLES
  check_cycles();
#endif //WITH_CYLES
#endif //CHECK_REGISTER
}//perform_checks2
#endif

#ifdef WITH_CYCLES
/* Name:	minimize_cycles
 * Class:	None.
 * Space:	None.
 * Purpose:	Compares pairwise cyclic states belonging to the current class,
 *		as if find equivalent ones, performs minimization.
 * Parameters:	start		- (i) start state of the current class;
 *		current_class_no- (i) current class number;
#ifdef PRINT_AUT
 *		class_name	- (i) current class name;
#endif
 *		dictionary	- (i) class name to state mapping.
 * Returns:	Nothing.
 * Globals:	cycle_number	- (i) cyclic state to class number mapping.
 *		cycle_addr	- (i/o) class number to set of cyclic states
 *					mapping;
 *		unproc_cycle_addr
 *				- (i/o) unprocessed cyclic states
 *					of the current class;
 *		already_deleted	- (i) states deleted during minimization.
 * Remarks:
 */
inline void
minimize_cycles(state *start, const int current_class_no,
#ifdef PRINT_AUT
		mystr class_name,
#endif
		map<mystr,pair<state *,int> > &dictionary)
{
  // First some checks if necessary
#ifdef PRINT_AUT
  cout << "Before minimization on " << class_name << ":\n";
  print_states(start, dictionary);
  unmark_states(start);
#endif //PRINT_AUT
#ifdef PRINT_DICT
  print_dict(cout, dictionary);
#endif //PRINT_DICT
#ifdef CHECK_REGISTER
  Register.check();
  check_cycles();
#endif //CHECK_REGISTER
#ifdef DEBUG
  cout << "Minimization\n";
#endif
  set<state *> *setp = cycle_addr[current_class_no];
  set<int> *scn = cycle_number[start];
  for (set<state *>::iterator dp5 = setp->begin(); dp5 != setp->end();
       dp5 = setp->begin()) {
    state *tp5 = *dp5;
    setp->erase(dp5);
    unproc_cycle_addr->insert(tp5);
#ifdef CHECK_REGISTER
    if (tp5->fan_in() < 0 || tp5->fan_out() < 0 ||
	tp5->fan_out() > 256) {
      long la = (long int)(tp5);
      cerr << "Trouble in cyclic states. State "
	   << la << " already deleted.\n";
      exit(4);
    }
#endif //CHECK_REGISTER
    if (tp5 != start) {
      pair_stack.clear();
      eq_pairs.clear();
      ineq.clear();
      if (*scn == *(cycle_number[tp5]) &&
	  equiv_pair(start, tp5, start->get_total_states() - 2)){
	Register.remove(tp5);
	redirect(tp5, start);
	for (set<state *>::iterator adp1 = already_deleted.begin();
	     adp1 != already_deleted.end(); adp1++) {
	  if (setp->find(*adp1) != setp->end()) {
	    setp->erase(*adp1);
	  }
	}
	already_deleted.clear();
      }
      else if (setp->size() > 0) {
	set<state *> *setp1 = new set<state *>(*setp);
	for (set<state *>::iterator dp7 = setp1->begin();
	     dp7 != setp1->end(); dp7 = setp1->begin()) {
	  if (*dp7 != start) {
	    state *tp7 = *dp7;
	    setp1->erase(dp7);
#ifdef CHECK_REGISTER
	    if (tp7->fan_in() < 0 || tp7->fan_out() < 0 ||
		tp7->fan_out() > 256) {
	      long la = (long int)tp7;
	      cerr << "Trouble in cyclic states. State "
		   << la << " already deleted.\n";
	      exit(4);
	    }
#endif //CHECK_REGISTER
	    pair_stack.clear();
	    eq_pairs.clear();
	    ineq.clear();
	    if (*(cycle_number[tp5]) == *(cycle_number[tp7]) &&
		equiv_pair(tp5, tp7, start->get_total_states()-2)) {
	      Register.remove(tp7);
	      redirect(tp7, tp5);
	      for (set<state *>::iterator adp2 =
		     already_deleted.begin();
		   adp2 != already_deleted.end(); adp2++) {
		if (setp->find(*adp2) != setp->end()) {
		  setp->erase(*adp2);
		}
		if (setp1->find(*adp2) != setp1->end()) {
		  setp1->erase(*adp2);
		}
	      }
	    }
	  }//if *dp7 != start
	}//for dp7
      }//if !equiv_pair(start, *dp5)
    }//if *dp5 != start
  }//for dp5 (minimization)
  swap(unproc_cycle_addr,cycle_addr[current_class_no]);
}//minimize_cycles

/* Name:	close_cycles
 * Class:	None.
 * Space:	None.
 * Purpose:	Updates cyclic states other than the state representing
 *		the class (stored in the dictionary).
 * Parameters:	is_cyclic		- (i) true if the class is cyclic,
 *						false otherwise;
 *		current_class_no	- (i) current cyclic class number;
#ifdef PRINT_AUT
 *		class_name		- (i) current class_name;
#endif
 *		start			- (i) start state of the class;
 *		dictionary		- (i) class name to state mapping.
 * Returns:	Nothing.
 * Globals:	cycle_addr		- (i/o) class number to set of states
 *						mapping;
 *		unproc_cycle_addr	- (i/o) unprocessed cyclic states
 *						belonging to the current class;
 * Remarks:
 */
inline void
close_cycles(const int is_cyclic, const int current_class_no,
#ifdef PRINT_AUT
	     mystr class_name,
#endif
	     state *start, map<mystr,pair<state *,int> > &dictionary)
{
  if (is_cyclic) {
    set<state*> *msp1 = cycle_addr[current_class_no];
    for (set<state*>::iterator dx3 = unproc_cycle_addr->begin();
	 dx3 != unproc_cycle_addr->end(); dx3++) {
      msp1->insert(*dx3);
    }
    unproc_cycle_addr->clear();
    swap(unproc_cycle_addr,cycle_addr[current_class_no]);
    // Exclude the representative from the process
    unproc_cycle_addr->erase(start);
    if (cycle_addr[current_class_no] == NULL) {
      cycle_addr[current_class_no] = new set<state*>;
    }
    cycle_addr[current_class_no]->insert(start);
#ifndef EARLY_START
    // Close cycles
#ifdef PRINT_AUT
    cout << "Before closing cycles on " << class_name << ":\n";
    print_states(start, dictionary);
    unmark_states(start);
#endif //PRINT_AUT
#ifdef PRINT_DICT
    print_dict(cout, dictionary);
#endif //PRINT_DICT
#ifdef CHECK_REGISTER
    Register.check();
    check_cycles();
#endif //CHECK_REGISTER
      // Update cyclic states
#ifdef DEBUG
      cout << "Closing cycles\n";
#endif
    for (set<state *>::iterator dp4 = unproc_cycle_addr->begin();
	 dp4 != unproc_cycle_addr->end();
	 dp4 = unproc_cycle_addr->begin()) {
      if (*dp4 != start) {
#ifdef CHECK_REGISTER
	if ((*dp4)->fan_in() < 0 || (*dp4)->fan_out() < 0 ||
	    (*dp4)->fan_out() > 256) {
	  cerr << "Trouble in cyclic states. State "
	       << hash_pointer(*dp4) << " already deleted.\n";
	  exit(4);
	}
#endif //CHECK_REGISTER
	add_if_different(start, *dp4);
      }
    }//for dp4
#endif //!EARLY_START
    // Minimize
#ifdef PRINT_AUT
//    minimize_cycles(start, current_class_no, class_name, dictionary);
#else
//     minimize_cycles(start, current_class_no, dictionary);
#endif
#ifdef CHECK_REGISTER
    Register.check();
    check_cycles();
#endif //CHECK_REGISTER
  }//if continuation class is declared as cyclic
}//close_cycles
#endif //WITH_CYCLES

/* Name:	get_morpheme
 * Class:	None.
 * Space:	None.
 * Purpose:	Reads a morpheme.
 * Parameters:	morph		- (o) morpheme read.
 * Returns:	Next symbol;
 * Globals:	None.
 * Remarks:	Depending on the compile option TRANSDUCER,
 *		either a simple string, or a pair of corresponding strings
 *		(upper and lower level) is returned. In the latter case,
 *		the strings are separated with LEVEL_SEP in the input.
 *
 *		This function is used instead of get_string to get
 *		the morpheme as either a string, or a pair of strings.
 *		It should be called after get_symbol() returns "morpheme".
 *		Unlike get_string(), this function reads further symbol!!!
 *		This is necessary, because the morpheme in transducers is
 *		string [ LEVEL_SEP string ].
 */
lex::symbol
get_morpheme(istream &input, labelstr &morph)
{
  using namespace lex;
  symbol symb;
#ifdef TRANSDUCER
  mystr morph1 = get_string(false);
  if ((symb = get_symbol(input)) == LEVEL_SEP) {
    if ((symb = get_symbol(input)) == morpheme) {
      mystr morph2 = get_string(false);
      morph = make_label_str(morph1, morph2);
    }
    else {
      complain(symb, "morpheme expected");
    }
  }
  else {
    morph = make_label_str(morph1, morph1);
  }
#else
  morph = get_string(false);
  symb = get_symbol(input);
#endif
  return symb;
}//get_morpheme

#if defined(DELETE) && defined(WITH_CYCLES) && !defined(DEL_CYCL)
/* Name:	delete_morpheme
 * Class:	None.
 * Space:	None.
 * Purpose:	Deletes a morpheme between the specified state and
 *		a state belonging to the next continuation class.
 * Parameters:	start		- (i) where to begin deleting;
 *		morpheme	- (i) morpheme to be deleted;
 *		target		- (i) target class dictionary entry.
 * Returns:	Nothing.
 * Globals:	cycle_name	- (i/o) cyclic state to class mapping;
 *		cycle_addr	- (i/o) cyclic class to states mapping;
 *		unproc_cycle_addr
 *				- (i/o) unprocessed states from cycle_addr;
 *		current_class	- (o) name of the currently processed class.
 * Remarks:
 */
void
delete_morpheme(state *start, labelstr morpheme, )
{
}//delete_morpheme

/* Name:	handle_deletion
 * Class:	None.
 * Space:	None.
 * Purpose:	Handles deletion of morphemes.
 * Parameters:	dictionary	- (i) dictionary of class names;
 *		input		- (i) input stream.
 * Returns:	Nothing.
 * Globals:	cycle_name	- (i/o) cyclic state to class mapping;
 *		cycle_addr	- (i/o) cyclic class to states mapping;
 *		unproc_cycle_addr
 *				- (i/o) unprocessed states from cycle_addr;
 *		current_class	- (o) name of the currently processed class.
 * Remarks:	This part recognizes just:
 *
 *		"-" <Definition>
 *
 *		where:
 *		<Definition> ::= <CurrClassName> "{" <NextMorphemes>... "}".
 *		<CurrClassName> ::= <Identifier>.
 *		<NextMorphemes> ::= <NextClassName> <Morpheme>... ";".
 *		<NextClassName> ::= <Identifier>.
 *
 *		However, the semantics is different.
 *		The morphemes between CurrClassName and NextClassName
 *		are deleted.
 *
 *		Note that adding a definition, and then deleting it,
 *		does not necessarily give the initial automaton.
 *
 *		For example, if we had:
 *		c1 {
 *		  NULL "a" "b";
 *		}
 *		c2 {
 *		  NULL "a" "b" "c";
 *		}
 *
 *		and then add:
 *		c2 {
 *		  c1 "";
 *		}
 *
 *		then deleting the empty morpheme:
 *		- c2 {
 *		  c1 "";
 *		}
 *
 *		would give us the situation equivalent to:
 *		c2 {
 *		  NULL "c";
 *		}
 */
void
handle_deletion(map<mystr,pair<state *,int> > &dictionary, istream &input)
{
  using namespace lex;
  symbol symb;
  mystr str;
  if ((symb = get_symbol(input)) != identifier) {
    complain(symb, "Class identifier expected");
    exit(1);
  }
  mystr class_name = get_string(true);
  mystr next_class_name;
  map<mystr, pair<state *,int> >::iterator dp =  dictionary.find(class_name);
  if (dp == dictionary.end()) {
    complain(symb, "Class name not defined yet");
    exit(1);
  }
  if ((symb = get_symbol(input)) != left_brace) {
    complain(symb, "Left brace expected");
    exit(1);
  }
#ifdef DEBUG
  cout << "Start deleting from class " << class_name << "\n";
#endif
  state *start = dp->second.first;
  bool is_cyclic = (dp->second.second == CYCLIC);
#ifdef WITH_CYCLES
  int current_class_no = -1;
  if (is_cyclic) {
    current_class_no = class_number[current_class];
  }
#endif
  Register.remove(start);
  // Process morphemes leading to one next continuation class
  while ((symb = get_symbol(input)) == identifier) {
    next_class_name = get_string(true);
    dp = dictionary.find(next_class_name);
    if (dp == dictionary.end()) {
      complain(symb, "Unknown continuation class");
      exit(1);
    }
#ifdef DEBUG
    cout << " next class " << next_class_name << "\n";
#endif
    symb = get_symbol(input);
    while (symb == morpheme) {
      swap(unproc_cycle_addr,cycle_addr[current_class_no]);
      labelstr morph;
      symb = get_morpheme(input, morph);
#ifdef DEBUG
      cout << " morpheme `" << morph <<"'\n";
#endif
      delete_morpheme(start, morph, dp);
      for (set<state*>::iterator dp1 = unproc_cycle_addr->begin();
	   dp1 != unproc_cycle_addr->end(); dp1 = unproc_cycle_addr->begin()) {
	delete_morpheme(*dp1, morph, dp);
      }
    }//while
  }//while
#ifdef DEBUG
  cout << "end of deletions\n";
#endif
}
 #endif

#ifdef MINIMIZE
/* Name:	build_states_vector
 * Class:	None.
 * Space:	None.
 * Purpose:	Puts all states of an automaton into a vector.
 * Parameters:	v		- (o) vector of pointers to states;
 *		s		- (i) initial state.
 * Returns:	Nothing.
 * Remarks:	This is necessary for minimization.
 *		Marked states are not considered.
 */
void
build_states_vector(vector<state *> &v, state *s)
{
  if (!(s->is_marked())) {
    s->mark();
    v.push_back(s);
    trans_vec &tv = s->get_transitions();
    for (trans_vec::iterator tvi = tv.begin(); tvi != tv.end(); tvi++) {
      build_states_vector(v, tvi->get_target());
    }
  }
}//build_states_vector
#endif

#ifndef NFA
/* Name:	parse_desc
 * Class:	None.
 * Space:	None.
 * Purpose:	Parses a dictionary description and builds a finite automaton.
 * Parameters:	input		- (i) input stream.
 * Returns:	The initial state of a finite automaton built from description.
 * Globals:	cycle_name	- (i/o) cyclic state to class mapping;
 *		cycle_addr	- (i/o) cyclic class to states mapping;
 *		unproc_cycle_addr
 *				- (i/o) unprocessed states from cycle_addr;
 *		current_class	- (o) name of the currently processed class.
 * Remarks:	The format of the input is as follows:
 *		<Description> ::= (<Declaration> | <Definition>)...
 *				  [<Morpheme>...].
 *		<Declaration> ::= <CyclicDecl> | <ForgetDecl> | <AcyclicDecl>.
 *		<CyclicDecl> ::= "Cyclic" ":" <Identifier>... ";".
 *		<ForgetDecl> ::= "Forget" ":" <Identifier>... ";".
 *		<AcyclicDecl> ::= "Acyclic" ":" <Morpheme>... ";".
 *		<Definition> ::= <CurrClassName> "{" <NextMorphemes>... "}".
 *		<CurrClassName> ::= <Identifier>.
 *		<NextMorphemes> ::= <NextClassName> <Morpheme>... ";".
 *		<NextClassName> ::= <Identifier>.
 *
 *		An identifier is a sequence of ISO8859-* letters, numbers,
 *		underscore characters, beginning with a letter. Identifiers
 *		are case-sensitive.
 *
 *		Morphemes are sequences of valid letters in the language,
 *		enclosed in double quotes.
 *
 *		All NextClassNames must be declared or defined earlier.
 *		There is a predefined NextClassName NULL. It has no morphemes,
 *		and no next classes. A class named Root should be defined
 *		by the user. The language of class Root is the language
 *		of the whole dictionary/automaton.
 *
 *		CyclicDecl is recognized only when compile-time option
 *		WITH_CYCLES is defined. Classes declared with CyclicDecl
 *		can be used as next classes before they are defined.
 *		This technique is used in order to obtain cyclic automata.
 *
 *		ForgetDecl should be used after all definitions. The arguments
 *		should be the names of all classes except for Root.
 *		Note: in the future, I might just takes this from a dictionary
 *		of classes, so ForgetDecl may disappear.
 *
 *		AcyclicDecl is recognized only when compile-time options
 *		CARFOR or SORTED are defined. Only one of them can be defined.
 *		If SORTED is defined, then morphemes on the list should be
 *		lexicographically sorted. The morphemes will be added
 *		to the class Root using either an algorithm
 *		by Rafael C. Carrasco and Mikel L. Forcada published
 *		in Computational Linguistics 28(2), June 2002 (with CARFOR),
 *		or my generalized algorithm for sorted data (with SORTED).
 *		The next class for those morphemes is assumed to be NULL.
 *		This declaration should be the last in the whole description.
 *		In addition, compile-time option WITH_CYCLES should be defined.
 *
 *		If the compile-time option TRANSDUCER is defined, morphemes
 *		in definition of classes can be replaced with morpheme pairs,
 *		separated with a slash. Not every morpheme needs to be replaced
 *		- those that are not define pairs of identical morphemes.
 *
 *		If compile-time option TEST is defined, the whole description
 *		may end with a list of morphemes to be tested. The compiler
 *		will print OK for those that are in the language of the class
 *		Root. Note that the word "morpheme" used here refers to
 *		a particular format of input. What should be put between
 *		double quotes is rather words than linguistic morphemes.
 */
state *
parse_desc(istream &input)
{
  using namespace lex;

  symbol symb;
  mystr str;
  map<mystr,pair<state *,int> > dictionary;
  state *sink = new state;
  sink->set_final();
  Register.get_or_put(sink);
  sink->hit();			// make it reentrant state that must be cloned
  state *initial_state = NULL;
  dictionary["NULL"] = pair<state *,int>(sink, CONTCL);
#if defined(WITH_CYCLES)
#ifndef EARLY_START
  closing_cycles_phase = false;
#endif //EARLY_START
  unproc_cycle_addr = new set<state*>;
#endif //WITH_CYCLES
  while ((symb = get_symbol(input)) != end_of_description) {
    if (symb == identifier) {
      str = get_string(true);


      // Handle "Cyclic:" directive
#ifdef WITH_CYCLES
      if (str == "Cyclic") {
	// Handle "Cyclic:" directive
	cyclic_dir(dictionary, input);
      }
      else
#endif //WITH_CYCLES


      // Handle "Forget:" directive
      if (str == "Forget") {
	forget_dir(dictionary, input);
      } // if str == "Forget"


      // Handles "Acyclic:" directive
#if defined(CARFOR) || defined(SORTED) || defined(UNSORTED) || defined(WATCYC)
      else if (str == "Acyclic") {
	acyclic_dir(dictionary, input);
#ifdef PRINT_AUT
	cout << "After addition of simple strings\n";
	print_states(dictionary["Root"].first, dictionary);
	unmark_states(dictionary["Root"].first);
#endif
      }
#endif


      // Handle continuation class definition
      else {
	// This is the continuation class description
	// First get and process its name
	mystr class_name = get_string(true);
	mystr next_class_name;
	map<mystr, pair<state *,int> >::iterator dp =
	  dictionary.find(class_name);
	bool is_cyclic = false;
	if (dp != dictionary.end()) {
#ifdef WITH_CYCLES
	  if (dictionary[class_name].second != CYCLIC) {
	    complain(symb, "Continuation class already defined");
	    exit(1);
	  }
	  else {
#endif //WITH_CYCLES
	    is_cyclic = true;
#ifdef WITH_CYCLES
	  }
#endif //WITH_CYCLES
	}//if class already declared
	if ((symb = get_symbol(input)) != left_brace) {
	  complain(symb, "Left brace expected");
	  exit(1);
	}
	state *start = is_cyclic ? dp->second.first : new state;
#ifdef DEBUG
	cout << "Processing class " << class_name << "\n";
	cout.flush();
#endif //DEBUG
#ifdef WITH_CYCLES
	current_class = class_name;
	if (is_cyclic) {
	  current_class_no = class_number[current_class];
	  // Cyclic states are already preregistered
	  // With EARLY_START, cyclic states are removed from Register
	  // in add_string_with_root
#ifndef EARLY_START
	  Register.remove(start);
#endif
	  // The state will be reregistered in minim_root
	}
	else {
	  current_class_no = -1;
	}
#endif
	// Process morphemes leading to one next continuation class
	while ((symb = get_symbol(input)) == identifier) {
	  next_class_name = get_string(true);
	  dp = dictionary.find(next_class_name);
	  if (dp == dictionary.end()) {
	    complain(symb, "Unknown continuation class");
	    exit(1);
	  }
#ifdef DEBUG
	  cout << " next class " << next_class_name << "\n";
	  cout.flush();
#endif //DEBUG


#if defined(WITH_CYCLES) && defined(EARLY_START)
	  if (is_cyclic) {

	  // This part handles totally incremental addition
	    symb = get_symbol(input);
	    while (symb == morpheme) {
	      swap(unproc_cycle_addr,cycle_addr[current_class_no]);
	      // Add the string to every state representing the class
	      int morpheme_repeat = 0;
	      labelstr morph;
	      symb = get_morpheme(input, morph);
#ifdef DEBUG
	      cout << "  morpheme `" << morph << "'\n";
	      cout.flush();
#endif //DEBUG
	      for (set<state*>::iterator dp1 = unproc_cycle_addr->begin();
		   dp1 != unproc_cycle_addr->end();
		   dp1 = unproc_cycle_addr->begin()) {
		state *s1;
		if (morpheme_repeat == 0 ||
		    (*dp1)->next(morph) != dp->second.first) {
		  s1 = add_string_with_root(*dp1, morph, dp->second.first, 1);
		}
		else {
		  s1 = *dp1;
		  unproc_cycle_addr->erase(s1);
		  cycle_addr[current_class_no]->insert(s1);
		}
		morpheme_repeat++;
		if (s1 == *dp1) {
		  // *dp1 not deleted
		  set<state*>::iterator pp;
		  if ((pp = unproc_cycle_addr->find(s1))
		      != unproc_cycle_addr->end()) {
		    cerr << "Something wrong, s1 in unproc\n";
		    unproc_cycle_addr->erase(pp);
		  }
		  if ((pp = cycle_addr[current_class_no]->find(s1))
		      == cycle_addr[current_class_no]->end()) {
		    cerr << "Something wrong, s1 not in cycle_addr\n";
		    cycle_addr[current_class_no]->insert(s1);
		  }
		}// *dp1 (currently processed cyclic state) not deleted

		if (s1 == NULL) {
		  s1 = dictionary[class_name].first;
		}
#if defined(DETAILED_PROGRESS) || (defined(PRINT_MORPH) && (defined(PRINT_AUT) || defined(PRINT_DICT))) || defined(CHECK_REGISTER) || defined(SANITY_CHECK)
		perform_checks1(dictionary, morpheme_repeat, s1);
#endif
	      }//for every cyclic state representing a continuation class
	    }//while symbol is morpheme
	  }//if continuation class is declared as cyclic
	  else {
#endif //WITH_CYCLES&&EARLY_START

	    // This part handles acyclic case, acyclic states in EARLY_START
	    // and semi-incremental addition
	    symb = get_symbol(input);
	    labelstr morph;
	    while (symb == morpheme) {
	      symb = get_morpheme(input, morph);
#ifdef DEBUG
	      cout << "  morpheme `" << morph << "'\n";
	      cout.flush();
#endif //DEBUG
	      start = add_string_with_root(start, morph,
					   dp->second.first,
//#if defined(WITH_CYCLES) && !defined(EARLY_START)
//					     (start->is_cyclic() ? 1 : 0)
//#else
					   0
//#endif
					   );
#if defined(DETAILED_PROGRESS) || defined(CHECK_REGISTER) || (defined(PRINT_MORPH) && (defined(PRINT_AUT) || defined(PRINT_DICT)))
	      perform_checks2(dictionary, start);
#endif
	    }//while symbol is a morpheme
#if defined(WITH_CYCLES) && defined(EARLY_START)
	  }//if continuation class is not declared as cyclic
#endif //WITH_CYCLES&&EARLY_START

	  // This part is common for WITH_CYCLES (both) and without them
	  if (symb != semicolon) {
	    complain(symb, "Semicolon expected");
	    exit(1);
	  }
	}//while symbol is an identifier
	if (symb != right_brace) {
	  complain(symb, "Right brace expected");
	  exit(1);
	}

	// All morphemes for the continuation class definition already added
	start = minim_root(start);
	start->hit();
#if defined(DELETE) && defined(WITH_CYCLES) && !defined(DEL_CYCL)
	dictionary[class_name] = pair<state *,int>(start, CYCLIC);
#else
	dictionary[class_name] = pair<state *,int>(start, is_cyclic ?
						   CYCLIC : CONTCL);
#endif
#if defined(WITH_CYCLES) && !defined(EARLY_START)
	close_cycles(is_cyclic, current_class_no, class_name, start,
		     dictionary);
#endif
#if defined(WITH_CYCLES) && defined(DEL_CYCL)
	// Delete cyclic markers, replace cyclic states with equivalent
	if (is_cyclic) {
	  for (set<state*>::iterator ccp =
		 cycle_addr[current_class_no]->begin();
	       ccp != cycle_addr[current_class_no]->end();
	       ccp = cycle_addr[current_class_no]->begin()) {
	    state *dsp = *ccp;
	    Register.remove(dsp);
	    set<int> *ms1 = cycle_number[dsp];
	    ms1->erase(current_class_no);
	    if (ms1->size() == 0) {
	      cycle_number.erase(dsp);
	      dsp->unset_cyclic();
	    }
	    cycle_addr[current_class_no]->erase(dsp);
	    state *dspr;
	    if ((dspr = Register.get_or_put(dsp)) != dsp) {
	      redirect(dsp, dspr);
	      if (dsp == start) {
		dictionary[class_name] = pair<state *,int>(dspr, CYCLIC);
	      }
	    }
	  }
	}
#endif
#ifdef PRINT_AUT
	cout << "After addition of class " << class_name << "\n";
	print_states(start, dictionary);
	unmark_states(start);
#endif //PRINT_AUT
#ifdef PRINT_DICT
	  print_dict(cout, dictionary);
#endif //PRINT_DICT
      }//if this is a description of a continuation class
    }//if the symbol is an identifier
#if defined(DELETE) && defined(WITH_CYCLES) && !defined(DEL_CYCL)
    else if (symb == minus) {
      handle_deletion(dictionary, input);
    }
#endif
#ifdef TEST
    else if (symb == morpheme) {
      break;
    }
#endif //TEST
    else {
      complain(symb, "Identifier expected");
      exit(1);
    }
  }
  initial_state = dictionary["Root"].first;
#if !defined(NFA) && defined(DEL_CL)
  for (map<mystr,pair<state *,int> >::iterator cisp = dictionary.begin();
       cisp != dictionary.end(); cisp++) {
    if (cisp->second.first != initial_state) {
#ifdef WITH_CYCLES
      if (cisp->second.second == CYCLIC) {
	cisp->second.first->hit(-2);
      }
#endif
      if (cisp->second.first->hit(0) <= 1) {
	delete_branch(cisp->second.first);
      }
    }
  }
#endif
#ifdef MINIMIZE
  vector<state *> aut_states;
  build_states_vector(aut_states, initial_state);
  unmark_states(initial_state);
  initial_state = minimize(aut_states);
#endif //MINIMIZE
#if defined(WITH_CYCLES) && !defined(EARLY_START)
#ifdef PRINT_AUT
  cout << "States reachable from Root:\n";
  print_states(initial_state, dictionary);
  unmark_states(initial_state);
#endif //PRINT_AUT
#endif //WITH_CYCLES&&!EARLY_START
#ifdef STATS
  int reach = reachable(initial_state);
  int tot = initial_state->get_total_states();
  int maxs = initial_state->get_max_states();
  unmark_states(initial_state);
  cout << "Total number of states: " << tot << "\n";
  cout << "Max number of states: " << maxs << "\n";
  if (reach == tot) {
    cout << "No unreachable states\n";
  }
  else {
    cout << tot - reach << " unreachable states\n";
  }
#endif //STATS
#ifdef TEST
  while (symb == morpheme) {
    cout << "Testing " << get_string(false) << "\n";
    cout << (test_string(initial_state, get_string(false).c_str())
	     ? "OK" : "failed")
	 << "\n";
    symb = get_symbol(input);
  }
#endif //TEST
  return initial_state;
}//parse_desc
#endif //!NFA

#ifdef NFA
/* Name:	nfa_add_morpheme
 * Class:	None.
 * Space:	None.
 * Purpose:	Adds a morpheme between states start and target.
 * Parameters:	start		- (i/o) start (source) state;
 *		str		- (i) the morpheme to be added;
 *		target		- (i) target state;
 * Globals:	None.
 * Remarks:	A trie is built from "start". The last symbol, instead
 *		of leading to a leaf, leads to the target state.
 *		In case of empty morphemes or prefixes, epsilon transitions
 *		are created.
 *		Because the mechanism for adding transitions excludes
 *		two transitions for the same state with the same labels,
 *		we cannot have two outgoing epsilon-transitions either.
 *		Therefore, we have to create a chain of epsilon transitions.
 */
state *
nfa_add_morpheme(state *start, labelstr str, state *target)
{
  if (str.length() == 0) {
    // Empty morpheme
    start->nfa_set_next(EMPTY_TRANS, target);
  }
  else {
    unsigned int i;
    state *q;
    state *p = start;
    for (i = 0; i < str.length() - 1; i++) {
      p->nfa_set_next(str[i], (q = new state));
      p = q;
    }
    p->nfa_set_next(str[i], target);
  }
  return start;
}//nfa_add_morpheme

/* Name:	epsilon_closure
 * Class:	None.
 * Space:	None.
 * Purpose:	Computes an epsilon-closure for a set of NFA states.
 * Parameters:	closure		- (i/o) set of NFA states / their closure.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	None.
 */
void
epsilon_closure(set<state *> *closure)
{
  set<state *> unproc = *closure;
  for (set<state *>::iterator i = unproc.begin(); i != unproc.end();
       i = unproc.begin()) {
    trans_vec &tv = (*i)->get_transitions();
    for (trans_vec::iterator t = tv.begin(); t != tv.end(); t++) {
      if ((*t).get_label() == EMPTY_TRANS &&
	  closure->find((*t).get_target()) == closure->end() &&
	  unproc.find((*t).get_target()) == unproc.end()) {
	unproc.insert((*t).get_target());
	closure->insert((*t).get_target());
      }
    }
    unproc.erase(i);
  }
}//epsilon_closure

/* Name:	nfa_del_aut
 * Class:	None.
 * Space:	None.
 * Purpose:	Deletes an automaton.
 * Parameters:	start		- (i/0) initial state.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	States are marked to avoid double deletion.
 *		Simple "delete start" is not suffcient in presence of loops.
 *
 *		Another shit in STL: reverse_iterator does not work at all.
 */
void
nfa_del_aut(state *start)
{
  vector<state *> all_states;
  vector<trans_vec::iterator> mystack;

  if (start) {
    start->mark();
    all_states.push_back(start);
    trans_vec &tv = start->get_transitions();
    for (trans_vec::iterator r = tv.begin(); r != tv.end(); r++) {
      mystack.push_back(r);
    }
    while (mystack.size()) {
      trans_vec::iterator t = mystack.back();
      mystack.pop_back();
      state *s;
      if (!((s = t->get_target())->is_marked())) {
	s->mark();
	all_states.push_back(s);
	trans_vec &v = s->get_transitions();
	for (trans_vec::iterator i = v.begin(); i != v.end(); i++) {
	  mystack.push_back(i);
	}
      }
    }
    for (unsigned int j = 0; j < all_states.size(); j++) {
      all_states[j]->get_transitions().clear();
      all_states[j]->get_intransitions().clear();
      delete all_states[j];
    }
  }
}//nfa_del_aut

/* Name:	determinize
 * Class:	None.
 * Space:	None.
 * Purpose:	Determinizes a non-deterministic automaton.
 * Parameters:	start		- (i) intial state of the NFA to determinize.
 * Returns:	Initial state of an equivalent deterministic automaton.
 * Globals:	None.
 * Remarks:	None.
 */
vector <state *> *
determinize(state *start)
{
  state *new_start;		// start state of the DFA
  // states of DFA as single states
  vector<state *> *dfa_states = new vector<state *>;
  vector<set<state *> *> dfa(1);	// sets of DFA as sets of states of NFA
  // set of DFA states (set of sets of NFA states)
  map<set<state*>,int> dfa_sets;
  dfa[0] = new set<state *>;
  dfa[0]->insert(start);
  epsilon_closure(dfa[0]);
  //dfa_sets.insert(0);
  dfa_sets[*(dfa[0])] = 0;
  // vector of transition vectors for all NFA states in one DFA state
  vector<trans_vec *> vvt;
  // vector of iterators for transition vectors
  vector<trans_vec::iterator> vti;
  int curr_state_no = 0;
  dfa_states->push_back(new_start = new state);
  map<labelchar,int> int_trans;
  unsigned int first_to_check = 1; // first state to be checked for equivalence
  // For every new state of DFA, starting from the start state
  for (unsigned int s = 0; s < dfa.size(); s++) {
    int_trans.clear();
    // For every NFA state of the current DFA state
    set<state *> *sp = dfa[s];
    for (set<state *>::iterator p = sp->begin(); p != sp->end(); p++) {
      trans_vec &tv = (*p)->get_transitions();
      // Calculate set of NFA states - target of transitions from s
      for (unsigned int tvi = 0; tvi < tv.size(); tvi++) {
	labelchar lab;
	if ((lab = tv[tvi].get_label()) != EMPTY_TRANS) {
	  int tg;		// target state number
	  if (int_trans.find(lab) == int_trans.end()) {
	    // New label on out-transitions of DFA state
	    // Create a new DFA state
	    int_trans[lab] = tg = dfa.size();
	    dfa.push_back(new set<state *>);
	  }
	  else {
	    // Existing label on out-transitions of DFA state
	    tg = int_trans[lab];
	  }
	  if (dfa[tg]->find(tv[tvi].get_target()) == dfa[tg]->end()) {
	    // NFA state not among targets of NFA states constituting DFA state
	    // Include it
	    dfa[tg]->insert(tv[tvi].get_target());
	  }
	}
      }
    }
    // Check if newly created states are unique
    int sn = first_to_check;
    int nsn = sn;
    int reduced = 0;
    vector<int> redir(dfa.size() - first_to_check);
    for (unsigned int ns = first_to_check; ns < dfa.size(); ns++) {
      map<set<state*>,int>::iterator esi;
      epsilon_closure(dfa[ns]);
      if ((esi = dfa_sets.find(*(dfa[ns]))) != dfa_sets.end()) {
	// Equivalent state found
	redir[sn - first_to_check] = (*esi).second;
	delete dfa[sn];
	reduced++;
      }
      else {
	redir[sn - first_to_check] = nsn;
	if (sn != nsn) {
	  dfa[nsn] = dfa[sn];
	}
	dfa_sets[*(dfa[ns])] = nsn++;
	dfa_states->push_back(new state);
	for (set<state *>::iterator x = dfa[ns]->begin();
	     x != dfa[ns]->end(); x++) {
	  if ((*x)->is_final()) {
	    dfa_states->back()->set_final();
	  }
	}
      }
      sn++;
    }
    // Set transitions for the DFA state
    for (map<labelchar,int>::iterator ni = int_trans.begin();
	 ni != int_trans.end(); ni++) {
      (*dfa_states)[curr_state_no]->set_next((*ni).first,
		     (*dfa_states)[redir[(*ni).second - first_to_check]]);
    }
    curr_state_no++;
    while (reduced) {
      dfa.pop_back();
      --reduced;
    }
    first_to_check = dfa.size();
  }
  nfa_del_aut(start); 		// delete start;
  return dfa_states;
}//determinize
#endif

#if defined(NFA) || defined(MINIMIZE)
class block_item {
public:
  int           state_no;       // state number
  block_item    *prev;          // previous item
  block_item    *next;          // next item
  block_item(const int i, block_item *n = NULL)
    : state_no(i), prev(NULL), next(n) { if (n) { n->prev = this; }}
};//block_item

class block_start {
public:
  int           items;          // counter
  block_item    *first;         // first item
  block_start(void) : items(0), first(NULL) {}
  void put(const int i) { first = new block_item(i, first); items++; }
};//block_start

/* Name:	minimize
 * Class:	None.
 * Space:	None.
 * Purpose:	Minimizes a DFA.
 * Parameters:	states		- (i/o) vector of states.
 * Returns:	Initial state of the vector.
 * Globals:	None.
 * Remarks:	Hopcroft minimization algorithm is used.
 *		Although we do have back transitions for cyclic automata
 *		here, they are useless for this algorithm.
 *		The algorithm wants a constant time calculation
 *		of a block number for a given state, and this cannot be
 *		done on pointers. Therefore, we have to recreate
 *		back transitions with integer targets - indexes in states vec.
 *		I know it sucks, but it seems the only way to maintain
 *		computational complexity.
 */
state *
minimize(vector<state *> &states)
{
  vector<bool> inwaiting(states.size());
  // Blocks (classes) of potentially equivalent states
  block_start *block = new block_start[states.size()];
  // Block numbers for states
  int *inblock = new int[states.size()];
  block_item **bip = new block_item *[states.size()];
  // Build state -> state number relation
  map<state *, int> state_no;
  for (unsigned int s1 = 0; s1 < states.size(); s1++) {
    state_no[states[s1]] = s1;
  }
  // Construct back transitions vector, find the set of all labels,
  // and set initial blocks
  set<labelchar> labels;
  vector<pair<labelchar, int> > backtrans;// back transitions
  // First back transition in backtrans for a state
  vector<int> backstart(states.size());
  int back_st = 0;
  for (unsigned int s2 = 0; s2 < states.size(); s2++) {
    trans_vec &tv = states[s2]->get_transitions();
    for (trans_vec::iterator tt = tv.begin(); tt != tv.end(); tt++) {
      if (labels.find((*tt).get_label()) == labels.end()) {
	labels.insert((*tt).get_label());
      }
    }
    // Put the state to the appropriate block and set inblock correctly
    block[(inblock[s2] = (states[s2]->is_final() ? 1 : 0))].put(s2);
    bip[s2] = block[inblock[s2]].first;
    backstart[s2] = back_st;
    trans_vec &itv = states[s2]->get_intransitions();
    for (trans_vec::iterator itt = itv.begin(); itt != itv.end(); itt++) {
      back_st++;
      backtrans.push_back(pair<labelchar,int>(itt->get_label(),
					      state_no[itt->get_target()]));
    }
  }
  state_no.clear();		// no longer need this
  // A queue of blocks to be processed
  int *waiting = new int[states.size()];
  // States that have transitions to the states of the current block
  int *inverse = new int[states.size()]; // because inverse can be > block[i]
  // Initially there are two blocks: non-final states
  waiting[0] = 0; inwaiting[0] = true;
  // and final states
  waiting[1] = 1; inwaiting[1] = true;
  int *jcount = new int[states.size()];
  for (unsigned int jc1 = 0; jc1 < states.size(); jc1++) jcount[jc1] = 0;
  // The first position in the queue to be processed
  int w_start = 0;
  // The first free place in the queue (end of the queue)
  int q = 2;
  while (w_start < q) {
    inwaiting[waiting[w_start]] = false;
    for (set<labelchar>::iterator lptr = labels.begin(); lptr != labels.end();
         lptr++) {
      labelchar ll = *lptr;
      int inv_count = 0;
      vector<bool> in_inverse(states.size());
      // For all states in the block
      for (block_item *bs = block[waiting[w_start]].first; bs; bs = bs->next) {
        int bst = backstart[bs->state_no];
        for (unsigned int tn1 = bst;
	     tn1 < bst + states[bs->state_no]->get_intransitions().size();
	     tn1++) {
          // Construct inverted
          if (backtrans[tn1].first == ll &&
	      !in_inverse[backtrans[tn1].second]) {
            inverse[inv_count++] = backtrans[tn1].second;
            in_inverse[backtrans[tn1].second] = true;
          }
        }
      }//for bs
      /*!!! CHECK FROM HERE !!!*/
      // Construct jlist
      // jlist is a list of blocks that have transitions leading to the current
      // block, jcount counts states in those blocks
      if (inv_count) {
        int jn = 0;
        int *jlist = new int[inv_count];
        for (int ic = 0; ic < inv_count; ic++) {
          if (jcount[inblock[inverse[ic]]]++ == 0) {
            jlist[jn++] = inblock[inverse[ic]];
          }
        }
        // For each j such that B[j] & INVERSE != 0 and B[j] not in INVERSE
        for (int jl = 0; jl < jn; jl++) {
          if (jcount[jlist[jl]] < block[jlist[jl]].items) {
            int j = jlist[jl];
            for (int ic1 = 0; ic1 < inv_count; ic1++) {
              if (inblock[inverse[ic1]] == j) {
                // Element in intersection
                // Move to B[q]
                block_item *bp = bip[inverse[ic1]];
                block[q].items++;
                if (bp->next) {
                  bp->next->prev = bp->prev;
                }
                if (bp->prev) {
                  bp->prev->next = bp->next;
                }
                else {
                  block[inblock[bp->state_no]].first = bp->next;
                }
                --block[inblock[bp->state_no]].items;
                inblock[bp->state_no] = q;
                bp->next = block[q].first; bp->prev = NULL;
                block[q].first = bp;
                if (bp->next) {
                  bp->next->prev = bp;
                }
              }//if element in intersection
            }//for ic1
            // Update waiting list
            if (inwaiting[j]) {
              waiting[q] = q; inwaiting[q] = true;
            }
            else if (block[j].items <= block[q].items) {
              waiting[q] = j; inwaiting[j] = true;
            }
            else {
              waiting[q] = q; inwaiting[q] = true;
            }
            q++;
          }//if
          jcount[jlist[jl]] = 0;
        }//for jl
        delete [] jlist;
      }//if inv_count
    }// for ll
    w_start++;
  }//while w_start < q
  delete [] jcount;
  delete [] bip;
  delete [] waiting;
  delete [] inverse;

  // Prevent automatic deletion
  for (vector<state *>::iterator s3 = states.begin(); s3 != states.end();
       s3++) {
    (*s3)->hit();
  }
  for (unsigned int bs2 = 0; bs2 < states.size(); bs2++) {
    if (block[inblock[bs2]].first->state_no != (int)bs2) {
      // Redirect transition
      unsigned int in_ts = states[bs2]->get_intransitions().size();
      for (unsigned int bs3 = 0; bs3 < in_ts; bs3++) {
	int source = backtrans[bs3 + backstart[bs2]].second;
	states[source]->set_next(backtrans[bs3 + backstart[bs2]].first,
				 states[block[inblock[bs2]].first->state_no]);
      }
    }
  }
  // Remove redundant states
  for (unsigned int s4 = 0; s4 < states.size(); s4++) {
    if (block[inblock[s4]].first->state_no != (int)s4) {
      delete states[s4];
      states[s4] = NULL;
    }
  }
  // restore hit count
  for (unsigned int s5 = 0; s5 < states.size(); s5++) {
    if (states[s5]) {
      states[s5]->hit(-1);
    }
  }
  state *new_start = states[block[inblock[0]].first->state_no];
  delete [] inblock;
  delete [] block;
  return new_start;
}//minimize
#endif //NFA|MINIMIZE

#ifdef NFA
/* Name:	nfa_parse_desc
 * Class:	None.
 * Space:	None.
 * Purpose:	Parses a dictionary description and builds a finite automaton
 *		using the traditional method: NFA, determinization,
 *		minimization.
 * Parameters:	input		- (i) input stream.
 * Returns:	The initial state of a finite automaton built from description.
 * Globals:
 * Remarks:
 */
state *
nfa_parse_desc(istream &input)
{
  using namespace lex;

  symbol symb;
  mystr str;
  map<mystr,pair<state *,int> > dictionary;
  state *sink = new state;
  sink->set_final();
  dictionary["NULL"] = pair<state *,int>(sink, CONTCL);
  while ((symb = get_symbol(input)) != end_of_description) {
    if (symb == identifier) {
      str = get_string(true);
      if (str == "Cyclic") {
	// Handle "Cyclic:" directive
	if (get_symbol(input) == colon) {
	  while ((symb = get_symbol(input)) == identifier) {
	    if (dictionary.find(get_string(true)) != dictionary.end()) {
	      complain(symb, "Continuation class already defined");
	      exit(1);
	    }
	    state *s = new state;
	    s->hit(2);		// make it reentrant state that must be cloned
	    mystr cyc_name = get_string(true);
	    dictionary[cyc_name] = pair<state *, int>(s, CONTCL);
	  }
	  if (symb != semicolon) {
	    complain(symb, "Semicolon expected");
	    exit(1);
	  }
	}
	else {
	  complain(symb, "Colon expected");
	  exit(1);
	}
      }
      else {
	mystr class_name = get_string(true);
	mystr next_class_name;
	map<mystr, pair<state *,int> >::iterator dp =
	  dictionary.find(class_name);
	bool is_cyclic = false;
	if (dp != dictionary.end()) {
	  is_cyclic = true;
	}//if class already declared
	if ((symb = get_symbol(input)) != left_brace) {
	  complain(symb, "Left brace expected");
	  exit(1);
	}
	state *start = is_cyclic ? dp->second.first : new state;
#ifdef DEBUG
	cout << "Processing class " << class_name << "\n";
	cout.flush();
#endif //DEBUG
	// Process morphemes leading to one next continuation class
	while ((symb = get_symbol(input)) == identifier) {
	  next_class_name = get_string(true);
	  dp = dictionary.find(next_class_name);
	  state *target = NULL;
	  if (dp == dictionary.end()) {
	    // New class, not defined yet. Create its starting state
	    dictionary[next_class_name] =
	      pair<state *,int>((target = new state), CONTCL);
	  }
	  else {
	    target = dp->second.first;
	  }
#ifdef DEBUG
	  cout << " next class " << next_class_name << "\n";
	  cout.flush();
#endif //DEBUG
	  symb = get_symbol(input);
	  while (symb == morpheme) {
	    labelstr morph;
	    symb = get_morpheme(input, morph);
	    nfa_add_morpheme(start, morph, target);
	  }
	  if (symb != semicolon) {
	    complain(symb, "Semicolon expected");
	    exit(1);
	  }
	}//while symbol is an identifier
	if (symb != right_brace) {
	  complain(symb, "Right brace expected");
	  exit(1);
	}
	dictionary[class_name] = pair<state *,int>(start, CONTCL);
      }//if this is a description of a continuation class
    }//if the symbol is an identifier
#ifdef TEST
    else if (symb == morpheme) {
      break;
    }
#endif //TEST
    else {
      complain(symb, "Identifier expected");
      exit(1);
    }
  }
  state *initial_state = dictionary["Root"].first;
  vector <state *> *all_states = determinize(initial_state);
  initial_state = minimize(*all_states);
#ifdef PRINT_AUT
  cout << "States reachable from Root:\n";
  print_states(initial_state, dictionary);
  unmark_states(initial_state);
#endif //PRINT_AUT
#ifdef STATS
  int reach = reachable(initial_state);
  int tot = initial_state->get_total_states();
  int maxs = initial_state->get_max_states();
  unmark_states(initial_state);
  cout << "Total number of states: " << tot << "\n";
  cout << "Max number of states: " << maxs << "\n";
  if (reach == tot) {
    cout << "No unreachable states\n";
  }
  else {
    cout << tot - reach << " unreachable states\n";
  }
#endif //STATS
#ifdef TEST
  while (symb == morpheme) {
    cout << "Testing " << get_string(false) << "\n";
    cout << (test_string(initial_state, get_string(false).c_str())
	     ? "OK" : "failed")
	 << "\n";
    symb = get_symbol(input);
  }
#endif //TEST
  return initial_state;
}//nfa_parse_desc
#endif

#if defined(GERTJAN)
#include "saveaut.cc"
#endif

#ifndef WITH_CYCLES
/* Name:	list_contents
 * Class:	None.
 * Space:	None.
 * Purpose:	Lists contents of the automaton (set of strings).
 * Parameters:	start		- (i) start state of a subautomaton;
 *		prefix		- (i) prefix of words of the aubautomaton.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	The automaton is printed on standard output.
 *		This function is defined only for acyclic automata.
 */
void
list_contents(const state *start, mystr &prefix)
{
  if (start->is_final()) {
    cout << prefix << "\n";
  }
  const trans_vec &tv = start->get_transitions();
  for (int i = 0; i < start->fan_out(); i++) {
    prefix += tv[i].get_label();
    list_contents(tv[i].get_target(), prefix);
    prefix.resize(prefix.size()-1);
  }
}//list_contents
#endif

/* Name:	usage
 * Class:	None.
 * Space:	None.
 * Purpose:	Explains the program use.
 * Parameters:	None.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	None.
 */
void
usage(void)
{
  cerr << "Usage:\nccip [options] [filename]\n\nIf filename not specified, "
    "standard input is used.\n\nOptions:\n-v\n\t- prints compile options\n"
#ifndef WITH_CYCLES
    "-l\t- lists contents of the automaton\n"
#endif
#ifdef GERTJAN
    "-o filename\t- saves the automaton in Gertjan van Noord's fsa format\n"
#endif
    ;
}//usage

/* Name:	print_options
 * Class:	None.
 * Space:	None.
 * Purpose:	Prints compile options (-Dxxx) with which the program
 *		was compiled.
 * Parameters:	None.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	None.
 */
void
print_options(void)
{
  cout << "Version 0.2, 25th May 2005\n";
#ifdef DEBUG
  cout << "Compiled with DEBUG - prints processed continuation classes"
    " and morphemes\n";
#else
  cout << "Compiled without DEBUG - continuation classes and morphemes not"
    " printed\n";
#endif
#ifdef PRINT_AUT
  cout << "Compiled with PRINT_AUT - prints parts of the automaton\n"
    "\tstarting at the initial state of processed continuation class\n";
#else
  cout << "Compiled without PRINT_AUT - contents of automaton not printed\n";
#endif
#ifdef PRINTIN
#if defined(PRINT_AUT) && defined(WITH_CYCLES)
  cout << "Compiled with PRINTIN - in-transitions printed\n";
#else
  cout << "Compiled with PRINTIN - no effect since PRINT_AUT or WITH_CYCLES "
       << "not defined\n";
#endif
#else
#if defined(PRINT_AUT) && defined(WITH_CYCLES)
  cout << "Compiled without PRINTIN - in-transitions not printed\n";
#else
  cout << "Compiled without PRINTIN - no effect since PRINT_AUT or WITH_CYCLES"
       << " not defined\n";
#endif
#endif
#ifdef PRINT_DICT
  cout << "Compiled with PRINT_DICT - Contents of internal dictionaries "
    "printed\n";
#else
  cout << "Compiled without PRINT_DICT - No internal dictionaries printed\n";
#endif
#ifdef PRINT_MORPH
  cout << "Compiled with PRINT_MORPH - prints parts of automaton or dictionary"
    "\nafter each morpheme\tused only with PRINT_AUT or PRINT_DICT\n";
#else
  cout << "Compiled without PRINT_MORPH - automaton not printed after each "
    "morpheme\n";
#endif
#ifdef TEST
  cout << "Compiled with TEST - automaton specification followed by strings"
    "\n\tin double quotes to be tested for presence in the automaton\n";
#else
  cout << "Compiled without TEST - not test strings after automaton "
    "specification\n";
#endif
#ifdef WITH_CYCLES
  cout << "Compiled with WITH_CYCLES - cycles can be present,\n"
    "\tCyclic: declaration is recognized\n";
#ifdef EARLY_START
  cout << "Compiled with EARLY_START - morphemes are added to every "
    "incarnation\n\tof the initial state of every cyclic continuation class\n";
#else
  cout << "Compiled without EARLY_START - loops closed at the end\n";
#endif
#else
  cout << "Compiled without WITH_CYCLES - Cyclic: declaration not "
    "recognized\n";
#endif
#ifdef SANITY_CHECK
  cout << "Compiled with SANITY_CHECK - checking contents of the register\n";
#else
  cout << "Compiled without SANITY_CHECK - contents of the register not "
    "checked\n";
#endif
#ifdef STATS
  cout << "Compiled with STATS - some statistics printed\n";
#else
  cout << "Compiled without STATS - no statistics printed\n";
#endif
#ifdef CHECK_REGISTER
  cout << "Compiled with CHECK_REGISTER - register check for coherence\n";
#else
  cout << "Compiled without CHECK_REGISTER - register not checked\n";
#endif
#ifdef ENABLE_INCLUDE
  cout << "Compiled with ENABLE_INCLUDE - include directive recognized\n";
#else
  cout << "Compiled without ENABLE_INCLUDE - include directive not "
       << "recognized\n";
#endif
#ifdef DETAILED_PROGRESS
  cout << "Compiled with DETAILED_PROGRESS - detailed statistics printed\n";
#else
  cout << "Compiled without DETAILED_PROGRESS - no info on morpheme counts\n";
#endif
#ifdef GERTJAN
  cout << "Compiled with GERTJAN - automaton saved in Gertjan's format\n";
#else
  cout
    << "Compiled without GERTJAN - automaton not saved in Gertjan's format\n";
#endif
#ifdef CARFOR
  cout << "Compiled with CARFOR - Acyclic: recognized, Carrasco-Forcada method"
       << " used\n";
#else
  cout << "Compiled without CARFOR - Carrasco-Forcada method for adding words "
       << "not used\n";
#endif
#ifdef SORTED
  cout << "Compiled with SORTED - Acyclic: recognized, sorted data algorithm "
       << "used\n";
#else
  cout << "Compiled without SORTED - sorted data algorithm not used\n";
#endif
#ifdef UNSORTED
  cout << "Compiled with UNSORTED - Acyclic: recognized, unsorted data "
       << "algorithm used\n";
#else
  cout << "Compiled without UNSORTED - unsorted data algorithm not used\n";
#endif
#ifdef WATCYC
  cout << "Compiled with WATCYC - Acyclic: recognized, generalized Watson "
    "algorithm used\n";
#else
  cout << "Compiled without WATCYC - generalized Watson algorithm not used\n";
#endif
#ifdef TRANSDUCER
  cout << "Compiled with TRANSDUCER - program produces transducers\n";
#else
  cout << "Compiled without TRANSDUCER - program produces recognizers\n";
#endif
#ifdef NFA
  cout << "Compiled with NFA - traditional (NFA, determinization, minimization"
       << ") construction\n";
#else
  cout << "Compiled without NFA - incremental or semi-incremental construction"
       << "\n";
#endif
#ifdef DEL_CL
#ifdef NFA
  cout << "Compiled with DEL_CL - no effect since NFA active\n";
#else
  cout << "Compiled with DEL_CL - states without in-transitions deleted\n";
#endif//!NFA
#else//!DEL_CL
#ifdef NFA
  cout << "Compiled without DEL_CL - no effect since NFA active\n";
#else
  cout << "Compiled without DEL_CL - states with no in-transitions kept\n";
#endif//!NFA
#endif
#ifdef DEL_CYCL
#ifdef NFA
  cout << "Compiled with DEL_CYCL - no effect since NFA active\n";
#elif defined(WITH_CYCLES)
  cout << "Compiled with DEL_CYCL - cyclic markers removed after class "
    "definition\n";
#else
  cout << "Compiled with DEL_CYCL - no effect since WITH_CYCLES not active\n";
#endif//!NFA&&!WITH_CYCLES
#else//!DEL_CL
#ifdef NFA
  cout << "Compiled without DEL_CYCL - no effect since NFA active\n";
#else
  cout << "Compiled without DEL_CYCL - cyclic markers kept after class "
    "definition\n";
#endif//!NFA
#endif//!DEL_CL
#ifdef MINIMIZE
  cout << "Compiled with MINIMIZE - additional minimization at the end\n";
#else
  cout << "Compiled without MINIMIZE - no additional minimization\n";
#endif
#ifdef DELETE
#ifdef DEL_CYCL
  cout << "Compiled with DELETE - no effect since DEL_CYCL is defined\n";
#elif !defined(WITH_CYCLES)
  cout << "Compiled with DELETE - no effect since WITH_CYCLES not defined\n";
#else
  cout << "Compiled with DELETE - deletion of morphemes enabled\n";
#endif//!DEL_CYCL
#else
  cout << "Compiled without DELETE - deletion of morphemes disabled\n";
#endif
}//print_options

/* Name:	not_enough_memory
 * Class:	None.
 * Space:	None.
 * Purpose:	Inform the user that there is not enough memory and quit.
 * Parameters:	None.
 * Returns:	Nothing.
 * Globals:	None.
 * Remarks:	Called when there is not enough memory.
 */
void
not_enough_memory(void)
{
  cerr << "Not enough memory for the automaton\n";
  exit(4);
}//not_enough_memory


/* Name:	main
 * Class:	None.
 * Space:	None.
 * Purpose:	Launches the program.
 * Parameters:	argc		- (i) number of program parameters;
 *		argv		- (i) program parameters.
 * Returns:	Completion code.
 * Globals:	None.
 * Remarks:	Completion code:
 *		0	- OK
 *		1	- syntax error in input data
 *		2	- invalid invocation
 *		3	- file error
 *		4	- internal error (deleted stated used)
 */
int
main(const int argc, const char *argv[])
{
  const char *data_file_name = NULL;
#if defined(GERTJAN)
  const char *save_file_name = NULL;
#ifdef WITH_CYCLES
  const int MAX_ARGS = 4;
#else
  const int MAX_ARGS = 5;
#endif
#else
#ifdef WITH_CYCLES
  const int MAX_ARGS = 2;
#else
  const int MAX_ARGS = 3;
#endif
#endif
#ifndef WITH_CYCLES
  bool list_cont = false;
#endif
#ifdef MCHECK
  mtrace();
#endif
  state *initial_state;
  set_new_handler(&not_enough_memory);
  if (argc > MAX_ARGS) {
    usage();
    return 2;
  }
  else if (argc > 1) {
    for (int i = 1; i < argc; i++) {
      if (argv[i][0] == '-' && argv[i][1] == 'v') {
	print_options();
	return 0;
      }
      else if (argv[i][0] == '-' && argv[i][1] == 'l') {
#ifdef WITH_CYCLES
	cerr << "Option -l can only be used when ccip compiled without "
	     << "WITH_CYCLES\n";
	usage();
	return 2;
#else
	list_cont = true;
#endif
      }
      else if (argv[i][0] == '-' && argv[i][1] == 'o') {
#if defined(GERTJAN)
	i++;
	if (i > argc) {
	  cerr << "Missing file name for saving\n";
	  usage();
	  return 2;
	}
	save_file_name = argv[i];
#else
	cerr << "Option -o can only be used when ccip compiled with GERTJAN\n";
	usage();
	return 2;
#endif //GERTJAN
      }
      else if (argv[i][0] == '-') {
	usage();
	return 2;
      }
      else {
	data_file_name = argv[i];
      }
    }
  }
  if (data_file_name) {
    ifstream data_file(data_file_name);
    if (!data_file) {
      cerr << "Cannot read from " << data_file_name << "\n";
      return 3;
    }
#ifdef NFA
    initial_state = nfa_parse_desc(data_file);
#else
    initial_state = parse_desc(data_file);
#endif
    data_file.close();
  }
  else {
#ifdef NFA
    initial_state = nfa_parse_desc(cin);
#else
    initial_state = parse_desc(cin);
#endif
  }
#if defined(GERTJAN)
  if (save_file_name) {
    ofstream save_file(save_file_name);
    if (!save_file) {
      cerr << "Cannot write to " << save_file_name << "\n";
      return 3;
    }
    gertjan_save(initial_state, save_file);
  }
#endif
#ifndef WITH_CYCLES
  if (list_cont) {
    mystr init_str = "";
    list_contents(initial_state, init_str);
  }
#endif
#ifdef MCHECK
  muntrace();
#endif
//  cerr << "Test begins\n";
//  cout << (test_string(initial_state,
//			 "abschiedadlersoldateinheiten") ? "OK" : "failed")
//	 << "\n";
  return 0;
}//main

/***	EOF ccip.cc	***/
