#!/usr/bin/perl
eval 'exec /usr/bin/perl -S $0 ${1+"$@"}'
    if $running_under_some_shell;
			# this emulates #! processing on NIH machines.
			# (remove #! line above if indigestible)

eval '$'.$1.'$2;' while $ARGV[0] =~ /^([A-Za-z_0-9]+=)(.*)/ && shift;
			# 'process any FOO=bar switches

# This script divides a file with continuation classes into 3 parts
# The selected part is printed.
# Synopsis:
# debug_classes print_what=p print_class=c file
# where p is 1 for prologue, 2 for debugged part, 3 for epilogue,
# and c is the class number to be debugged (0=NULL).

$was_root=0;
$in_part=1;
while (<>) {
    chop;
    $ll = $_;
    $print_this = ($in_part == $print_what);
#    printf "print_this=$print_this, in_part=$in_part\n";
    if (($qq = $ll) =~ /^Root/) {
	$was_root = 1;
    } elsif (($qq = $ll) =~ /^  c[0-9][0-9]*/) {
	if ($was_root) {
#	    printf "Class number handled\n";
	    if (($qq = $ll) =~ /c[0-9][0-9]*/) {
		# This shit perl saves leading spaces in $qq!!!
		while (substr($qq,0,1) eq " ") {
		    substr($qq,0,1) = "";
		}
#		printf "Class name is `%s'\n", $qq;
		$c_c = substr($qq, 1);
#		printf "Class number is $c_c\n";
		if ($c_c == $print_class) {
		    $in_part = 2;
		}
	    }
	}
    } elsif (($qq = $ll) =~ /NULL/) {
	if ($was_root) {
	    if ($print_class == 0) {
		$in_part = 2;
	    }
	}
    } elsif (($qq = $_) =~ /^  ;/) {
	if ($in_part == 2) {
	    $in_part = 3;
	    $print_this = ($print_what == $in_part);
	}
    }
    if ($print_this) {
	printf "%s\n", $ll;
    }
}
	
