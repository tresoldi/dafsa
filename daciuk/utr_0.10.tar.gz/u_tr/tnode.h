/***	tnode.h		***/

/*	Copyright (C) Jan Daciuk, 1996	*/

#ifndef		TNODE_H
#define		TNODE_H


enum {FIND, REGISTER};
enum {FALSE, TRUE};

const int	PATH_LEN	= 128;	/* WARNING: not checked */

/* bit masks for arc-node */
const int	SURF_IS_FINAL	= 1;
const int	IS_FINAL	= 2;

#ifdef MONITOR_MEMORY
extern int tr_memory;		/* memory used by the transducer */
extern int idx_memory_all;	/* memory allocated by the index */
extern int idx_memory_use;	/* memory actually used by the index */
#endif

using namespace std;

class tnode;

struct prefix;

/* arc information for building phase - later enclosed in tr_arc */
class arc_node {
public:
  tnode		*child;		/* where the processing should go on seeing
				 * label `letter' in current node
				 * (NULL - common final node) */
  char		surf_letter;	/* surface label of current arc */
  char		lex_letter;	/* lexical label of current arc */
  char		fin_status;	/* final status (is_final & surf_is_final) */
  int		get_surf_is_final(void) {return (fin_status & SURF_IS_FINAL);}
  int		get_is_final(void) {return ((fin_status & IS_FINAL) != 0); }
  void		set_surf_is_final(void)
    { fin_status |= SURF_IS_FINAL; }
  void		set_is_final(void)
    { fin_status |= IS_FINAL; }
};/*arc_node*/

#ifdef MORE_COMPR
inline int operator !=(const arc_node &a1, const arc_node &a2) {
  return (a1.child != a2.child || a1.surf_letter != a2.surf_letter
	  || a1.lex_letter != a2.lex_letter || a1.fin_status != a2.fin_status);
}
#endif


/* Class name:	tnode
 * Purpose:	Provide methods and data for handling transducer nodes.
 * Methods:	tnode		- create a new node;
 *		~tnode		- delete node;
 *		add_child	- add a node or an arc to the transducer;
 *		add_postfix	- create a chain of nodes for letter of
 *				  a string and append them to this node;
 *		hit_node	- increases hit_count;
 *		compress_or_register
 *				- if subgraph beginning at this is unique,
 *				  register it, if not, replace it with
 *				  an already registered subgraph;
 *		find_or_register- find a registered node isomorphic to this,
 *				  or register this node;
 *		unregister	- unregister a node;
 *		hash		- computes a hash function for the node;
 *		number_arcs	- number arcs of the transducer;
 *		set_final_on	- sets final attribute on arc leading to node;
 * Variables:	children	- arcs leading from this node;
 *		no_of_children	- number of arcs leading from this node;
 *		arc_no		- arc index of the first arc of this node
 *				  in table of arcs in resulting final state
 *				  transducer;
 *		write_arcs	- write arcs of the transducer to a file.
 *		node_no		- node number;
 *		hit_count	- number of registered nodes that have arcs
 *				  leading to this node;
 *		big_brother	- pointer to a node containing the same arcs
 *				  (and more);
 *		brother_offset	- number of the first node in big_brother
 *				  corresponding to the first node of this node.
 */
class tnode {
private:
#ifdef FLEXIBLE
  static int	max_arcs_per_node; /* max no of children per node found */
#endif

  arc_node	*children;	/* outgoing arcs */
  int		arc_no;		/* arc number in the resulting automaton */
  int		hit_count;	/* number of incoming arcs */
  tnode		*big_brother;	/* node with the same arcs and more */
  short		no_of_children;	/* number of outgoing arcs */
  short		brother_offset;	/* offset of identical arcs in big brother */
#ifdef STATISTICS
  static int	total_arcs;	/* total number of arcs in the automaton
				   (inludes arcs stored in other arcs) */
  static int	total_nodes;	/* number of nodes in the automaton */
  static int	in_single_line;	/* number of nodes forming single lines */
  static int	line_length;	/* number of nodes in a line */
  static tnode	*current_line;	/* next node in current line of single nodes */
  static int	outgoing_arcs[10];	/* number of nodes having the
					   corresponding number of outgoing
					   arcs */
  static int	incoming_arcs[12];	/* number of nodes having the
					   corresponding number of incoming
					   arcs */
  static int	line_of[10];		/* number of nodes in a single line
					   of nodes of given length */
  static int	fail_count;		/* number of incoming transitions
					   for the fail state */
#endif /*STATISTICS*/

public:
#if defined(FLEXIBLE) && defined(NEXTBIT) && defined(STOPBIT)
  static int	next_nodes;	/* number of arcs with NEXT flag set */
#ifdef MORE_COMPR
  int		free_end;	/* the number of arcs at the end of the node
				   that can be permuted */
#endif /*MORE_COMPR*/
#endif /*FLEXIBLE,NEXTBIT,STOPBIT*/
  static int	no_of_arcs;	/* number of arcs in the automaton */

public:
  tnode(void) {children = NULL; no_of_children = 0; arc_no = -1; hit_count = 0;
#ifdef MONITOR_MEMORY
  tr_memory += sizeof(tnode);
#endif
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT) && defined(MORE_COMPR)
  free_end = no_of_children;
#endif
	       big_brother = NULL; }
  tnode(const tnode *n);
  ~tnode(void) { if (children != NULL) delete [] children;
#ifdef MONITOR_MEMORY
  tr_memory -= (sizeof(tnode) + no_of_children * sizeof(arc_node));
#endif
  }
  arc_node *get_children(void) const { return children;}
  int get_arc_no(void) const { return arc_no;}
  void set_arc_no(const int n) { arc_no = n;}
  int get_no_of_kids(void) const { return no_of_children;}
  int get_hit_count(void) const { return hit_count;}
  tnode *get_big_brother(void) const { return big_brother;}
  tnode *add_child(const char surf_letter, const char lex_letter,
		  tnode *next_node, const int surf_final);
  tnode *add_postfix(const char *surf_postfix, const char *lex_postfix);
  int hit_node(int hit_val=1) { return hit_count+=hit_val; }
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
  int number_arcs(const int gtl);
#else
  int number_arcs(void);
#endif /*FLEXIBLE,STOPBIT,NEXTBIT*/
  int write_arcs(ostream &outfile);
  tnode *set_link(tnode *big_guy, const int offset);
  void set_final_on(char surf, char lex);
  void reset_hit_count(void) { hit_count = 0; }
  void count_arcs(int *freq_table);
  void sort_arcs(void);
  friend void delete_branch(tnode *branch);
  friend int cmp_nodes(const tnode *node1, const tnode *node2);
  friend void register_subnodes(tnode *c_node, const int group_size);
  friend int part_cmp_nodes(const tnode *small_node, const tnode *big_node,
			    int offset, int group_size);
  friend int compress_or_register(tnode *l_node, tnode *cr_node);
  void print() const;
#ifndef STOPBIT
#ifdef JOIN_PAIRS
  friend class pair_registery;
#endif
#endif
#ifdef DEBUG
  friend void show_index(const int index_name);
#endif
#ifdef STATISTICS
  void print_statistics(const tnode *n) {
    cerr << "Statistics:" << endl
      << "States: " << n->total_nodes << endl
      << "Transitions: " << n->total_arcs - 1 << endl
      << "Number of nodes with given # of outgoing transitions" << endl
      << "1:\t\t" << n->outgoing_arcs[1] - 1 << endl
      << "2:\t\t" << n->outgoing_arcs[2] << endl
      << "3:\t\t" << n->outgoing_arcs[3] << endl
      << "4:\t\t" << n->outgoing_arcs[4] << endl
      << "5:\t\t" << n->outgoing_arcs[5] << endl
      << "6:\t\t" << n->outgoing_arcs[6] << endl
      << "7:\t\t" << n->outgoing_arcs[7] << endl
      << "8:\t\t" << n->outgoing_arcs[8] << endl
      << "9:\t\t" << n->outgoing_arcs[9] << endl
      << ">9:\t\t" << n->outgoing_arcs[0] << endl;
    cerr << "Number of nodes with given # of incoming transitions" << endl
      << "1:\t\t" << n->incoming_arcs[1] - 2 << endl
      << "2:\t\t" << n->incoming_arcs[2] << endl
      << "3:\t\t" << n->incoming_arcs[3] << endl
      << "4:\t\t" << n->incoming_arcs[4] << endl
      << "5:\t\t" << n->incoming_arcs[5] << endl
      << "6:\t\t" << n->incoming_arcs[6] << endl
      << "7:\t\t" << n->incoming_arcs[7] << endl
      << "8:\t\t" << n->incoming_arcs[8] << endl
      << "9:\t\t" << n->incoming_arcs[9] << endl
      << "10-99:\t\t" << n->incoming_arcs[10] << endl
      << "100-999:\t" << n->incoming_arcs[11] << endl
      << ">999:\t\t" << n->incoming_arcs[0] << endl
      << "fail state has " << fail_count << " incoming transitions" << endl;
    cerr << "Number of nodes in single lines: " << n->in_single_line - 1
	 << endl;
    cerr << "Number single lines of given length" << endl
      << "1:\t\t" << n->line_of[1] - 1 << endl
      << "2:\t\t" << n->line_of[2] << endl
      << "3:\t\t" << n->line_of[3] << endl
      << "4:\t\t" << n->line_of[4] << endl
      << "5:\t\t" << n->line_of[5] << endl
      << "6:\t\t" << n->line_of[6] << endl
      << "7:\t\t" << n->line_of[7] << endl
      << "8:\t\t" << n->line_of[8] << endl
      << "9:\t\t" << n->line_of[9] << endl
      << ">9:\t\t" << n->line_of[0] << endl;
  }
#endif /*STATISTICS*/
#ifdef FLEXIBLE
  int get_max_arcs_per_node(void) { return max_arcs_per_node; }
  int get_no_of_arcs(void) { return no_of_arcs; }
#if defined(STOPBIT) && defined(NEXTBIT)
  /* in write_arcs(): is the node the next node in the automaton */
  int wis_next_node(const tnode *n) const {
    return (n &&
	    (n->big_brother ?
	     (n->brother_offset == 0 && n->big_brother->hit_count != 0)
	     : n->hit_count != 0));
  }

  /* in number_arcs(): is the node the next node in the automaton;
     if it does not have a big brother, and it has not been numbered yet,
     then we can put it right after the current node;
     if it has a big brother, and the big brother is not numbered yet,
     the the brother offset must be 0 for n to be the next node,
     because otherwise the first arc of n will not be the first arc of its
     brother, so it will not be the next arc after the last arc of the
     current node
  */
  int nis_next_node(const tnode *n) const {
    return (n &&
	    (n->big_brother ?
	     (n->brother_offset == 0 && n->big_brother->arc_no == -1)
	     : n->arc_no == -1));
  }
#endif /*STOPBIT,NEXTBIT*/
#endif /*FLEXIBLE*/
#if defined(MORE_COMPR) && defined(FLEXIBLE) && defined(STOPBIT)
  friend int match_subset(tnode *n, const int kids_tab[],
			  const int kids_no_no);
  friend int match_part(tnode *n, tnode *nn, const int to_do,
			const int start_at, const int subset_size);
#endif
};/*tnode*/


/* holds information about prefix of word already in transducer */
struct prefix {
  tnode		*path[PATH_LEN];	/* common prefix path */
  int		arc_no[PATH_LEN];	/* ordinal number of the arc
					 * of node path[i] leading
					 * to the node path[i+1] */
  int		length;		// length of prefix
  int		first;		/* first node in path with hit count > 1 */
  int		already_there;	/* if the string is already in transducer */
};/*prefix*/


/* Name:	mod_child
 * Class:	None.
 * Purpose:	Modifies a link to a child from a given node.
 * Parameters:	parent_node	- (i/o) parent node;
 *		child_node	- (i) child node;
 *		arc_no		- (i) modified arc number;
 *		surf_is_final	- (i) surface string is final;
 *		is_final	- (i) arc is final;
 * Returns:	TRUE if child modified, FALSE otherwise.
 * Remarks:	Arc must exist.
 *		Maybe it would be a good idea to exclude surf_final
 *		from here. It cannot be dealt with properly here,
 *		as surface string can end e.g. before common_prefix->first,
 *		so it has to corrected later anyway.
 *		OK, so be it.
 *
 *		delete_branch takes care of hit_count housekeeping.
 */
int
mod_child(tnode *parent_node, tnode *child_node, int arc_no, int surf_is_final,
	  int is_final);

#ifdef SORT_ON_FREQ
/* Name:        freq_cmp
 * Class:       None.
 * Purpose:     Compares arcs on frequency.
 * Parameters:  el1             - (i) the first arc;
 *              el2             - (i) the second arc;
 * Result:      -1      - if the label on the first arc appears less frequently
 *                              on arcs in the automaton than the label on the
 *                              second arc;
 *              0       - if the label on the first arc appears the same number
 *                              of times in the automaton as the label on the
 *                              second arc;
 *              1       - if the label on the first arc appears more frequently
 *                              on arcs in the autoamton than the label on the
 *                              second arc.
 * Remarks:     None.
 */
int
freq_cmp(const void *el1, const void *el2);


/* Name:	freq_count_cmp
 * Class:	None
 * Purpose:	Compares two positions in frequency order.
 * Parameters:	el1	- (i) pointer to the first position;
 *		el2	- (i) pointer to the second position;
 * Returns:	-1 if the frequency count for the first position is greater
 *		   than the frequency count for the second position;
 *		0  if the frequency count for both positions is equal;
 *		1  if the frequency count for the first position is less
 *		   than the frequency count for the second position;
 * Remarks:	The position is calculated as (c1 + 128) * 256 + c2 + 128,
 *		where c1 is the code of the surface character, and c2 is
 *		the code of the lexical character.
 *		The order is reversed, so that first positions have greatest
 *		count.
 */
int
freq_count_cmp(const void *el1, const void *el2);

#endif



#endif
/***	EOF tnode.h	***/
