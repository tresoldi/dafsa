/***	tnode.cc	***/

/* Copyright (C) Jan Daciuk, 1996.	*/

/*

This file implements methods of class tnode.

*/

#include	<iostream>
#include	<stdlib.h>
#include	<string.h>
#include	<stddef.h>
#include	"tr.h"
#include	"tnode.h"
#include	"nstr.h"
#include	"tindex.h"

extern char	FILLER;
#ifdef MONITOR_MEMORY
int tr_memory = 0;		/* memory used by the transducer */
int idx_memory_all = 0;		/* memory allocated by the index */
int idx_memory_use = 0;		/* memory actually used by the index */
#endif

int	tnode::no_of_arcs = 1;	// initially there is an empty arc #0

int	frequency_table[256*256];   // no of occurences of labels on arcs
int	frequency_order[256*256];   // frequency order of arcs

#if defined(FLEXIBLE)
/* this has to be defined somewhere */
int tr_arc_ptr::gtl = 0;
int tr_arc_ptr::size = 0;
#ifndef STOPBIT
int tr_arc_ptr::ctl = 0;
#else //STOPBIT
#ifdef NEXTBIT
int tnode::next_nodes = 0;
const char *tr_arc_ptr::curr_dictionary = NULL;
#endif //NEXTBIT
#endif //STOPBIT
#ifdef NUMBERS
int tr_arc_ptr::entryl = 0;
int tr_arc_ptr::aunit = 0;
#endif
#endif
#ifdef STATISTICS
int tnode::total_nodes = 0;	/* total number of nodes in the automaton */
int tnode::total_arcs = 0;	/* total number of arcs in the automaton */
int tnode::in_single_line = 0;	/* number of nodes forming single lines */
int tnode::line_length = 0;
tnode *tnode::current_line = NULL;
int tnode::outgoing_arcs[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
int tnode::incoming_arcs[12] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
int tnode::line_of[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
int tnode::fail_count = 0;	// number of incoming arcs for the fail state
#endif


/* Name:	tnode
 * Class:	tnode
 * Purpose:	Create a copy of a given node.
 * Parameters:	n		- (i) node to be copied.
 * Returns:	Nothing.
 * Remarks:	hit_count is reset, as this is a new node.
 *		hit_count of all children is increased, as this is another
 *		node pointing to them.
 */
tnode::tnode(const tnode *n)
{
  int i;

  arc_no = -1; hit_count = 0; big_brother = NULL;
  no_of_children = n->no_of_children;
  children = new arc_node[no_of_children];
  for (i = 0; i < no_of_children; i++) {
    children[i] = n->children[i];
    if (children[i].child)
      children[i].child->hit_count++;
  }
#ifdef MONITOR_MEMORY
  tr_memory += sizeof(tnode);
#endif
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT) && defined(MORE_COMPR)
  free_end = n->free_end;
#endif
}//tnode::tnode


/* Name:	set_final_on
 * Class:	tnode
 * Parameters:	surf			- (i) surface letter;
 *		lex			- (i) lexical letter.
 * Returns:	Nothing.
 * Remarks:	Previous version of this method took node address
 *		as a parameter. This was wrong, because there may
 *		be more than one arc between two nodes.
 */
void
tnode::set_final_on(char surf, char lex)
{
  for (int i = 0; i < no_of_children; i++)
    if (children[i].surf_letter == surf && children[i].lex_letter == lex) {
      children[i].set_is_final();
      break;
    }
}//tnode::set_final_on

/* Name:	add_postfix
 * Class:	tnode
 * Purpose:	Create a chain of nodes with each node holding a consecutive
 *		letters from postfixes. Link it to the current node.
 * Parameters:	surf_postfix		- (i) the surface string to be added;
 *		lex_postfix		- (i) the lexical string to be added.
 * Returns:	Pointer to the child node,
 *		or NULL if added arc has a NULL link.
 * Remarks:	This function has been totally rewritten. The aim was to:
 *		1) minimize needless memory allocation,
 *		2) increase speed.
 *
 *		Ad 1. Now suffix nodes are created from the end and looked up
 *			immediately in index. Memory is not allocated for them
 *			until it is known they are unique (at this stage).
 *			So many nodes that are found isomorphic to others
 *			do not contribute to memory load.
 *			This change was necessary due to a feature of SunOS:
 *			free(p) is equivalent to NOP. I love Sun!!!
 *
 *		Ad 2. All nodes in the suffix chain contain only one child,
 *			so both creation of nodes, and registering them
 *			is much simpler than in the general case.
 *			Also, if there is a uniqe node in the suffix path,
 *			all nodes preceeding it are also unique, so there
 *			is no need to search for them in index.
 */
tnode *
tnode::add_postfix(const char *surf_postfix, const char *lex_postfix)
{
  char		surf_node_char, lex_node_char;
  tnode		current_node;
  arc_node	*current_arc;
  tnode		*last_node;
  tnode		*new_node;
  int		unique;
  int		i;

  int s_len = strlen(surf_postfix);
  int l_len = strlen(lex_postfix);
  int len = l_len;
  if (s_len > len)
    len = s_len;

  last_node = NULL; unique = FALSE;
  current_arc = new arc_node[1];
  current_node.children = current_arc;
  current_node.hit_count = 0;
  current_node.no_of_children = 1;
  current_node.arc_no = -1;
  current_node.big_brother = NULL;

  for (i = len - 1; i > 0; --i) {
    // fill arc
    current_arc->child = last_node;
    current_arc->surf_letter = (i < s_len ? surf_postfix[i] : FILLER);
    current_arc->lex_letter = (i < l_len ? lex_postfix[i] : FILLER);
    current_arc->fin_status = 0;
    if (last_node == NULL)
      current_arc->set_is_final();
    if (i == s_len - 1)
      current_arc->set_surf_is_final();

    if (!unique) {
      if ((last_node = find_or_register(&current_node, PRIM_INDEX, FALSE))
	  == NULL) {
	// node is uniqe
	unique = TRUE;
      }
      else {
	if (!unique && last_node->children[0].child) {
	  // Earlier an isomorphic node has been found. Its hit count
	  // was inceased under assumption that a new node that points
	  // to that node will be created. However, a node isomorphic
	  // to that new one has been found as well. So there is no
	  // new node pointing to last_node->children[0].child.
	  // As its hit count was increased, it has to be decreased
	  // to restore its original value
	  last_node->children[0].child->hit_node(-1);
	}

	// else last node contains a pointer to the node isomorphic
	// to current one
      }
    }//if !unique

    if (unique) {
      // there is a unique node down the path, so the whole path is unique:
      // there is no need to check that in the index - simply register nodes
      new_node = new tnode;
      new_node->children = new arc_node[1];
      new_node->no_of_children = 1;
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT) && defined(MORE_COMPR)
      new_node->free_end = 1;
#endif
      new_node->children[0] = current_arc[0];

      find_or_register(new_node, PRIM_INDEX, TRUE);
      last_node = new_node;
#ifdef MONITOR_MEMORY
      tr_memory += sizeof(arc_node);
#endif
    }
    last_node->hit_node();
  }//for

  surf_node_char = *surf_postfix ? *surf_postfix++ : FILLER;
  lex_node_char = *lex_postfix ? *lex_postfix++ : FILLER;
  add_child(surf_node_char, lex_node_char, last_node,
	    (*surf_postfix == '\0' && surf_node_char != FILLER));
  return last_node;
}//tnode::add_postfix

/* Name:	add_child
 * Class:	tnode
 * Purpose:	Add a child (an arc) to the given node.
 * Parameters:	surf_letter	- (i) arc surface label;
 *		lex_letter	- (i) arc lexical label;
 *		next_node	- (i) a node that the arc leads to
 *					or NULL for final node;
 *		surf_final	- (i) if this is the last character of surface
 *					string.
 * Returns:	Pointer to this node.
 * Remarks:	There may be an arc of this node labelled
 *		`surf_letter/lex_letter'.
 *		In that case, use that arc (i.e., attach next node to it).
 *		The pointer there can be either NULL, or non-NULL.
 *		The first situation means that this node is the last in
 *		a chain, and the label leads to the common final (empty) node.
 *		Otherwise, existing node is replaced with a new one.
 *		If not, create a new arc.
 *
 *		Arcs must be added in a right place to ensure the cannonical
 *		order of nodes (for comparison).
 */
tnode *
tnode::add_child(const char surf_letter, const char lex_letter, tnode *next_node,
		const int surf_final)
{
  arc_node	*new_children;
  arc_node	*new_child;
  int		i, j;

  // find if there is already an arc labelled `surf_letter/lex_letter'
  // if so, put `next_node' at the end of that arc
  // if not, remember where to put the new arc
  for (i = 0; i < no_of_children && children[i].surf_letter <= surf_letter;
       i++) {
    if (children[i].surf_letter == surf_letter &&
	children[i].lex_letter >= lex_letter) {

      if (children[i].lex_letter > lex_letter)
	break;	// gone too far - no further candidates

      // arc found
      if (children[i].child) {
	if (children[i].child != next_node) {
	  // delete that child (with pointers to children)
	  // and replace it with `next_node'
	  // provided the child is referenced elsewhere
	  // (in that case, its hit_count is decreased)
	  delete_branch(children[i].child);
	}
      }
      children[i].child = next_node;
      if (surf_final)
	children[i].set_surf_is_final();
      if (next_node == NULL)
	children[i].set_is_final();
      return this;
    }
    // else either children[i].surf_letter < surf_letter
    // or children[i].surf_letter == surf_letter
    //    and children[i].lex_letter < lex_letter
  }//for

  // a new arc must be created
#ifdef MONITOR_MEMORY
  tr_memory += sizeof(arc_node);
#endif
  j = i;
  new_children = new arc_node[no_of_children + 1];
  for (i = 0; i < j; i++)
    new_children[i] = children[i];
  for (i = j; i < no_of_children; i++)
    new_children[i+1] = children[i];

  new_child = new_children + j;
  new_child->child = next_node;
  new_child->fin_status = 0;
  if (next_node == NULL)
    new_child->set_is_final();
  if (surf_final)
    new_child->set_surf_is_final();
  new_child->surf_letter = surf_letter;
  new_child->lex_letter = lex_letter;

  if (no_of_children)
    delete [] children;
  children = new_children;
  no_of_children++;
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT) && defined(MORE_COMPR)
  free_end = no_of_children;
#endif
  return this;
}//tnode::add_child


/* Name:	mod_child
 * Class:	None.
 * Purpose:	Modifies a link to a child from a given node.
 * Parameters:	parent_node	- (i/o) parent node;
 *		child_node	- (i) child node;
 *		arc_no		- (i) modified arc number;
 *		surf_is_final	- (i) surface string is final;
 *		is_final	- (i) arc is final;
 * Returns:	TRUE if a child modified, FALSE if not.
 * Remarks:	Arc must exist.
 *		Maybe it would be a good idea to exclude surf_final
 *		from here. It cannot be dealt with properly here,
 *		as surface string can end e.g. before common_prefix->first,
 *		so it has to be corrected later anyway.
 *		OK, so be it.
 *
 *		delete_branch takes care of hit_count housekeeping.
 */
int
mod_child(tnode *parent_node, tnode *child_node, int arc_no, int surf_is_final,
	  int is_final)
{
  int		modified;
  arc_node	*child_arc = parent_node->get_children() + arc_no;
  modified = (child_node != child_arc->child ||
	      child_arc->get_is_final() != is_final ||
	      child_arc->get_surf_is_final() != surf_is_final);
  if (child_arc->child && child_arc->child != child_node)
    delete_branch(child_arc->child);
  child_arc->child = child_node;
  if (child_arc->get_is_final() | is_final)
    child_arc->set_is_final();
  if (child_arc->get_surf_is_final() | surf_is_final)
    child_arc->set_surf_is_final();
  return modified;
}//mod_child;

/* Name:	print
 * Class:	tnode
 * Purpose:	Print node contents (for debugging only).
 * Parameters:	None.
 * Returns:	Nothing.
 * Remarks:	For debugging.
 */
void
tnode::print(void) const
{
  cerr << "[" << hex << long(this) << "] ";
  if (big_brother)
    cerr << "(" << hex << long(big_brother) << "+" << dec << brother_offset
	 << ") ";
  cerr << dec << no_of_children << ":";
  for (int qq = 0; qq < no_of_children; qq++) {
    cerr << " " << children[qq].surf_letter << "/"
	 << children[qq].lex_letter << "[" << hex << long(children[qq].child)
         << dec << (children[qq].get_is_final() ? "]!" : "]");
    if (children[qq].child) {
      cerr << "(";
      for (int qqq = 0; qqq < children[qq].child->no_of_children; qqq++) {
	cerr << children[qq].child->children[qqq].surf_letter << "/";
	cerr << children[qq].child->children[qqq].lex_letter;
      }
      cerr << ")";
    }
  }
  cerr << "\n";
}//tnode::print


/* Name:	number_arcs
 * Class:	tnode
 * Purpose:	Assign an index to each arc in the transducer.
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
 * Parameters:	gtl	- (i) goto field length.
#else
 * Parameters:	None.
#endif
 * Returns:	Number of the first arc of the node.
 * Remarks:	Arc numbers are kept in nodes, rather than in arcs themselves.
 *		A node keeps an arc number of its first arc.
 *		Arc number equal -1 means the node has not been visited yet.
 *		Arcs of the root are numbered from 1, because arc #0 is
 *		a dummy arc.
 *
 *		This used to easy, but is no loger so.  This is because
 *		of compression.
 *
 *              In pictures below, "->-" is a link to big_brother, either
 *              a true big_brother (i.e. one that is bigger), or the first
 *              node of merged nodes. "-=-" Indicates a link to a node
 *              that this node was merged with. Index n indicates already
 *              numbered node. Xo means brother_offset of X. a means
 *              current arc number to be allocated.
 *
 *              Situations and actions (this (A) is always not numbered):
 *
 *              1) A                    - number A and children of A
 *                                        Note: A may be a big brother
 *                                        of another node. It does not matter.
 *                                        A = a.
 *
 *              2a) A ->-> B            - number B, number A, and number
 *                                        children of B.
 *                                        B = a; A = B + Ao.
 *
 *              2b) A ->-> Bn           - number A.
 *                                        A = B + Ao.
 *
 *              3a) A ->-> B            - number B, number A, number children
 *                    <-=-                of B, number children[1] of A.
 *                                        B = a; A = B + Ao;
 *
 *              3b) A -=-> B            - number A, number B, number children
 *                    <-<-                of A, number children[1] of B
 *                                        Note: in 3, A & B are always numbered
 *                                        at the same time.
 *                                        A = Ao; B = A + Bo.
 *
 *              4a) A ->-> B ->-> C     - number C, number B, number A,
 *                           <-=-         number children of C,
 *                                        number children[1] of B.
 *                                        C = a; B = C + Bo; A = B + Ao.
 *
 *
 *              4c) A ->-> Bn ->-> Cn   - number A.
 *                            <-=-        A = B + Ao.
 *
 *              4d) A ->-> Bn -=-> Cn   - number A.
 *                            <-<-        A = B + Ao.
 *
 */
int
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
tnode::number_arcs(const int gtl)
#else
tnode::number_arcs(void)
#endif
{
  tnode		*p, *pp = NULL;
  int		limit;		// number of arcs to write for the node
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
  static tnode	*descendants[MAX_ARCS_PER_NODE];
#endif

//  cerr << "Numbering: "; print();
#ifdef STATISTICS
  total_nodes++;
  total_arcs += no_of_children;
  if (no_of_children < 10)
    (outgoing_arcs[no_of_children])++;
  else
    (outgoing_arcs[0])++;
  if (hit_count < 10)
    (incoming_arcs[hit_count])++;
  else if (hit_count < 100)
    (incoming_arcs[10])++;
  else if (hit_count < 1000)
    (incoming_arcs[11])++;
  else
    (incoming_arcs[0])++;
  if (no_of_children == 1 && hit_count == 1) {
    in_single_line++;
    if (current_line == this) {
      if (line_length > 0 && line_length < 10)
	--(line_of[line_length]);
      line_length++;
      if (line_length < 10)
	(line_of[line_length])++;
      else if (line_length == 10)
	(line_of[0])++;
    }
    else {
      line_length = 1;
      (line_of[line_length])++;
    }
  }
  else
    line_length = 0;
  current_line = children->child;
#endif //STATISTICS
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
  if (gtl == 0 && no_of_children > 1) {
    // try to rearrange arcs so that one that leads to nodes with more
    // children will be the last one
    int found = 0;
    if (free_end > 0 && free_end < MAX_ARCS_PER_NODE) {
      for (int kk = no_of_children - free_end; kk < no_of_children; kk++)
	descendants[kk] = children[kk].child;
      int maxi = -1;
      int maxv = 1;
      while (!found) {
	int inactive = 0;
	for (int ll = no_of_children - 1; ll >= no_of_children - free_end;
	     --ll) {
	  if (descendants[ll] == NULL || descendants[ll]->arc_no != -1)
	    inactive++;
	  else if (descendants[ll]->no_of_children > maxv) {
	    maxv = descendants[ll]->no_of_children;
	    maxi = ll;
	    found = TRUE;
	  }
	  else
	    descendants[ll] = descendants[ll]->get_children()->child;
	}//for
	if (inactive >= free_end)
	  break;
      }//while
      if (found) {
	if (maxi != no_of_children - 1) {
	  // exchange two arcs
	  arc_node tmp_arc = children[no_of_children - 1];
	  children[no_of_children - 1] = children[maxi];
	  children[maxi] = tmp_arc;
	}
      }
    }
  }
#endif
  if (no_of_children) {
#ifdef FLEXIBLE
    if (no_of_children > max_arcs_per_node)
      max_arcs_per_node = no_of_children;
#endif
    p = this;
    limit = no_of_children;
    if (big_brother) {
      if (big_brother->arc_no != -1) {
        // big brother has been numbered
        // Situations 2b, 4c, 4d.
        arc_no =
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
	  (GOTO_OFFSET + gtl) *
#endif //FLEXIBLE,STOPBIT,NEXTBIT
	  brother_offset + big_brother->arc_no;
	return arc_no;
        // Note: no need to number children (already numbered)
      }

#ifdef JOIN_PAIRS
#ifndef STOPBIT
      limit = big_brother->no_of_children;      // change when chains of arcs
      // Situations 2a, 3a, 3b, 4a, 4b
      if (big_brother->big_brother && big_brother->big_brother != this) {
        // Situations: 4a, 4b.
        if (big_brother->brother_offset < 0)
          // Situation 4b.
          p = big_brother;
        else
          // Situation 4a.
          p = big_brother->big_brother;
        p->big_brother->arc_no = no_of_arcs + p->big_brother->brother_offset;
        p->arc_no = no_of_arcs;         // we use it in the following line...
        arc_no = big_brother->arc_no + brother_offset;
        limit -= p->brother_offset;
        // Handled: 4a: Bn, An; 4b: Cn, An.
        // Wait for: 4a: Cn, Cc, B[1]c; 4b: Bn, Bc, C[1]c.
      }
      else if (big_brother->big_brother && big_brother->big_brother == this) {
        // Situations 3a, 3b.
        if (big_brother->brother_offset < 0)
          // Situation 3b.
          p = big_brother;
        else
          // Situation 3a.
          p = this;
        p->big_brother->arc_no = no_of_arcs + p->big_brother->brother_offset;
        limit -= p->brother_offset;
        // Handled: 3a: An; 3b: Bn.
        // Wait for: 3a: Bn, Bc, A[1]c; 3b: An, Ac, B[1]c.
      }
      else {
#endif //!STOPBIT
#endif //JOIN_PAIRS

        // Situation 2a

        p = big_brother;
        arc_no =
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
	  (gtl ? (GOTO_OFFSET + gtl) : 1) *
#endif
	  brother_offset + no_of_arcs;
        limit = p->no_of_children;
        // handled: An.
        // Wair for: Bn, Bc.
#ifdef JOIN_PAIRS
#ifndef STOPBIT
      }
#endif //!STOPBIT
#endif //JOIN_PAIRS
    }

    p->arc_no = no_of_arcs;
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT) && defined(MORE_COMPR)
    if (gtl == 0 && (no_of_children &&
		     !nis_next_node(p->children[p->no_of_children-1].child))) {
      // Try to rearrange arcs in p so that the last arc would point
      // to the next node
      int a, b;
      b = p->no_of_children - 1;
      for (a = b - 1; a>= p->no_of_children - p->free_end; --a) {
	if (nis_next_node(p->children[a].child)) {
	  // Exchange arcs
	  arc_node temp_arc = p->children[a];
	  p->children[a] = p->children[b];
	  p->children[b] = temp_arc;
	  break;
	}
      }
    }
#endif //FLEXIBLE,STOPBIT,NEXTBIT,MORE_COMPR
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
    if (gtl) {
      // We recalculate the numbers taking variable arc length into account
      no_of_arcs += limit * (GOTO_OFFSET + gtl);
#ifdef NUMBERS
      if (entryl)
	no_of_arcs += entryl;
#endif //NUMBERS
      if (gtl > 1 && no_of_children &&
	  nis_next_node(p->children[p->no_of_children - 1].child))
	no_of_arcs -= (gtl - 1);
    }
    else {
      // gtl == 0
      no_of_arcs += limit;	// just counting arcs
    }
#else //!(FLEXIBLE,STOPBIT,NEXTBIT)
#ifdef NUMBERS
    if (entryl)
      no_of_arcs += limit * a_size + entryl;
    else
      no_of_arcs += limit;
#else //!NUMBERS
    no_of_arcs += limit;
#endif //!NUMBERS
#endif //!(FLEXIBLE,STOPBIT,NEXTBIT)

// no conditionals

#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
    // We start from the last arc to have more compression
    // because in that way we will place the target of the last arc as the next
    for (int j = limit - 1; j >= 0; --j) {
      pp = p->children[j].child;
      if (pp && pp->arc_no == -1) {
	pp->number_arcs(gtl);
	if (j == limit - 1)
	  next_nodes++;
      }
#ifdef STATISTICS
      if (pp == NULL) {
	fail_count++;
      }
#endif //STATISTICS
    }
#else //FLEXIBLE,STOPBIT,NEXTBIT
    for (int i = 0; i < limit; i++) {
#ifdef JOIN_PAIRS
#ifndef STOPBIT
      if (i >= p->no_of_children)
        pp = p->big_brother->children[1].child;
      else
#endif //!STOPBIT
#endif //JOIN_PAIRS
      pp = p->children[i].child;
      if (pp && pp->arc_no == -1)
	pp->number_arcs();
    }
#endif //!(FLEXIBLE,STOPBIT,NEXTBIT)
#ifdef STATISTICS
    if (pp == NULL) {
      fail_count++;
    }
#endif //STATISTICS
  }
  else
    arc_no = 0;
  return arc_no;
}//tnode::number_arcs


#ifdef  SORT_ON_FREQ
/* Name:        count_arcs
 * Class:       tnode
 * Purpose:     Counts arcs having the same label.
 * Parameters:  freq_table      - number of occurences of arcs with
 *                                different labels.
 * Returns:     Nothing.
 * Remarks:     Nodes counted receive arc_no = -2.
 *              This will be changed by sort_arcs.
 *
 *              As a result, freq_table contains the number of occurences
 *              of arcs with a specific label in the cell indexed by that
 *              label code. The code is treated as unsigned.
 *
 *		It is assumed that characters are signed. If it is not so,
 *		delete "+ 128".
 */
void
tnode::count_arcs(int *freq_table)
{
  tnode          *p;
  unsigned char c1, c2;

  if (no_of_children) {
    arc_no = -2;
    for (int i = 0; i < no_of_children; i++) {
      c1 = children[i].surf_letter + 128;
      c2 = children[i].lex_letter + 128;
      freq_table[c1*256 + c2]++;
      p = children[i].child;
      if (p && p->arc_no != -2)
        p->count_arcs(freq_table);
    }
  }
}//tnode::count_arcs


/* Name:        sort_arcs
 * Class:       tnode
 * Purpose:     Sorts arcs by frequency.
 * Parameters:  None.
 * Result:      Nothing.
 * Remarks:     Frequency is the frequency of occurence of an label
 *              in the automaton.
 *              Nodes already sorted receive arc_no = -1.
 *              before sorting, they should have arc_no = -2.
 */
void
tnode::sort_arcs(void)
{
  tnode	*p;

  if (no_of_children) {
    arc_no = -1;
    qsort(children, no_of_children, sizeof(arc_node), freq_cmp);
    for (int i = 0; i < no_of_children; i++) {
      p = children[i].child;
      if (p && p->arc_no != -1)
        p->sort_arcs();
    }
  }
}//tnode::sort_arcs


/* Name:        freq_cmp
 * Class:       None.
 * Purpose:     Compares arcs on frequency.
 * Parameters:  el1             - (i) the first arc;
 *              el2             - (i) the second arc;
 * Result:      -1      - if the label on the first arc appears more frequently
 *                              on arcs in the automaton than the label on the
 *                              second arc;
 *              0       - if the label on the first arc appears the same number
 *                              of times in the automaton as the label on the
 *                              second arc;
 *              1       - if the label on the first arc appears less frequently
 *                              on arcs in the autoamton than the label on the
 *                              second arc.
 * Remarks:     It is assumed that char is signed. If it is otherwise
 *		delete "+ 128".
 *		The result is reversed, because arcs should be sorted
 *		in reverse order - this should give better speed, as
 *		more frequent arcs will be at the beginning.
 */
int
freq_cmp(const void *el1, const void *el2)
{
  int c1, c2;

  c1 = (((arc_node *)(el1))->surf_letter + 128) << 8;
  c1 += ((arc_node *)(el1))->lex_letter + 128;
  c2 = (((arc_node *)(el2))->surf_letter + 128) << 8;
  c2 += ((arc_node *)(el2))->lex_letter + 128;
  return frequency_order[c2] - frequency_order[c1];
}//freq_cmp

/* Name:	freq_count_cmp
 * Class:	None
 * Purpose:	Compares two positions in frequency order.
 * Parameters:	el1	- (i) pointer to the first position;
 *		el2	- (i) pointer to the second position;
 * Returns:	-1 if the frequency count for the first position is greater
 *		   than the frequency count for the second position;
 *		0  if the frequency count for both positions is equal;
 *		1  if the frequency count for the first position is less
 *		   than the frequency count for the second position;
 * Remarks:	The position is calculated as (c1 + 128) * 256 + c2 + 128,
 *		where c1 is the code of the surface character, and c2 is
 *		the code of the lexical character.
 */
int
freq_count_cmp(const void *el1, const void *el2)
{
  int	c1, c2;

  c1 = frequency_table[*((int *)el1)];
  c2 = frequency_table[*((int *)el2)];
  return c1 - c2;
}

#endif

#ifdef FLEXIBLE
char *
int2bytes(char *bytes, int val, int len);

/* Name:	int2bytes
 * Class:	None
 * Purpose:	Write integers as a sequence of len bytes, the most significant
 *		byte first.
 * Parameters:	bytes		- (o) where to write;
 *		val		- (i) what to write;
 *		len		- (i) on how many bytes.
 * Returns:	Pointer to the sequence of bytes.
 * Remarks:	No check is made to assure there is enough place in bytes
 *		for val.
 */
char *
int2bytes(char *bytes, int val, int len)
{
  for (int i = 0; i < len; i++) {
    bytes[i] = val & 0xff;
    val >>= 8;
  }
  return bytes;
}/*int2bytes*/
#endif

/* Name:	write_arcs
 * Class:	tnode
 * Purpose:	Writes arcs of a node and arcs of its descendants to a file.
 * Parameters:	outfile		- (o) output file.
 * Returns:	TRUE if arcs written, FALSE otherwise.
 * Remarks:	It is assumed that arcs were numbered with tnode::number_arcs
 *		with root being #1. #0 is a dummy arc.
 */
int
tnode::write_arcs(ostream &outfile)
{
#ifdef FLEXIBLE
  char		output_arc[8];
  char		*oa = &output_arc[0];
  tr_arc_ptr	dummy;
#else
  tr_arc	output_arc[1], *oa = &output_arc[0];
#endif
  int		i;
  tnode		*p;
  arc_node	pp;
  int		limit = no_of_children;
  static int	you_have_not_been_warned = TRUE;

#ifdef FLEXIBLE
#ifdef STOPBIT
  int gtl = dummy.gtl;
  int size = GOTO_OFFSET + gtl;
#else
  int gtl = dummy.gtl;			// length of go_to field
  int ctl = dummy.ctl;	// length of counter field
  int size = gtl + ctl + 2;		// size of whole arc
  int mask = 0xc0 << (8 * (gtl - 1));		// mask for state bits
#endif
#endif
  if (hit_count > 0) {
    hit_count = 0;
    if (no_of_children > 0) {
//      if (big_brother && brother_offset >= 0)
//	  cerr << "While writing arcs, a node with bb encountered\n";
#ifndef STOPBIT
#ifdef JOIN_PAIRS
      if (big_brother && no_of_children == 2 &&
          brother_offset < 0)
        limit = no_of_children - brother_offset;
#endif
#endif
      for (i = 0; i < limit; i++) {
#ifndef STOPBIT
#ifdef JOIN_PAIRS
        if (i >= no_of_children)
          pp = big_brother->children[1];
        else
#endif
#endif
	pp = children[i];
	p = pp.child;

	// labels
#ifdef FLEXIBLE
	oa[0] = pp.surf_letter;
	oa[1] = pp.lex_letter;
#else
	oa->surf_letter = pp.surf_letter;
	oa->lex_letter = pp.lex_letter;
#endif
	if (p) {

	  // goto field
#ifdef FLEXIBLE
#ifdef STOPBIT
	  int2bytes(oa + GOTO_OFFSET, p->arc_no << GOTO_SHIFT, gtl);
#else //!STOPBIT
	  int2bytes(oa + 2 + ctl, p->arc_no & ~mask, gtl);
	  int2bytes(oa + 2, p->no_of_children, ctl);
#endif //!STOPBIT
#else //!FLEXIBLE
	  oa->go_to = p->arc_no;
	  oa->set_children(p->no_of_children);
#endif //!FLEXIBLE
	  if (p->no_of_children > MAX_ARCS_PER_NODE &&
	      you_have_not_been_warned) {
	    cerr << "Too many arcs leading from one node\nYour language "
	         << "contains more than " << MAX_ARCS_PER_NODE
		 << " characters!\n";
	    you_have_not_been_warned = FALSE;
	  }
	}
	else {
	  // empty address
#ifdef FLEXIBLE
#ifdef STOPBIT
	  for (int iii = GOTO_OFFSET; iii < size; iii++)
	    oa[iii] = 0;
#else
	  for (int iii = 2; iii < size; iii++)
	    oa[iii] = 0;
	  oa[1 + ctl + gtl] = pp.surf_letter ? 0xc0 : 0x80;
#endif //!STOPBIT
#else //!FLEXIBLE
	  oa->go_to = 0;
	  oa->set_children(0);
	  oa->set_final(TRUE);
	  oa->set_surf_final(pp.surf_letter != FILLER);
#endif //!FLEXIBLE
	}
	// flags
#ifdef FLEXIBLE
#ifdef STOPBIT
	if (pp.get_is_final())
	  oa[GOTO_OFFSET] |= FINAL_BIT_MASK;
	else
	  oa[GOTO_OFFSET] &= ~FINAL_BIT_MASK;
	if (pp.get_surf_is_final())
	  oa[GOTO_OFFSET] |= FINAL_SURF_BIT_MASK;
	else
	  oa[GOTO_OFFSET] &= ~FINAL_SURF_BIT_MASK;
	if (i == limit - 1)
	  oa[GOTO_OFFSET] |= STOP_BIT_MASK;
	else
	  oa[GOTO_OFFSET] &= ~STOP_BIT_MASK;
#ifdef NEXTBIT
	if (i == limit - 1 && wis_next_node(p)) {
	  oa[GOTO_OFFSET] |= NEXT_BIT_MASK;
	  oa[GOTO_OFFSET] |= 0x80; // make sure goto != 0
	}
	else
	  oa[GOTO_OFFSET] &= ~NEXT_BIT_MASK;
#endif
#else //!STOPBIT
	if (pp.get_is_final())
	  oa[1 + ctl + gtl] |= 0x80;
	else
	  oa[1 + ctl + gtl] &= 0x7f;
	if (pp.get_surf_is_final())
	  oa[1 + ctl + gtl] |= 0x40;
	else
	  oa[1 + ctl + gtl] &= 0xbf;
#endif
#else
	oa->set_final(pp.get_is_final());
	oa->set_surf_final(pp.get_surf_is_final());
#endif

#ifdef DEBUG
	cerr << "Writing arc #" << arc_no + i << " `" << oa->surf_letter
	     << (oa->surf_is_final() ? "!/" : "/")
	     << oa->lex_letter
	     << ((oa->is_final()) ? "!'" : "'") << " -> " << oa->go_to;
	if (oa->children() > 1)
	  cerr << "-" << oa->go_to + (oa->children()) - 1;
	cerr << "\n";
#endif
#ifdef FLEXIBLE
#if defined(STOPBIT) && defined(NEXTBIT)
	if (!(outfile.write((char *)oa,
			    (p && i == limit - 1 && wis_next_node(p)) ?
			    GOTO_OFFSET + 1 : size)))
	  return FALSE;
#else //!(STOPBIT,NEXTBIT)
	if (!(outfile.write((char *)oa, size)))
	  return FALSE;
#endif //!(STOPBIT,NEXTBIT)
#else //!FLEXIBLE
	if (!(outfile.write((char *)&output_arc[0], sizeof output_arc[0])))
	  return FALSE;
#endif //FLEXIBLE
      }


      // For all arcs of this node or its brother
      // write arcs of descendants
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
      // reverse the order to maximize the number of next pointers
      for (i = limit - 1; i >= 0; --i) {
#else //!(FLEXIBLE,STOPBIT,NEXTBIT)
      for (i = 0; i < limit; i++) {
#endif //!(FLEXIBLE,STOPBIT,NEXTBIT)
#ifdef JOIN_PAIRS
#ifndef STOPBIT
        if (i >= no_of_children)
          p = big_brother->children[1].child;
        else
#endif
#endif
	p = children[i].child;
	if (p) {
	  if (p->big_brother)
	    p = p->big_brother;
          // This must be done twice, as a 1-arc node may refer to 2-arc node
          // merged with another 2-arc node
          if (p->big_brother  && p->brother_offset >= 0)
            p = p->big_brother;
	  if (!(p->write_arcs(outfile)))
	    return FALSE;
	}
      }
    }
  }
  return TRUE;
}//tnode::write_arcs


/* Name:	delete_branch
 * Class:	None. Friend of class tnode.
 * Purpose:	Deletes a subgraph beginning at the node.
 * Parameters:	n	- (i/o) starting node of the subgraph to delete.
 * Returns:	Nothing.
 * Remarks:	Only nodes with hit_count greater than zero are deleted.
 *		There is no need to deregister deleted nodes.
 *		Only unique nodes are registered.
 *		Only non-unique nodes are deleted.
 */
void
delete_branch(tnode *branch)
{
#ifdef DEBUG
  cerr << "Deleting branch: "; branch->print();
#endif
  if (branch->hit_count == -1)
    // branch is to be deleted higher up
    return;

  if (branch->hit_count) {
    // the branch is still in use
    branch->hit_count--;
  }
  else {
    branch->hit_count = -1;	// to avoid loops
    for (int i = 0; i < branch->no_of_children; i++) {
      if (branch->children[i].child)
	delete_branch(branch->children[i].child);
    }
    delete branch;
  }
}//delete_branch


/* Name:	set_link
 * Class:	tnode
 * Purpose:	Establish link between this node, and a node having more links
 *		that include also all links from this node.
 * Parameters:	big_guy		- (i) bigger node;
 *		offset		- (i) offset to the set of arcs of this node
 *					found in big_guy.
 * Returns:	Pointer to this node.
 * Remarks:	None.
 */
tnode *
tnode::set_link(tnode *big_guy, const int offset)
{
#ifdef DEBUG
  cerr << "Node " << (long)this << " with ";
  for (int i = 0; i < no_of_children; i++)
    cerr << children[i].surf_letter << children[i].lex_letter;
  cerr << "\n now points to " << (long)big_guy << "+" << offset << " with ";
  for (int j = 0; j < big_guy->no_of_children; j++)
    cerr << big_guy->children[j].surf_letter
         << big_guy->children[j].lex_letter;
  cerr << "\n";
#endif
  big_brother = big_guy;
  brother_offset = offset;
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT) && defined(MORE_COMPR)
  if (big_guy->free_end > big_guy->no_of_children - offset)
    big_guy->free_end = big_guy->no_of_children - offset;
#endif
  return this;
}//tnode::set_link


/***	EOF tnode.cc	***/
