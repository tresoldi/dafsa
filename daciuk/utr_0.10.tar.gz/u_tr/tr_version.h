/***	tr_version.h	***/

const char *VERSION = "Ver. 0.10, Sep. 17th, 2002.";

/***	tr_version.h	***/
