/***	tr.h		***/

/*	Copyright (C) Jan Daciuk, 1996	*/

/* This structure describes a labelled arc in a transducer */

#ifndef		TR_H
#define		TR_H

#if defined(NEXTBIT) && !defined(STOPBIT)
#undefine	NEXTBIT
#endif

#ifdef FLEXIBLE
/* Name:	bytes2int
 * Class:	None
 * Purpose:	Converts a string of bytes into an integer.
 * Parameters:	bytes		- (i) a vector of bytes to be converted;
 *		n		- (i) length of the vector.
 * Returns:	Integer value computed from the vector.
 * Remarks:	This is used because certain fields in transducer's arcs
 *		are of variable size depending on the total number of arcs
 *		in the transducer. The side effect is portability.
 */
inline int
bytes2int(const unsigned char *bytes, const int n)
{
  register int r = 0;
  register int i;
  for (i = n - 1; i >= 0; --i) {
    r <<= 8; r |= bytes[i];
  }
  return r;
}
#endif /*FLEXIBLE*/

/* This constant depends on the representation of the # of children for node.
 * It MUST BE a power of 2 minus 1.
 */
const int	MAX_ARCS_PER_NODE = 255;

typedef		unsigned int		fas_pointer;
typedef		const char	*tr_arc_pointer;


#ifndef FLEXIBLE

/* Class name:	tr_arc
 * Purpose:	Provide a structure for a final state transducer.
 * Methods:	children	- returns the number of children of the node
 *				  the current arc leads to;
 *		is_final	- whether the node the arc leads to is final;
 *		set_children	- sets the number of children of the node
 *				  the current arc leads to to the given value;
 *		set_final	- mark the arc as final (i.e. leading to
 *				  a final node) or not according to `f'.
 * Remarks:	Both the number of children and information whether the arc
 *		leads to a final node are kept in a single char. This is
 *		done in order to have sizeof tr_arc equal to 4.
 */
class tr_arc {
public:
  fas_pointer	go_to;		/* Index in transducers's table of arcs.
				 * It can be understood as an address of
				 * the node the arc leads to.
				 * That place has several (see counter)
				 * arc elements that say where to go to
				 * on seeing a particular character.
				 */
  short int		counter;	/* The MSB (most significant bit) tells
				 * whether the node reached by this arc
				 * is final, or not. If MSB is set, the
				 * node is final.
				 * (counter & 0x3FF) says how many arcs
				 * lead from the node reached by this arc.
				 */
  char		surf_letter;	/* This arc should be followed on encountering
				 * this letter in surface string.
				 */
  char		lex_letter;	/* This arc should be followed on encountering
				 * this character in lexical string.
				 */

  /* Returns number of children of the node this arc leeds to */
  int children(void) const { return (counter & 0x3ff); }

  /* Returns TRUE if surface string may end with this arc */
  int surf_is_final(void) const { return ((counter & 0x8000) != 0); }

  /* Returns TRUE if this is a final arc */
  int is_final(void) const { return ((counter &0x4000) != 0); }

  /* Sets the number of children of the node the arc leeds to */
  int set_children(const int kids)
    {return(counter = ((counter&0xC000) | kids));}

  /* Sets surface string possible end marker */
  void set_surf_final(const int fin)
    { if (fin) counter |= 0x8000; else counter &= 0x7fff; }

  /* Sets final arc marker */
  void set_final(const int fin)
    { if (fin) counter |= 0x4000; else counter &= 0xbfff; }
};/*class tr_arc*/

typedef const tr_arc		*tr_arc_ptr;


#else //FLEXIBLE

const int GOTO_OFFSET = 2;
const int FINAL_BIT_MASK = 1;
const int FINAL_SURF_BIT_MASK = 2;
const int STOP_BIT_MASK = 4;
const int NEXT_BIT_MASK = 8;

#ifdef NEXTBIT
const int GOTO_SHIFT = 4;
#else
const int GOTO_SHIFT = 3;
#endif /*NEXTBIT*/

/*FLEXIBLE*/
class tr_arc_ptr {
 public:
  tr_arc_pointer	arc;	/* the arc itself */
  static int		gtl;	/* length of the goto field */
  static int		size;	/* size of the arc */
#ifdef NUMBERS
  static int		entryl;	/* size of number of entries field */
  static int		aunit;	/* how many bytes arc number represents */
#endif /*NUMBERS*/
#ifndef STOPBIT
  static int		ctl;	/* transition counter length */
#else /*STOPBIT*/
#ifdef NEXTBIT
  static const char	*curr_dictionary; /* starting transition */
#endif /*NEXTBIT*/
#endif /*STOPBIT*/

  tr_arc_ptr(void) { arc = NULL; } /* constructor */
  tr_arc_ptr(const tr_arc_pointer a) { arc = a; } /* constructor */
  tr_arc_ptr & operator=(tr_arc_pointer a) { arc = a; return *this; }

  int is_last(void) const {   /* returns true if the arc is the last in node */
    return ((arc[GOTO_OFFSET] & STOP_BIT_MASK) == STOP_BIT_MASK);
  }

  int is_final(void) const {	/* return TRUE if the arc is final */
    return ((arc[GOTO_OFFSET] & FINAL_BIT_MASK) == FINAL_BIT_MASK);
  }

  int is_surf_final(void) const { /* return TRUE if the arc is surf final */
    return ((arc[GOTO_OFFSET] & FINAL_SURF_BIT_MASK) == FINAL_SURF_BIT_MASK);
  }

  char get_surf(void) const {	/* return surface label */
    return arc[0];
  }

  char get_lex(void) const {	/* return lexical label */
    return arc[1];
  }

  fas_pointer get_goto(void) const { /* get number of the target node */
#if defined(NEXTBIT) && defined(STOPBIT)
    if ((arc[GOTO_OFFSET] & NEXT_BIT_MASK) == NEXT_BIT_MASK) {
      return ((arc - curr_dictionary) + GOTO_OFFSET + 1);
    }
    else {
      return bytes2int((const unsigned char *)arc + GOTO_OFFSET, gtl)
	>> GOTO_SHIFT;
    }
#else
    return bytes2int((const unsigned char *)arc + GOTO_OFFSET, gtl) >>
      GOTO_SHIFT;
#endif
  }

  tr_arc_ptr & operator++(void) { /* get next arc of the same node */
    arc += size;		/* don't care about the last arc */
    return *this;
  }

  tr_arc_pointer first_node(tr_arc_pointer curr_dict) {	/* get address of 1. */
    return (curr_dict
#ifdef NUMBERS
	    + entryl * 2
#endif
	    + size);
  }
};/*class tr_arc_ptr*/

#ifndef STOPBIT

/*FLEXIBLE,!STOPBIT*/
/* Name:	tr_get_children
 * Class:	None
 * Purpose:	Returns number of children of node pointed to by the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	Number of children of node reached by arc.
 * Remarks:	FLEXIBLE version. The first two bytes of an arc are the
 *		characters - this is why p + 2 is used below.
 */
inline int
tr_get_children(tr_arc_ptr p) /*FLEXIBLE,!STOPBIT*/
{
  return bytes2int((unsigned char *)(p.arc + 2), p.ctl);
}/*tr_get_children*/

/*FLEXIBLE,!STOPBIT*/
/* Name:	tr_get_goto
 * Class:	None
 * Purpose:	Returns the go_to field.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	The go_to field of the arc.
 * Remarks:	FLEXIBLE version. The first two bytes of an arc are
 *		the 2 characters (this is why p + 2 appears), and then
 *		comes the counter that is ctl characters long. The next field
 *		is the go_to field.
 *		The two most significant bits of the go_to field are the status
 *		bits and they have nothing to do with arc numbers. They are
 *		removed by using a mask.
 */
inline fas_pointer
tr_get_goto(tr_arc_ptr p)
{
  int g = bytes2int((const unsigned char *)(p.arc + 2) + p.ctl, p.gtl);
  int mask = 0xc0 << (8 * (p.gtl - 1));
  return (g & ~mask);
}/*tr_get_goto*/

/*FLEXIBLE,!STOPBIT*/
/* Name:	tr_get_final
 * Class:	None
 * Purpose:	Returns the final status of the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	TRUE if the arc is final, FALSE otherwise.
 * Remarks:	FLEXIBLE version.
 */
inline int
tr_get_final(tr_arc_ptr p)
{
  return ((p.arc[1 + p.ctl + p.gtl] & 0x80) != 0);
}/*tr_get_final*/

/*FLEXIBLE,!STOPBIT*/
/* Name:	tr_get_surf_final
 * Class:	None
 * Purpose:	Returns the surface final status of the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	TRUE if the arc is final at surface level, FALSE otherwise.
 * Remarks:	FLEXIBLE version.
 */
inline int
tr_get_surf_final(tr_arc_ptr p)
{
  return ((p.arc[1 + p.ctl + p.gtl] & 0x40) != 0);
}/*tr_get_surf_final*/

/*FLEXIBLE,!STOPBIT*/
/* Name:	tr_get_surf
 * Class:	None
 * Purpose:	Obtains surface character of the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	Surface character of the arc.
 * Remarks:	FLEXIBLE version.
 */
inline char
tr_get_surf(tr_arc_ptr p)
{
  return p.arc[0];
}/*tr_get_surf*/

/*FLEXIBLE,!STOPBIT*/
/* Name:	tr_get_lex
 * Class:	None
 * Purpose:	Obtains lexical character of the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	Lexical character of the arc.
 * Remarks:	FLEXIBLE version.
 */
inline char
tr_get_lex(tr_arc_ptr p)
{
  return p.arc[1];
}/*tr_get_lex*/

/*FLEXIBLE,!STOPBIT*/
/* Name:	tr_first_node
 * Class:	None
 * Purpose:	Given the address of a dictionary (transducer), find the first
 *		transition (arc).
 * Parameters:	curr_dict	- (i) beginning of the current dictionary.
 * Result:	Pointer to the first arc of the dictionary (transducer).
 * Remarks:	FLEXIBLE version.
 */
inline tr_arc_ptr
tr_first_node(tr_arc_ptr curr_dict)
{
  return curr_dict.arc + curr_dict.size;
}/*tr_first_node*/

/*FLEXIBLE,!STOPBIT*/
/* Name:	tr_next_node
 * Class:	None
 * Purpose:	Finds the node pointed to by the start arc.
 * Parameters:	curr_dict	- (i) beginning of the current dictionary;
 *		start		- (i) current arc.
 * Returns:	Pointer to next node (indicated by the go_to field).
 * Remarks:	FLEXIBLE version.
 */
inline tr_arc_ptr
tr_next_node(tr_arc_ptr curr_dict, tr_arc_ptr start)
{
  return curr_dict.arc + (tr_get_goto(start) * start.size);
}/*tr_next_node*/

/*FLEXIBLE,!STOPBIT*/
/* Name:	tr_inc_next
 * Class:	None
 * Purpose:	Finds the next arc after the current one (the next sibling).
 * Parameters:	curr_arc	- (i/o) current arc.
 * Returns:	Next arc after the current.
 * Remarks:	FLEXIBLE version.
 */
inline tr_arc_ptr
tr_inc_next(tr_arc_ptr &curr_arc)
{
  return curr_arc.arc += curr_arc.size;
}/*tr_next_node*/



#endif /*!STOPBIT*/
#endif /*FLEXIBLE*/
#ifndef FLEXIBLE

/*!FLEXIBLE*/
/* These functions belong to no class, so they can be used where
   class methods would not do. They are needed, because in FLEXIBLE
   the arc pointer is a pointer to char.
*/
/* Name:	tr_get_children
 * Class:	None
 * Purpose:	Returns number of children of node pointed to by the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	Number of children of node reached by arc.
 * Remarks:	InFLEXIBLE version.
 */
inline int
tr_get_children(tr_arc_ptr p)
{
  return p->children();
}/*tr_get_children*/

/*!FLEXIBLE*/
/* Name:	tr_get_goto
 * Class:	None
 * Purpose:	Returns the go_to field.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	The go_to field of the arc.
 * Remarks:	The go_to field is public, so access functions are not needed.
 *		InFLEXIBLE version.
 */
inline fas_pointer
tr_get_goto(tr_arc_ptr p)
{
  return p->go_to;
}/*tr_get_goto*/

/*!FLEXIBLE*/
/* Name:	tr_get_final
 * Class:	None
 * Purpose:	Returns the final status of the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	TRUE if the arc is final, FALSE otherwise.
 * Remarks:	InFLEXIBLE version.
 */
inline int
tr_get_final(tr_arc_ptr p)
{
  return p->is_final();
}/*tr_get_final*/

/*!FLEXIBLE*/
/* Name:	tr_get_surf_final
 * Class:	None
 * Purpose:	Returns the surface final status of the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	TRUE if the arc is final at surface level, FALSE otherwise.
 * Remarks:	InFLEXIBLE version.
 */
inline int
tr_get_surf_final(tr_arc_ptr p)
{
  return p->surf_is_final();
}/*tr_get_surf_final*/

/*!FLEXIBLE*/
/* Name:	tr_get_surf
 * Class:	None
 * Purpose:	Obtains surface character of the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	Surface character of the arc.
 * Remarks:	InFLEXIBLE version.
 *		surf_letter is public, so no access function is needed.
 */
inline char
tr_get_surf(tr_arc_ptr p)
{
  return p->surf_letter;
}/*tr_get_surf*/

/*!FLEXIBLE*/
/* Name:	tr_get_lex
 * Class:	None
 * Purpose:	Obtains lexical character of the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	Lexical character of the arc.
 * Remarks:	lex_character is public, so no access function is needed.
 *		InFLEXIBLE version.
 */
inline char
tr_get_lex(tr_arc_ptr p)
{
  return p->lex_letter;
}/*tr_get_lex*/

/*!FLEXIBLE*/
/* Name:	tr_first_node
 * Class:	None
 * Purpose:	Given the address of a dictionary (transducer), find the first
 *		transition (arc).
 * Parameters:	curr_dict	- (i) beginning of the current dictionary.
 * Result:	Pointer to the first arc of the dictionary (transducer).
 * Remarks:	InFLEXIBLE version.
 */
inline tr_arc_ptr
tr_first_node(tr_arc_pointer curr_dict)
{
  return (tr_arc_ptr)(curr_dict + 1);
}/*tr_first_node*/

/*!FLEXIBLE*/
/* Name:	tr_next_node
 * Class:	None
 * Purpose:	Finds the node pointed to by the start arc.
 * Parameters:	curr_dict	- (i) beginning of the current dictionary;
 *		start		- (i) current arc.
 * Returns:	Pointer to next node (indicated by the go_to field).
 * Remarks:	InFLEXIBLE version.
 */
inline tr_arc_ptr
tr_next_node(tr_arc_pointer curr_dict, tr_arc_ptr start)
{
  return (tr_arc_ptr)(curr_dict + start->go_to);
}/*tr_next_node*/

/*!FLEXIBLE*/
/* Name:	tr_inc_next
 * Class:	None
 * Purpose:	Finds the next arc after the current one (the next sibling).
 * Parameters:	curr_arc	- (i/o) current arc.
 * Returns:	Next arc after the current.
 * Remarks:	FLEXIBLE version.
 */
inline tr_arc_ptr
tr_inc_next(tr_arc_ptr &curr_arc)
{
  return curr_arc++;
}/*tr_next_node*/

#endif /*!FLEXIBLE*/



#ifdef FLEXIBLE
#ifdef STOPBIT



/*---*/

/* Name:	tr_get_goto
 * Class:	None
 * Purpose:	Returns the go_to field.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	The go_to field of the arc.
 * Remarks:	None.
 */
inline fas_pointer
tr_get_goto(tr_arc_ptr p)
{
  return p.get_goto();
}/*tr_get_goto*/

/* Name:	tr_get_final
 * Class:	None
 * Purpose:	Returns the final status of the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	TRUE if the arc is final, FALSE otherwise.
 * Remarks:	FLEXIBLE version.
 */
inline int
tr_get_final(tr_arc_ptr p)
{
  return p.is_final();
}/*tr_get_final*/

/* Name:	tr_get_surf_final
 * Class:	None
 * Purpose:	Returns the surface final status of the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	TRUE if the arc is final at surface level, FALSE otherwise.
 * Remarks:	FLEXIBLE version.
 */
inline int
tr_get_surf_final(tr_arc_ptr p)
{
  return p.is_surf_final();
}/*tr_get_surf_final*/

/* Name:	tr_get_surf
 * Class:	None
 * Purpose:	Obtains surface character of the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	Surface character of the arc.
 * Remarks:	FLEXIBLE version.
 */
inline char
tr_get_surf(tr_arc_ptr p)
{
  return p.get_surf();
}/*tr_get_surf*/

/* Name:	tr_get_lex
 * Class:	None
 * Purpose:	Obtains lexical character of the arc.
 * Parameters:	p		- (i) arc pointer.
 * Returns:	Lexical character of the arc.
 * Remarks:	FLEXIBLE version.
 */
inline char
tr_get_lex(tr_arc_ptr p)
{
  return p.get_lex();
}/*tr_get_lex*/

/* Name:	tr_first_node
 * Class:	None
 * Purpose:	Given the address of a dictionary (transducer), find the first
 *		transition (arc).
 * Parameters:	curr_dict	- (i) beginning of the current dictionary.
 * Result:	Pointer to the first arc of the dictionary (transducer).
 * Remarks:	FLEXIBLE version.
 */
inline tr_arc_ptr
tr_first_node(tr_arc_ptr curr_dict)
{
  return curr_dict.first_node(curr_dict.arc);
}/*tr_first_node*/

/* Name:	tr_next_node
 * Class:	None
 * Purpose:	Finds the node pointed to by the start arc.
 * Parameters:	curr_dict	- (i) beginning of the current dictionary;
 *		start		- (i) current arc.
 * Returns:	Pointer to next node (indicated by the go_to field).
 * Remarks:	FLEXIBLE version.
 */
inline tr_arc_ptr
tr_next_node(tr_arc_ptr curr_dict, tr_arc_ptr start)
{
  return curr_dict.arc + start.get_goto() 
#ifndef NEXTBIT
    * start.size
#endif
    ;
}/*tr_next_node*/

/* Name:	tr_inc_next
 * Class:	None
 * Purpose:	Finds the next arc after the current one (the next sibling).
 * Parameters:	curr_arc	- (i/o) current arc.
 * Returns:	Next arc after the current.
 * Remarks:	FLEXIBLE version.
 */
inline tr_arc_ptr
tr_inc_next(tr_arc_ptr &curr_arc)
{
  return ++curr_arc;
}/*tr_inc_next*/

#endif //STOPBIT
#endif //FLEXIBLE

#if defined(FLEXIBLE) && defined (STOPBIT)
#define forallnodes(i) \
          for (int i##nlast = 1;\
                 i##nlast;\
                 i##nlast = !(next_node.is_last()), ++next_node)

#elif defined(FLEXIBLE) && !defined(STOPBIT)
#define forallnodes(i) \
          int i##kids = tr_get_children(start); \
          for (int i = 0; i < i##kids; i++, ++next_node)
#else
#define forallnodes(i) \
          int i##kids = start->children(); \
          for (int i = 0; i < i##kids; i++, ++next_node)
#endif


/* The following structure contains a transducer file header */
struct tr_signature {
  char		sig[4];		/* Contains transducer identifier */
  char		ver;		/* transducer type number */
  char		filler;		/* char used as filler */
  char		annot_sep;	/* char that separates annotations from lex */
  char		gtl;		/* for future use */
};/*struct tr_signature */

#endif
/***	EOF tr.h	***/
