/***	one_word_io.cc	***/

/*	Copyright (C) Jan Daciuk, 1996	*/

#include	<iostream>
#include	<string.h>
#include	"nstr.h"
#include	"tr.h"
#include	"commont.h"

/* Name:	tr_io
 * Class:	tr_io (constructor).
 * Purpose:	Initialize stream variables, allocate buffer if needed.
 * Parameters:	in_file		- (i) input stream to be used with tr_io;
 *		out_file	- (i) output stream to be used with tr_io;
 *		max_line_length	- (i) max input line length (buffer size);
 *		word_chars	- (i) characters that are parts of a word
 *					(NULL means standard).
 * Returns:	Nothing.
 * Remarks:	I/O operations in one_word_io module are so simple, that
 *		no buffer is allocated.
 */
tr_io::tr_io(istream *in_file, ostream &out_file, const int max_line_length,
	     const char *word_chars)
: output(out_file), Max_line_len(max_line_length)
{
  input = in_file;
  proc_state = stream_state = 1;
}//tr_io::tr_io


/* Name:	~tr_io
 * Class:	tr_io
 * Purpose:	Deallocate memory.
 * Parameters:	None.
 * Returns:	Nothing.
 * Remarks:	Since no buffer is allocated, there is nothing to deallocate,
 *		and generally there is nothing to do.
 */
tr_io::~tr_io(void)
{
}//tr_io::~tr_io


/* Name:	operator>>
 * Class:	None (friend of class tr_io).
 * Purpose:	Read word from input and echo it on output with a trailing
 *		colon.
 * Parameters:	s		- (o) where to put the string read.
 * Returns	in_file.
 * Remarks:	One word per line is assumed. Lines longer than Max_word_len
 *		are truncated.
 */
tr_io &
tr_io::operator>>(char *s)
{
  char		junk;

  input->get(s, Max_word_len, '\n');
  input->get(junk);
  stream_state = input->good();
  if (stream_state)
    output << s << ":";
  return *this;
}//tr_io::operator>>

/* Name:	print_OK
 * Class:	tr_io
 * Purpose:	Prints OK on output.
 * Parameters:	None.
 * Returns:	this.
 * Remarks:	I know that this `i = ...' thing is horrible.
 */
tr_io &
tr_io::print_OK(void)
{
  int i;

  i = (output << " *OK*\n") ? 1 : 0;
  stream_state = i;
  return *this;
}//tr_io::print_OK


/* Name:	print_not_found
 * Class:	tr_io
 * Purpose:	Prints "*not found*" on output.
 * Parameters:	None.
 * Returns:	this.
 * Remarks:	I know that this `i = ...' thing is horrible, but g++ did not
 *		allow me to assign the value to stream_state directly.
 */
tr_io &
tr_io::print_not_found(void)
{
  int	i;

  i = (output << " *not found*\n") ? 1 : 0;
  stream_state = i;
  return *this;
}//tr_io::print_not_found

/* Name:	print_repl
 * Class:	tr_io
 * Purpose:	Prints a replacement for an incorrect word.
 * Parameters:	r		- (i) list of replacements.
 * Returns:	this.
 * Remarks:	I Know that this `i = ...' thing is horrible.
 */
tr_io &
tr_io::print_repls(word_list *r)
{
  int i;
  int is_first = 1;

  for (r->reset(); r->item(); r->next()) {
    output << (is_first ? " " : ", ") << r->item();
    is_first = 0;
  }
  i = (output << "\n") ? 1 : 0;
  stream_state = i;
  return *this;
}//tr_io::print_repl


/* Name:	print_morph
 * Class:	tr_io
 * Purpose:	Prints a morphology list for a word.
 * Parameters:	s		- (i) list of morphological descriptions.
 * Returns:	this.
 * Remarks:	I Know that this `i = ...' thing is horrible.
 */
tr_io &
tr_io::print_morph(word_list *s)
{
  int i;
  int is_first = 1;

  for (s->reset(); s->item(); s->next()) {
    output << (is_first ? " " : ", ") << s->item();
    is_first = 0;
  }
  i = (output << "\n") ? 1 : 0;
  stream_state = i;
  return *this;
}//tr_io::print_morph





/***	EOF one_word_io	***/
