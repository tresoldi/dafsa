/***	one_word_io.h	***/

/*	Copyright (C) Jan Daciuk, 1996	*/

class one_word_io : public tr_io {
public:
  one_word_io(istream &in_file, ostream &out_file, const int max_line_length)
    : tr_io(in_file, out_file, max_line_length) {};
  ~one_word_io(void);
  virtual int tr_control(const tr_io::contr_oper op);
};/*one_word_io*/

/***	EOF one_word_io.h	***/
