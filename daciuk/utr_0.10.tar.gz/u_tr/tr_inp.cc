/***	tr_inp.cc	***/

/*	Copyright (C) Jan Daciuk, 1996	*/

#include	<iostream>
#include	<stdlib.h>
#include	<string.h>
#include	"tr_inp.h"

extern char	FILLER;
extern char	ANNOT_SEPARATOR;
extern char	INPUT_SEPARATOR;

const	int	WORD_BUFFER_LENGTH = 128;

using namespace std;

/* Name:	transd_inp
 * Class:	transd_inp
 * Purpose:	Allocates memory for buffers. Constructor.
 * Parameters:	None.
 * Returns:	Nothing.
 * Remarks:	None.
 */
transd_inp::transd_inp(void)
{
  input_buffer = new char[WORD_BUFFER_LENGTH];
  surf_buffer = new char[WORD_BUFFER_LENGTH];
  lex_buffer = new char[WORD_BUFFER_LENGTH];
  s_len = 0; l_len = 0;
}//transd_inp::transd_inp


/* Name:	~transd_inp
 * Class:	transd_inp
 * Purpose:	Deallocates memory used by buffers. Destructor.
 * Parameters:	None.
 * Returns:	Nothing.
 * Remarks:	None.
 */
transd_inp::~transd_inp(void)
{
  delete [] input_buffer;
  delete [] surf_buffer;
  delete [] lex_buffer;
}//transd_inp::~transd_inp


/* Name:	operator>>
 * Class:	None (friend of transd_inp).
 * Purpose:	Reads a line from input and extracts surface and lexical forms
 *		from it.
 * Parameters:	in_file		- (i) input stream;
 *		tr_inp		- (o) information for the transducer.
 * Returns:	Input stream.
 * Remarks:	This is a new, simpler version (for unsorted data only).
 *		There is no need to convert input to a special format.
 *
 *		Now the input is:
 *
 *		surface		lexical		annotations
 *
 *		where surface, lexical, and annotations are separated with
 *		spaces and HTs.
 *
 *		Annotations are optional.
 *
 *		Input was: one character from surface string, one from lexical
 *		string, then from surface string, then form lexical one,...
 *		FILLER characters from the end of those strings are removed.
 */
istream &
operator>>(istream &in_file, transd_inp &tr_inp)
{
  int	len;
  char	junk;

  char	*s = tr_inp.surf_buffer;
  char	*l = tr_inp.lex_buffer;
  char	*w = tr_inp.input_buffer;
  in_file.get(tr_inp.input_buffer, WORD_BUFFER_LENGTH, '\n');
  in_file.get(junk);			// get rid of annoying "\n"
  len = strlen(tr_inp.input_buffer);
  if (len == 0) {
    return in_file;
  }
  while (junk != '\n') {
    char *tmp_buf = new char[tr_inp.buf_len + WORD_BUFFER_LENGTH];
    strcpy(tmp_buf, tr_inp.input_buffer);
    tmp_buf[tr_inp.buf_len - 1] = junk;
    delete [] tr_inp.input_buffer;
    tr_inp.input_buffer = tmp_buf;
    in_file.get(tr_inp.input_buffer + tr_inp.buf_len, WORD_BUFFER_LENGTH,
		'\n');
    in_file.get(junk);
    tr_inp.buf_len += WORD_BUFFER_LENGTH;
    w = tr_inp.input_buffer;
    delete [] tr_inp.surf_buffer;
    delete [] tr_inp.lex_buffer;
    s = tr_inp.surf_buffer = new char[tr_inp.buf_len];
    l = tr_inp.lex_buffer = new char[tr_inp.buf_len];
  }

  // surface form
  while (*w != '\0' && *w != INPUT_SEPARATOR)
    *s++ = *w++;
  *s = '\0';
  if (*w == INPUT_SEPARATOR)
    w++;

  // lexical form
  while (*w != '\0' && *w != INPUT_SEPARATOR)
    *l++ = *w++;
  if (*w == INPUT_SEPARATOR) {
    w++;
    *l++ = ANNOT_SEPARATOR;
  }
  while (*w != '\0')
    *l++ = *w++;
  *l = '\0';

  tr_inp.s_len = s - tr_inp.surf_buffer;
  tr_inp.l_len = l - tr_inp.lex_buffer;
  return in_file;
}//transd_inp::operator>>


  
  
/***	EOF tr_inp.cc	***/
