/***	accentt.cc	***/

/*	Copyright (c) Jan Daciuk, 1997	*/


#include	<iostream>
#include	<fstream>
#include	<string.h>
#include	<stdlib.h>
#include	<new>
#include	"tr.h"
#include	"nstr.h"
#include	"commont.h"
#include	"accentt.h"






/* Name:	accent_tr
 * Class:	accent_tr (constructor).
 * Purpose:	Open dictionary files and read automata from them.
 * Parameters:	dict_names	- (i) dictionary file names;
 *		language_file	- (i) file containing information about
 *					letters, esp. case.
 * Returns:	Nothing.
 * Remarks:	At least one dictionary file must be read.
 */
accent_tr::accent_tr(word_list *dict_names, const char *language_file)
: tr(dict_names, language_file)
{
}//accent_tr::accent_tr


/* Name:	accent_file
 * Class:	accent_tr
 * Purpose:	Restore accents in all words of a file.
 * Parameters:	io_obj		- (i/o) where to read words,
 *					and where to print them;
 *		equiv		- (i) character equivalent classes.
 * Returns:	Exit code.
 * Remarks:	Class variable `replacements' is set to the list of words
 *		equivalent to the `word'.
 */
int
accent_tr::accent_file(tr_io &io_obj, const char *equiv)
{
  char		word_buffer[Max_word_len];
  char		*word = &word_buffer[0];

  while (io_obj >> word) {
    if (accent_word(word, equiv)) {
      io_obj.print_repls(&replacements);
      replacements.empty_list();
    }
    else
      io_obj.print_not_found();
  }
  return state;
}//accent_tr::accent_file


/* Name:	accent_word
 * Class:	accent_tr
 * Purpose:	Restore accents of a word using all specified dictionaries.
 * Parameters:	word	- (i) word to be checked;
 *		equiv		- (i/o) classes of equivalences for characters.
 * Returns:	TRUE if words equal to the given one modulo diacritics are found,
 *		FALSE otherwise.
 * Remarks:	Class variable `replacements' is set to the list of equivalent
 *		words.
 *		The table of equivalent characters contains 256 characters,
 *		and contains:
 *		for characters with diacritics:
 *			- corresponding character without diacritic;
 *		for characters without diacritics:
 *			- that character.
 *		Note: this can be used for other forms of equivalencies,
 *		not necessarily with diacritics.
 */
int
accent_tr::accent_word(const char *word, const char *equiv)
{
  dict_list		*dict;
#ifdef CASECONV
  char			saved_char;
#endif

  char_eq = equiv;
  dictionary.reset();
  for (dict = &dictionary; dict->item(); dict->next()) {
    set_dictionary(dict->item());
    word_accents(word, 0, tr_first_node(current_dict));
#ifdef CASECONV
    if (word_syntax[(unsigned char)*word] == 2) {
      // word is uppercase - try lowercase
      saved_char = *word;
      *((char *)word) = casetab[(unsigned char)*word]; // change to lowercase
      word_accents(word, 0, tr_first_node(current_dict));
      *((char *)word) = saved_char; // restore original word
    }
#endif
  }

#ifdef CASECONV
  // Convert case of replacements to uppercase if the original was uppercase
  if (word_syntax[(unsigned char)*word] == 2) {
    replacements.reset();
    for (;replacements.item(); replacements.next()) {
      if (word_syntax[(unsigned char)(replacements.item()[0])] == 3) {
	// Word is lowercase - convert to uppercase
	replacements.item()[0] =
          casetab[(unsigned char)(replacements.item()[0])];
      }
    }
  }
#endif

  return replacements.how_many();
}//accent_tr::accent_word


/* Name:	word_accents
 * Class:	accent_tr
 * Purpose:	Find all words that have the same letters, but sometimes
 *		with diacritics.
 * Parameters:	word	- (i) word to look for;
 *		level	- (i) how many characters of the word have been
 *				considered so far;
 *		start	- (i) look at children of that node.
 * Returns:	TRUE if words equal to the given one modulo diacritics
 *		are found, FALSE otherwise.
 * Remarks:	Class variable `replacements' is set to the list of words
 *		equivalent to the `word'.
 *		The table of equivalent characters contains 256 characters,
 *		and contains:
 *		for characters with diacritics:
 *			- corresponding character without diacritic;
 *		for characters without diacritics:
 *			- that character.
 *		Note: this can be used for other forms of equivalencies,
 *		not necessarily with diacritics.
 */
int
accent_tr::word_accents(const char *word, const int level, tr_arc_ptr start)
{
  tr_arc_ptr	next_node = tr_next_node(current_dict, start);
  unsigned char	char_no;
  //  int		kids = tr_get_children(start);

  //  for (int i = 0; i < kids; i++, tr_inc_next(next_node)) {
  forallnodes(i) {
    candidate[level + 1] = '\0';
    char_no = (unsigned char)(tr_get_surf(next_node));
    if (*word == char_eq[char_no]) {
      candidate[level] = tr_get_surf(next_node);
      if (word[1] == '\0' && tr_get_surf_final(next_node))
	replacements.insert_sorted(candidate);
      else
	word_accents(word + 1, level + 1, next_node);
    }
    else if (tr_get_surf(next_node) == FILLER) {
      word_accents(word, level, next_node);
    }
  }
  return replacements.how_many();
}//accent_tr::word_accents


/***	EOF accentt.cc	***/
