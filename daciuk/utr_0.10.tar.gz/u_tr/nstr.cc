/***	nstr.cc		***/

/*	Copyright (C), Jan Daciuk, 1996	*/

#include	<string.h>
#include	"nstr.h"

/* Name:	nstrdup
 * Class:	None.
 * Purpose:	Create a copy of the given string in dynamically allocated
 *		memory.
 * Parameters:	word	- (i) string to copy.
 * Returns:	A pointer to the copy.
 * Remarks:	strdup that uses `new' instead of `malloc'.
 */
char *
nstrdup(const char *word)
{
  char *n = new char[strlen(word) + 1];
  return strcpy(n, word);
}//nstrdup

/* Name:	nnstrdup
 * Class:	None.
 * Purpose:	Create a copy of the first characters of the given string
 *		in dynamically allocated memory.
 * Parameters:	word	- (i) string to copy;
 *		n	- (i) number of characters to copy.
 * Returns:	A pointer to the copy.
 * Remarks:	Uses new, not malloc.
 */
char *
nnstrdup(const char *word, const int n)
{
  char *s = new char[n + 1];
  strncpy(s, word, n);
  s[n] = '\0';
  return s;
}//nnstrdup

/***	EOF nstr.cc	***/
