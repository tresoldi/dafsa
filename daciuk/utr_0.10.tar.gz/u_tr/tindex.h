/***	tindex.h	***/

/*	Copyright (C) Jan Daciuk, 1996	*/

#ifndef		TINDEX_H
#define		TINDEX_H

#ifndef		TNODE_H
#include	"tnode.h"
#endif

/* Types of indices: primary and secondary */
enum { PRIM_INDEX, SECOND_INDEX };

/* Specifies the size of a chunk of node table allocated at one for index */
const	int INDEX_SIZE_STEP		= 16;
extern const int MAX_ARCS_PER_NODE;

/* This is used in a secondary index as an intermediate level */
struct pair_index {
  tnode		**down;		/* to the table where each entry contains
                                 * a substring of the given length,
                                 * given number of children, and
				 * begins with the given letter.
                                 * This table contains only pointers
				 * to nodes,
				 * and is sorted alphabetically */
  int		counter;	/* number of entries below */
  int		size;		/* space allocated for entries below */
  char		surf;		/* surface level character */
  char		lex;		/* lexical level character */
};/*pair_index*/

struct tree_index {
  union down_pointer {
    tnode	**leaf;		/* to the table where each entry contains
                                 * a substring of the given length,
                                 * given number of children, and
				 * begins with the given letter.
                                 * This table contains only pointers
				 * to nodes,
				 * and is sorted alphabetically */
    tree_index	*indx;		/* points to a table of lower level */
    pair_index	*pind;		/* points to a table with pairs
				   of (surf, lex) characters
				   and corresponding down pointers */
  } down;
  int		counter;	/* number of entries in *down */
  int		size;		/* space allocated for entries in *down */
};//tree_index




/* Name:	get_index_by_name
 * Class:	None
 * Purpose:	Delivers appropriate index.
 * Parameters:	index_name	- (i) index number.
 * Returns:	Root of required index.
 * Remarks:	Currently two indices available: PRIM_INDEX and SECOND_INDEX.
 *		No parameter checking.
 */
tree_index *
get_index_by_name(const int index_name);


/* Name:	register_at_level
 * Class:	None.
 * Purpose:	Looks for an appropriate entry at the given level.
 *		If not found, then creates it.
 * Parameters:	discriminator	- (i) value that should be matched
 *					against `data';
 *		table_node	- (i/o) a node in the table of the upper
 *					level that points to the table
 *					that is to be searched;
 *		to_register	- (i) TRUE means register, otherwise
 *					find and DO NOT REGISTER;
 *		cluster_size	- (i) table size (in entries) at this level.
 * Returns:	A pointer to a table entry (existing previously or
 *		just created) pointing to the next (the lower) level.
 * Remarks:	None.
 */
tree_index *
register_at_level(const int discriminator, tree_index &table_node,
		  const int to_register,
		  const int cluster_size = MAX_ARCS_PER_NODE);


/* Name:	cmp_nodes
 * Class:	None (friend of class tnode).
 * Purpose:	Find if two subgraphs (represented by their root nodes)
 *		are isomorphic.
 * Parameters:	node1		- (i) first node;
 *		node2		- (i) second node;
 * Returns:	0		- if nodes are isomorphic;
 *		negative value	- if `node2' should precede `node1';
 *		positive value	- if `node2' should follow `node1'.
 * Description:	Only the children are compared for letters, being final,
 *		and addresses of the nodes they lead to.
 *		If they are equal, addresses of children are compared.
 * Remarks:	The number of children for the two nodes is not checked,
 *		as it assumed that the function is invoked only when
 *		the tree search has selected nodes of equal number of children
 *		for the comparison.
 *
 *		It is assumed that children are sorted alphabetically.
 *
 *		It is possible to compare addresses of children, because
 *		children are registered first, and all child nodes
 *		of the node to be registered (if any) are already registered.
 *
 *		In previous version, the addresses of children were compared
 *		first.  This should speed up the comparison, and decrease
 *		the number of compared nodes, as a strict order was introduced
 *		among nodes (which was not the case before).
 *
 *		However, this did not work. Arcs were modified, and addresses
 *		of children changed, so that the nodes in the index should
 *		be moved (deregistered and reregistered, or with a special
 *		function) to reflect the changes.
 *
 *		In the version 0.8, I have changed the definition
 *		of comp_or_reg, and I hope it will work with addresses of
 *		children compared first.
 */
int
cmp_nodes(const tnode *node1, const tnode *node2);

    
/* Name:	part_cmp_nodes
 * Class:	None (friend of class tnode).
 * Purpose:	Compares two subnodes.
 * Parameters:	small_node	- (i) node to be replaced;
 *		big_node	- (i) node that may contain the same arcs;
 *		offset		- (i) (optional) if present, take to comparison
 *					only arcs #offset from small_node;
 *		group_size	- (i) (optional) how many arcs to consider.
 * Returns:	< 0 if small_node < big_node,
 *		= 0 if small_node = big_node,
 *		> 0 if small_node > big_node.
 * Remarks:	Let the small node have arcs (c d f).
 *		If the big node is (b c d f g) we compare:
 *		(b c d f g)  (b c d f g)  (a b c f g)  (a b c f g)
 *		(c d f)        (c d f)<-found!
 *
 *		But for the big node being (b c d e f g):
 *		(b c d e f g)  (b c d e f g)  (b c d e f g)  (b c d e f g)
 *		(c d f)          (c d f)          (c d f)          (c d f)
 *		it does not work.
 *
 *		Maybe by chaging the order of arcs more arcs could be slashed.
 *
 *		It is assumed that both nodes compared
 *		have the same pseudonode. This is achieved
 *		with the index structure.
 */
int
part_cmp_nodes(const tnode *small_node, const tnode *big_node, int offset=-1,
	       int group_size=-1);


/* Name:	cmp_lpairs
 * Class:	None.
 * Purpose:	Seeks a letter pair in the intermediate level of register
 * Parameters:	p1		- (i) pointer to the node to be found;
 *		p2		- (i) pointer to the index structure;
 *		offset		- (i) arc offset in p1;
 * Returns:	0		- if structure found;
 *		negative	- if the structure corresponding to p1 node
 *					should be lower in the register;
 *		positive	- if the structure corresponding to p1 node
 *					should be higher in the register;
 * Remarks:	Last argument is provided for compatibility with other
 *		comparison functions.
 */
int
cmp_lpairs(const void *p1, const void *p2, int offset, int);

/* Name:	cmp_bnodes
 * Class:	None.
 * Purpose:	Wrapper for cmp_nodes for bsearch_ind.
 * Parameters:	p1		- (i) first node;
 *		p2		- (i) second node.
 * Returns:	0		- if nodes are isomorphic;
 *		negative value	- if p1 should precede p2;
 *		positive value	- if p1 should follow p2.
 * Remarks:	Last two parameters are provided for compatibility
 *		with other comparison functions.
 */
inline int
cmp_bnodes(const void *p1, const void *p2, int, int)
{
  return cmp_nodes((const tnode *)p1, *((const tnode **)p2));
}//cmp_bnodes

/* Name:	bpart_cmp
 * Class:	None.
 * Purpose:	Wrapper for part_cmp_nodes.
 * Parameters:	p1		- (i) smaller node;
 *		p2		- (i) bigger node;
 *		offset		- (i) subnode offset;
 *		group_size	- (i) number of nodes in subnode.
 * Returns:	0		- if nodes are isomorphic;
 *		negative value	- if p1 should precede p2;
 *		positive value	- if p1 should follow p2.
 * Remarks:	None.
 */
int
bpart_cmp(const void *p1, const void *p2, int offset, int group_size);


/* Name:	bsearch_ind
 * Class:	None.
 * Purpose:	Finds either a node (or a subnode) or a place where it
 *		should be inserted.
 * Parameters:	n		- (i) node to be found;
 *		low		- (i) first item;
 *		high		- (i) last item;
 *		item_size	- (i) item size (in bytes);
 *		cmp		- (i) comparison function;
 *		offset		- (i) subnode offset in a big node;
 *		group_size	- (i) number of arcs in a subnode.
 * Returns:	Address to either the node or an entry in the index
 *		leading to that node, or a place where it should be,
 *		if it were there.
 * Remarks:	I had to write my own bsearch function for two reasons:
 *		1) comparing subnodes requires additional parameters
 *			to the comparison function;
 *		2) I need to node where to put the node in case where it
 *			is missing in the register.
 */
void *
bsearch_ind(const tnode *n, void *low, void *high,
	    int (*cmp)(const void *, const void *, int, int),
	    const int item_size, const int offset, const int group_size);


/* Name:	register_at_pair_level
 * Class:	None.
 * Purpose:	Registers a node (or a pseudonode) at the character pair
 *		level.
 * Parameters:	c_node		- (i) the node (or a pseudonode)
 *					to be registered;
 *		table_node	- (i/o) index entry one level up;
 *		to_register	- (i) TRUE means register, FALSE - search only;
 *		offset		- (i) offset of the pseudonode
 *					(0 for a real node);
 *		group_size	- (i) number of arcs in a pseudonode
 *					(number of arcs in a real node).
 * Returns:	A pair_index structure pointing to the lowest level.
 * Remarks:	None.
 */
pair_index *
register_at_pair_level(const tnode *c_node, tree_index &table_node,
		       const int to_register, const int offset,
		       const int group_size);


/* Name:	register_subnodes
 * Class:	None.
 * Purpose:	Registers sets of `group_size' arcs as a pseudonode.
 * Parameters:	c_node		- (i) groups of arcs of c_node are to be
 *					registered as a pseudonode;
 *		group_size	- (i) number of arcs in a group.
 * Returns:	Nothing.
 * Remarks:	A pointer to the original full size node is registered in
 *		the secondary index.
 *
 *		As of version 0.8, I have replaced the number of children level
 *		(here superficial), with two levels corresponding to the
 *		surface and the lexical characters.
 */
void
register_subnodes(tnode *c_node, const int group_size);


/* Name:	tget_pseudo_offset
 * Class:	None (friend of class tnode).
 * Purpose:	Looks if it is possible to replace arcs of the smaller node
 *		with a subset of arcs of a larger node. If yes, then
 *		finds the position of the small node as a pseudonode
 *		within the big node.
 * Parameters:	small_node	- (i) node to be replaced;
 *		big_node	- (i) node that may contain the same arcs;
 * Returns:	Number of the arc of big_node that is the first of
 *		small_node->no_of_children arcs that are identical to the arcs
 *		of small_node, or -1 if such arcs not found.
 * Remarks:	Let the small node have arcs (c d f).
 *		If the big node is (b c d f g) we compare:
 *		(b c d f g)  (b c d f g)  (a b c f g)  (a b c f g)
 *		(c d f)        (c d f)<-found!
 *
 *		But for the big node being (b c d e f g):
 *		(b c d e f g)  (b c d e f g)  (b c d e f g)  (b c d e f g)
 *		(c d f)          (c d f)          (c d f)          (c d f)
 *		it does not work.
 *
 *		Maybe by chaging the order of arcs more arcs could be slashed.
 */
int
tget_pseudo_offset(const tnode *small_node, const tnode *big_node);


/* Name:	compress_or_register
 * Class:	None.
 * Purpose:	Find if there is subgraph in the transducer that is isomorphic
 *		to the subgraph that begins at the last child of this node.
 * Parameters:	l_node		- (i) parent of the node to be compressed
 *					or registered.
 * Returns:	TRUE if node compressed, FALSE if registered.
 * Remarks:	Because the node can be deleted, and replaced by a pointer
 *		to another node, the method must be invoked with the parent
 *		of the node in question, so that the pointer can be modified.
 *
 *		hit_count counts the number of (registered) links that lead
 *		to a node. hit_count = 0 means the node is not registered yet.
 *		hit_count is also used to avoid deleting nodes that are
 *		pointed to somewhere else in the transducer.
 */
int
compress_or_register(tnode *l_node, tnode *cr_node=NULL);


/* Name:	comp_or_reg
 * Class:	None.
 * Purpose:	Find if there is subgraph in the transducer that is isomorphic
 *		to the subgraph that begins at the last child of this node.
 * Parameters:	n		- (i/o) node to be registered or replaced by
 *					an already existing node.
 * Returns:	Pointer to n or to the equivalent node that replaced it.
 * Remarks:	hit_count counts the number of (registered) links that lead
 *		to a node. hit_count = 0 means the node is not registered yet.
 *		hit_count is also used to avoid deleting nodes that are
 *		pointed to somewhere else in the transducer.
 *
 *		Note that hit_count is always increased for the unique node,
 *		regardless whether it is the original parameter of comp_or_reg,
 *		or a node found found somewhere else in the transducer.
 *		This means that in the situation where we modify an existing
 *		path in the transducer (path from the first reentrant node,
 *		that is a node with more than one incoming arc), we should
 *		decrease hit_count for that node _before_ calling comp_or_reg.
 *		If an isomorphic node is found, then n can be deleted
 *		by delete_branch (note that delete_branch only deletes nodes
 *		that have hit_count equal to zero). Remember that the node
 *		n _must_ be unregistered first!!!
 *		If an isomorphic node is not found, then comp_or_reg simply
 *		restores the hit_count.
 */
tnode *
comp_or_reg(tnode *n);


/* Name:	find_or_register
 * Class:	None.
 * Purpose:	Finds an isomorphic subgraph in the transducer or registers
 *		a new node.
 * Parameters:	c_node		- (i) node to be found or registered;
 *		index_root	- (i/o) which index to use;
 *		register_it	- (i) if TRUE, register the node,
 *					if FALSE, find an isomorphic node.
 * Returns:	Pointer to an isomorphic node or NULL.
 * Remarks:	The index has levels indexed for:
 *		number of children
 *		hash function
 *		all features of the node
 *
 *		The secondary index has level indexed for:
 *		hash function
 *		character pairs
 *		all features of the node
 *
 *		index_root_name parameter may have two values:
 *		PRIM_INDEX (= 0) - primary index used normally in the program,
 *		SECOND_INDEX (= 1) - secondary index used in optimization.
 *
 *		The force_registration parameter is now abandoned.
 *		The only situation it was used was in appending a suffix,
 *		when a node from the suffix was isomorphic with the node
 *		to which the suffix was appended. The workaround is simply
 *		to unregister that node (the last node in the common prefix),
 *		because it should be unregistered and reregistered anyway.
 */
tnode *
find_or_register(tnode *c_node, const int index_root_name,
		   const int register_it);




/* Name:	unregister
 * Class:	none
 * Purpose:	Unregisters a node.
 * Parameters:	c_node		- node to unregister.
 * Returns:	TRUE if node unregistered, FALSE otherwise.
 * Remarks:	The index has levels indexed for:
 *		number of children
 *		hash function
 *		all features of the node
 *
 *		Unregistering removes the entry from the lowest level,
 *		leaving higher levels untouched (except for counters).
 *
 *		There is no unregistering procedure for the secondary index.
 */
int
unregister(tnode *c_node);


/* Name:	destroy_index
 * Class:	None
 * Purpose:	Destroys index structure (releasing memory!).
 * Parameters:	index_root	- (i) index to destroy.
 * Returns:	Nothing.
 * Remarks:	Nodes pointed to in the index are not destroyed.
 */
void
destroy_index(tree_index &index_root);

/* Name:	hash
 * Class:	None.
 * Purpose:	Computes a hash function for the node to be used in index.
 * Parameters:	n		- (i) node for which hash function is to be
 *					computed;
 *		start		- (i) first arc number
 *		how_many	- (i) how many arcs are to be considered.
 * Returns:	Hash function.
 * Remarks:	Value of hash function depends on labels of arcs going
 *		from this node.
 *		Due to problems with unregistering, dependency on addresses
 *		had to be abandoned.
 *		From the version 0.8, it is reintroduced.
 */
int
hash(const tnode *n, const int start, const int how_many);



/* Name:	share_arcs
 * Class:	None.
 * Purpose:	Tries to find if arcs of one node are a subset of another.
 *		If so, a reference to them is replaced by a reference
 *		to a part (a subset) of the other node.
 * Parameters:	root		- (i) root of the automaton.
 * Returns:	Number of suppressed arcs.
 * Remarks:	This must take A LOT of time!
 *
 *              The algorithm:
 *              Let n1 be the second biggest number of children per node
 *              in the automaton.
 *              Take all consecutive sequences of n1 arcs from each of
 *              nodes with the biggest number of arcs and register them
 *              as nodes in the secondary index.
 *              For each node with n1 children, search for an isomorphic
 *              node in the secondary index. If found, set a link
 *              from the smaller node to the bigger one.
 */
int
share_arcs(tnode *root);


//#ifdef DEBUG
/* Name:	show_index
 * Class:	None (friend of class node).
 * Purpose:	Show index contents.
 * Parameters:	index_name	- (i) index number.
 * Returns:	Nothing.
 * Remarks:	I hate optimization.
 */
void
show_index(const int index_name);
//#endif

#endif
/***	EOF tindex.h	***/
