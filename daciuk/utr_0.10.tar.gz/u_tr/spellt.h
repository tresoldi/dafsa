/***	spellt.h		***/

/*	Copyright (C) Jan Daciuk, 1996	*/


const int	Max_edit_distance = 3; /* max edit distance allowed */



/* Found candidates for replacements with additional information */
struct ranked_hits {
  char		*list_item;	/* candidate */
  int		dist;		/* edit distance between candidate and word */
  int		cost;		/* cost of restoring this word */
};


/* Name:	comp
 * Class:	None.
 * Purpose:	Compares two items.
 * Parameters:	it1		- (i/o) first item;
 *		it2		- (i) second item.
 * Returns:	< 0 if it1 < it2;
 *		= 0 if it1 = it2;
 *		> 0 if it1 > it2.
 * Remarks:	It is necessary to modify the distance field during
 *		the comparison, because otherwise the new item should replace
 *		the old one, and the would be too expensive.
 */
inline int
comp(const ranked_hits *it1, const ranked_hits *it2)
{
  int c;
  ranked_hits *rh1 = (ranked_hits *)it1;
  if ((c = strcmp(it1->list_item, it2->list_item)) == 0)
    if (it1->dist < it2->dist)
      rh1->dist = it2->dist;
  return c;
}/*comp*/

/* Name:	new_copy
 * Class:	None.
 * Purpose:	Creates a copy of the parameter in dynamic memory.
 * Parameters:	it		- (i) item to be copied.
 * Returns:	Copy of the item.
 * Remarks:	None.
 */
inline ranked_hits *
new_copy(const ranked_hits *it)
{
  ranked_hits	*rh;

  rh = new ranked_hits;
  memcpy(rh, it, sizeof(ranked_hits));
  return rh;
}/*new_copy*/


typedef		list<ranked_hits>	hit_list;


/* Class name:	H_matrix
 * Purpose:	Keeps track of already computed values of edit distance.
 * Methods:	H_matrix	- (constructor) reserves space and initializes;
 *		operator()	- provides matrix item of appropriate indices;
 *		set		- sets matrix item
 * Variables:	p		- the table itself;
 *		row_length	- number of columns;
 *		column_height	- number of rows;
 *		edit_distance	- max edit distance allowed for candidates.
 */
class H_matrix {
private:
  int	*p;
  int	row_length;
  int	column_height;
  int	edit_distance;
public:
  H_matrix(const int distance, const int max_length);
  ~H_matrix(void) { delete [] p; }
  int operator()(const int i, const int j);
  void set(const int i, const int j, const int val);
};/*H_matrix*/

class spell_tr : public tr {
protected:
  /* List of found words with their cost and edit distance */
  hit_list		results;

  /* Edit distance as specified in command line */
  int			edit_dist;

  /* Effective edit distance (modified by word length) */
  int			e_d;

  /* Matrix used for computing the edit distance between word and candidate */
  H_matrix		H;

#ifdef CHCLASS
  char			**first_column;	/* for each index equal to the code
					   of a single character that
					   may appear in text, and may be
					   replaced with a two-character
					   sequence, a pointer to a string
					   of such sequences (pairs of
					   characters) */
  char			**second_column;/* for each index equal to the code
					   of a single character that
					   may replace a two-letter sequence
					   of characters in a text, a pointer
					   to a string of such sequences
					   (pairs of characters) */
#endif

  /* Check if the word is in specified dictionaries
     if not, find replacements */
  int spell_word(const char * word);

  /* Find replacements (recursively) starting from arc `start' */
#ifdef CHCLASS
  hit_list *find_repl(const int depth, tr_arc_ptr start, const int word_index,
		      const int cand_index);
#else
  hit_list *find_repl(const int depth, const tr_arc_ptr start);
#endif

#ifdef CHCLASS
  /* Compute edit distance between word prefix and candidate prefix.
     First i characters from word, and j from candidate are considered.
     In presence of equivalent sequences of letters, i and j may count
     sequences rather than characters. */
  int ed(const int i, const int j, const int word_index, const int cand_index);

  /* Compute cutt-off edit distance at depth `depth' */
  int cuted(const int depth, const int word_index, const int cand_index);
#else
  /* Compute edit distance between word prefix and candidate prefix.
     First i characters from word, and j from candidate are considered.
     In presence of equivalent sequences of letters, i and j may count
     sequences rather than characters. */
  int ed(const int i, const int j);

  /* Compute cutt-off edit distance at depth `depth' */
  int cuted(const int depth);
#endif

  /* Rank replacements on their cost */
  int rank_replacements(void);

#ifdef RUNON
  /* find all pairs of words that concatenated form word */
  hit_list *find_runon(const char *word);

  /* Find next letter of the first word in a runon word */
  void next_runon(const char *word, tr_arc_ptr start, const int ind);
#endif

#ifdef CHCLASS
  /* Read a file defining equivalent characters and sequences (pairs)
     of characters */
  int read_ch_seq_equiv(const char *chsub_file);

  /* */
  int match_word(const int i, const int j);

  /* */
  int match_candidate(const int i, const int j);
#endif


public:
  /* Initialize */
  spell_tr(word_list *dict_names, const int distance,
	   const char *language_file = NULL, const char *chsub_file = NULL);
  ~spell_tr(void) {};
  /* Spell all words found in input stream io_obj */
  int spell_file(const int distance, tr_io &io_obj);
};/*class spell_tr*/



/* Name:	comp_cost
 * Class:	None.
 * Purpose:	Compares two ranked_hits structures on cost.
 * Parameters:	rh1		- (i) first structure;
 *		rh2		- (i) second structure.
 * Returns:	< 0 if rh1 < rh2
 *		= 0 if rh1 = rh2
 *		> 0 if rh1 > rh2.
 * Remarks:	Parameters must have the void pointer type for compatibility.
 */
int
comp_cost(const void *rh1, const void *rh2);

/***	EOF spellt.h	***/
