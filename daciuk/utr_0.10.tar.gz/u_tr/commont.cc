/***	commont.cc	***/

/*	Copyright (c) Jan Daciuk, 1997	*/


#include	<iostream>
#include	<fstream>
#include	<string.h>
#include	<stdlib.h>
#include	<ctype.h>
#include	<new>
#include	"tr.h"
#include	"nstr.h"
#include	"commont.h"


/* This must be defined somewhere, and this place seems best */


/* Arbitrary values - real values are to be computed */
#ifdef FLEXIBLE
int tr_arc_ptr::gtl = 2;
#ifndef STOPBIT
int tr_arc_ptr::ctl = 1;
#endif
int tr_arc_ptr::size = 5;
#ifdef STOPBIT
#ifdef NUMBERS
int	tr_arc_ptr::entryl = 0;	/* size of number of entries field */
int	tr_arc_ptr::aunit = 0;	/* how many bytes arc number represents */
#endif /*NUMBERS*/
#ifdef NEXTBIT
const char *tr_arc_ptr::curr_dictionary = NULL;
#endif //NEXTBIT
#endif //STOPBIT
#endif //FLEXIBLE


/* Name:	tr
 * Class:	tr (constructor).
 * Purpose:	Open dictionary files and read automata from them.
 * Parameters:	dict_names	- (i) dictionary file names;
 *		language_file	- (i) name of a file containing information
 *				  on what constitutes a word,
 *				  and more importantly - case conversions.
 * Returns:	Nothing.
 * Remarks:	At least one dictionary file must be read.
 */
tr::tr(word_list *dict_names, const char *language_file)
{
  int	at_least_one_good = FALSE;

  dict_names->reset();
  read_language_file(language_file);
  for (word_list *p = dict_names; p->item() != NULL; p->next())
    at_least_one_good |= read_fsa(p->item());
  state = !at_least_one_good;
}//tr::tr


/* Name:	read_language_file
 * Class:	tr.
 * Purpose:	Read file with word characters and prepare case table.
 * Parameters:	a_file		- (i) name of file with language description.
 * Returns:	TRUE if succeeded, FALSE otherwise.
 * Remarks:	Two class variables: word_syntax and casetable are set.
 *
 *		The format of the language file is as follows:
 *			The first character in the first line is a comment
 *			character. Each line that begins with that character
 *			is a comment.
 *			Note: it is usually `#' or ';'.
 *
 *			Characters are represented by themselves, the file
 *			is binary.
 *
 *			The first non-comment line contains all characters
 *			that can be used within a word. They normally include
 *			all letters, and may include other characters, such
 *			as a dash, or an apostrophe.
 *
 *		The format of the case table:
 *			The table contains 256 characters of codes 0-255.
 *
 *			For a lowercase letter, the table contains
 *			its uppercase equivalent.
 *			For an uppercase letter, the table contains
 *			its lowercase equivalent.
 *
 *			The other characters are not defined.
 */
int
tr::read_language_file(const char *file_name)
{
  const char *letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
  const int	Buf_len = 512;
  int		i;
  char		comment_char;
  char		junk;
  unsigned char	buffer[Buf_len];
  unsigned char	first;

  char *word_tab = new char[256];
  for (i = 0; i < 256; i++)
    word_tab[i] = '\0';
  if (file_name) {
    ifstream lang_f(file_name, ios::in /*| ios::nocreate*/);
    if (lang_f.bad()) {
      cerr << "Cannot open language file `" << file_name << "'\n";
      return FALSE;
    }
    if (lang_f.get((char *)buffer, Buf_len, '\n'))
      comment_char = buffer[0];
    else
      return FALSE;
    lang_f.get(junk);
    if (junk != '\n')
      cerr << "Lines in language file " << file_name << " are too long!\n";
    int read_word_chars = TRUE;
    while (read_word_chars && lang_f.get((char *)buffer, Buf_len, '\n')) {
      lang_f.get(junk);
      if (junk != '\n')
	cerr << "Lines in language file " << file_name << " are too long!\n";
      if ((first = buffer[0]) != comment_char) {
	for (unsigned char *p = buffer; *p; p++) {
	  word_tab[*p] = TRUE;
	}
	read_word_chars = FALSE;
      }
    }//while
    int read_case = TRUE;
    // first is lowercase
    int upper = 3;	// in word_tab, uppercase is marked with 2, lowercase 3
    while (read_case && lang_f.get((char *)buffer, Buf_len, '\n')) {
      lang_f.get(junk);
      if (junk != '\n')
	cerr << "Lines in language file " << file_name << " are too long!\n";
      if ((first = buffer[0]) != comment_char) {
	for (unsigned char *p = buffer; *p; p++) {
	  word_tab[*p] = upper;
	  if (upper == 2) {
	    // second letter in pair, first is in `first'
	    casetab[first] = (char)*p;
	    casetab[*p] = (char)first;
	  }
	  upper = 5 - upper;		// flip case
	  first = *p;
	}
	read_word_chars = FALSE;
      }
    }//while
    word_syntax = word_tab;
  }
  else {
    word_syntax = word_tab;
    for (const char *p = letters; *p; p++) {
      if (islower(*p)) {
	word_syntax[(unsigned char)*p] = 3;
	casetab[(unsigned char)*p] = toupper(*p);
      }
      else {
	word_syntax[(unsigned char)*p] = 2;
	casetab[(unsigned char)*p] = tolower(*p);
      }
    }
  }
  return TRUE;
}//tr::read_language_file


/* Name:	read_fsa
 * Class:	tr
 * Purpose:	Reads a transducer from a specified file and places it
 *		on a list of dictionaries.
 * Parameters:	dict_file_name	- (i) dictionary file name.
 * Returns:	TRUE if success, FALSE if failed.
 * Remarks:	None.
 */
int
tr::read_fsa(const char *dict_file_name)
{
#ifdef FLEXIBLE
#ifdef STOPBIT
#ifdef NEXTBIT
  const int	version = 3;
#else //!NEXTBIT
  const int	version = 2;
#endif //!NEXTBIT
#else //!STOPBIT
  const int	version = 1;
#endif //!STOPBIT
#else //!FLEXIBLE
  const int	version = 0;
#endif
  streampos	file_size;
  int		no_of_arcs;
  tr_arc_ptr	new_fsa;
#ifndef FLEXIBLE
  tr_arc	dummy;		/* to get the sizeof fsa_arc */
#endif
  tr_signature	sig_arc;
  dict_desc	dd;
#ifdef FLEXIBLE
  int		gtl;
#ifndef STOPBIT
  int		ctl;
#endif
#endif
  int		arc_size;
  

  // open dictionary file
  ifstream dict(dict_file_name, ios::in /*| ios::nocreate */ | ios::ate);
  if (dict.bad()) {
    cerr << "Cannot open dictionary file " << dict_file_name << "\n";
    return(FALSE);
  }

  // see how many arcs are there
#ifdef LOOSING_RPM
  // There is a bug in libstdc++ distributed in rpms.
  // This is a workaround (thanks to Arnaud Adant <arnaud.adant@supelec.fr>
  // for pointing this out).
  if (!dict.seekg(0,ios::end)) {
    cerr << "Seek on dictionary file failed. File is "
         << dict_file_name << "\n";
    return FALSE;
  }
#endif //!LOOOSING_RPM
  file_size = dict.tellg();
  if (!dict.seekg(0L)) {
    cerr << "Seek on dictionary file failed. File is "
         << dict_file_name << "\n";
    return FALSE;
  }

  // read and verify signature
  if (!(dict.read((char *)&sig_arc, sizeof(sig_arc)))) {
    cerr << "Cannot read dictionary file " << dict_file_name << "\n";
    return(FALSE);
  }
  if (strncmp(sig_arc.sig, "\\FST", 4)) {
    cerr << "Invalid dictionary file (bad magic number): " << dict_file_name
	 << endl;
    return(FALSE);
  }
  if (sig_arc.ver != version) {
    cerr << "Invalid dictionary version in file: " << dict_file_name << endl
	 << "Version number is " << int(sig_arc.ver)
	 << ", which indicates that the dictionary was built:" << endl;
    switch (sig_arc.ver) {
    case 0:
      cerr << "without FLEXIBLE, "
	   << "without STOPBIT, without NEXTBIT" << endl;
      break;
    case 1:
      cerr << "with FLEXIBLE, "
	   << "without STOPBIT, without NEXTBIT" << endl;
      break;
    case 2:
      cerr << "with FLEXIBLE, "
	   << "with STOPBIT, without NEXTBIT" << endl;
      break;
    case 3:
      cerr << "with FLEXIBLE, "
	   << "with STOPBIT, with NEXTBIT" << endl;
      break;
    default:
      cerr << "with yet unknown compile options (upgrade your software)"
	   << endl;
    }
    return FALSE;
  }
  FILLER = sig_arc.filler;
  annot_sep = sig_arc.annot_sep;
#ifdef FLEXIBLE
  gtl = sig_arc.gtl & 0x0f;
  new_fsa.gtl = gtl;
  new_fsa.size = gtl + GOTO_OFFSET;
#ifndef STOPBIT
  ctl = (sig_arc.gtl >> 4) & 0x0f;
#endif //STOPBIT
#ifdef NUMBERS
  new_fsa.entryl = (sig_arc.gtl >> 4) & 0x0f;
  new_fsa.aunit = (new_fsa.entryl ? 1 : new_fsa.size);
#endif //NUMBERS
#endif //FLEXIBLE

  // allocate memory and read the transducer
#ifdef FLEXIBLE
  arc_size = 1;		// in reality: 2 + ctl + gtl, but tr_arc_ptr is char*
#else
  arc_size = sizeof(dummy);
#endif
  no_of_arcs = ((long)file_size - sizeof(sig_arc)) / arc_size;
#ifdef FLEXIBLE
  new_fsa = new char[no_of_arcs];
#else
  new_fsa = new tr_arc[no_of_arcs];
#endif
#ifdef	DEBUG
  cerr << "No of arcs to read is " << no_of_arcs << ", filesize is "
       << file_size << ", filepos is " << dict.tellg() 
       << ", arc is " << (sizeof dummy) << "\n";
#endif
#if defined(FLEXIBLE)
  if (!(dict.read((char *)new_fsa.arc, no_of_arcs * arc_size))) {
#else
  if (!(dict.read((char *)new_fsa, no_of_arcs * arc_size))) {
#endif
    cerr << "Cannot read dictionary file " << dict_file_name << "\n";
    return(FALSE);
  }

#ifdef	DEBUG
  for (int i = 0; i < no_of_arcs; i++)
    cerr << i << " letters: " << new_fsa[i].surf_letter << "/"
         << new_fsa[i].lex_letter << ", go_to: " 
         << new_fsa[i].go_to
         << ", children: " << new_fsa[i].children() << ", final: "
	   << new_fsa[i].is_final()
	 << ", surface final: " << new_fsa[i].surf_is_final() << "\n";
#endif
  // put the transducer on the list of dictionaries
  dd.filler = FILLER;
  dd.annot_sep = annot_sep;
#ifdef FLEXIBLE
  dd.gtl = gtl;
#ifndef STOPBIT
  dd.ctl = ctl;
#endif //STOPBIT
#ifdef NUMBERS
  dd.entryl = new_fsa.entryl;
#endif //NUMBERS
#endif //FLEXIBLE
  dd.no_of_arcs = no_of_arcs;
  dd.dict = new_fsa;
  dictionary.insert(&dd);
  return TRUE;
}//tr::read_fsa



/* Name:	word_in_dictionary
 * Class:	tr
 * Purpose:	Find if a word is in a dictionary (transducer).
 * Parameters:	word	- (i) word to check;
 *		start	- (i) look at children of that node
 * Returns:	TRUE if word found, FALSE otherwise.
 * Remarks:	None.
 */
int
tr::word_in_dictionary(const char *word, tr_arc_ptr start)
{
  tr_arc_ptr	next_node = tr_next_node(current_dict, start);
  //  int kids = tr_get_children(start);

  //  for (int i = 0; i < kids; i++, tr_inc_next(next_node)) {
  forallnodes(i) {
    if (*word == tr_get_surf(next_node)) {
      if (word[1] == '\0' && tr_get_surf_final(next_node))
	return TRUE;
      else if (word_in_dictionary(word + 1, next_node))
	return TRUE;
    }
    else if (tr_get_surf(next_node) == FILLER) {
      if (word_in_dictionary(word, next_node))
	return TRUE;
    }
  }
  return FALSE;
}//tr::word_in_dictionary

/* Name:        word_in_dictionaries
 * Class:       tr
 * Purpose:     Searches for the word in all dictionaries (transducers).
 * Parameters:  word    - (i) word to be checked.
 * Returns:     TRUE if the word is in the dictionaries, FALSE otherwise.
 * Remarks:     I don't know why it was not present here before.
 */
int
tr::word_in_dictionaries(const char *word)
{
  dict_list             *dict;

  dictionary.reset();
  for (dict = &dictionary; dict->item(); dict->next()) {
    set_dictionary(dict->item());
    if (word_in_dictionary(word, tr_first_node(current_dict)))
      return TRUE;
#ifdef CASECONV
    else if (word_syntax[(unsigned char)*word] == 2) {
      // word is uppercase - try lowercase
      *((char *)word) = casetab[(unsigned char)*word];
      if (word_in_dictionary(word, tr_first_node(current_dict)))
        return TRUE;
      *((char *)word) = casetab[(unsigned char)*word];
    }
#endif
  }
  return FALSE;
}//tr::word_in_dictionaries

/* Name:        set_dictionary
 * Class:       tr
 * Purpose:     Sets variables associated with the current dictionary
 * Parameters:  dict    - (i) current dictionary description.
 * Returns:     Nothing.
 * Remarks:     None.
 */
void
tr::set_dictionary(dict_desc *dict)
{
#ifdef FLEXIBLE
  tr_arc_ptr   dummy(NULL);
#endif

#ifdef FLEXIBLE
  current_dict = dict->dict.arc;
#else
  current_dict = (const char *)(dict->dict);
#endif
  FILLER = dict->filler;
#ifdef FLEXIBLE
#ifdef STOPBIT
  dummy.gtl = dict->gtl;
  dummy.size = dummy.gtl + GOTO_OFFSET;
#ifdef NUMBERS
  dummy.entryl = dict->entryl;
  dummy.aunit = dummy.entryl ? 1 : (goto_offset + dummy.gtl);
#endif
#ifdef NEXTBIT
  dummy.curr_dictionary = current_dict;
#endif //NEXTBIT
#else //!STOPBIT
  dummy.gtl = dict->gtl;
  dummy.ctl = dict->ctl;
  dummy.size = 2 + dummy.gtl + dummy.ctl;
#endif //!STOPBIT
#endif //FLEXIBLE
}//fsa::set_dictionary


/***	EOF commont.cc	***/
