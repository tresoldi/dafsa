/***	build_tr.cc	***/

/*
Copyright (c) Jan Daciuk, 1996

You can find links to various sources describing the algorithms used here
at http://www.pg.gda.pl/~jandac/fsa.html

*/


#include	<iostream>
#include	<stddef.h>
#include	<string.h>
#include	<stdlib.h>
#include	"tr.h"
#include	"tnode.h"
#include	"nstr.h"
#include	"build_tr.h"
#include	"tindex.h"
#include	"tr_inp.h"

extern char	FILLER;
extern char	ANNOT_SEPARATOR;

#ifdef FLEXIBLE
int tnode::max_arcs_per_node = 0;
#endif

/*	internal prototypes	*/

int
find_common_prefix(tnode *start_node, const char *surf_word,
		   const char *lex_word, prefix *common_prefix,
		   const int length);
inline int
comp_pair(int s1, int s2, int l1, int l2);

inline int
comp_pair(int s1, int s2, int l1, int l2)
{
  register int	c;

  if ((c = s1 - s2) == 0)
    return (l1 - l2);
  else
    return c;
}//comp_pair

/* Name:	mark_inner
 * Class:	None.
 * Purpose:	Mark nodes with a specified value of arc_no.
 * Parameters:	n	- (i) node to be marked;
 *		no	- (i) arc_no for that node.
 * Returns:	n - the node to be marked.
 * Remarks:	It is assumed that node with arc_no = no are already marked.
 */
tnode *
mark_inner(tnode *n, const int no)
{
  if (n->get_arc_no() == no)
    return n;

  n->set_arc_no(no);
  arc_node *an = n->get_children();
  for (int i = 0; i < n->get_no_of_kids(); i++, an++)
    if (an->child)
      mark_inner(an->child, no);
  return n;
}

/* Name:	find_common_prefix
 * Class:	None.
 * Purpose:	Find how many letters of the word just read are already in
 *		the transducer. Find the node that contains the last letter.
 * Parameter:	start_node	- (i) where to start in the transducer;
 *		word		- (i) word whose common prefix is sought;
 *		common_prefix	- (o) information about the prefix;
 *		length		- (i) how many characters of word were
 *					already considered.
 * Returns:	common_prefix length.
 * Remarks:	I had to add `length' parameter, because that was the only
 *		way to avoid using a global variable (I hate doing that).
 *
 *		There are length + 1 nodes in `path'.
 *
 *		Because there is no NULL final node, there are two cases:
 *		1) the final letter of the prefix is on the arc leading
 *			to another node,
 *		2) the final letter of the prefix is on the arc with
 *			a NULL link (a link to a global end state).
 *		The path is one node shorter in the first case.
 */
int
find_common_prefix(tnode *start_node,
		   const char *surf_word,
		   const char *lex_word,
		   prefix *common_prefix,
		   const int length)
{
  arc_node	*offspr;
  char		surf, lex;
  int		l;
  int		c;
  int		i;

  common_prefix->first = 0;
  common_prefix->already_there = FALSE;
  common_prefix->path[length] = start_node;

  surf = (*surf_word ? *surf_word : FILLER);
  lex = (*lex_word ? *lex_word : FILLER);
  offspr = start_node->get_children();
  for (i = 0; i < start_node->get_no_of_kids(); i++, offspr++) {

//    if (offspr->fin_status == -1)
//      cerr << "fin_status error\n";

    if ((c = comp_pair(offspr->surf_letter, surf, offspr->lex_letter, lex))
	< 0)
      // if offspring preceeds given pair
      continue;
    else {
      if (c == 0) {
	// the ith arc is labelled with the appropriate surf/lex pair
	common_prefix->arc_no[length] = i;	// remember arc no


	if (offspr->child) {
	  // There are further nodes: search for them
	  l = find_common_prefix(offspr->child,
				 *surf_word ? surf_word + 1 : surf_word,
				 *lex_word ? lex_word + 1 : lex_word,
				 common_prefix,
				 length + 1);

	  /* Everything beneath (in offspr->child condition) is executed
	     _after_ further nodes are examined, so everything set here
	     will be honored if it is not modified for nodes _earlier_
	     in the path
	     */
	  if (start_node->get_hit_count() > 1)
	    common_prefix->first = length;	// first node pointed to
	                                        // by two or more nodes

	  if (l == length + 1 && offspr->get_is_final() &&
	      (!((*surf_word && surf_word[1]) || 
	       (*lex_word && lex_word[1])))) {
	    // the arc from start node to offspr->child is final
	    // and it corresponds to the last character pair of prefix
	    common_prefix->already_there = TRUE;
	  }
	  return l;	// return prefix path length

	}//if arc has a non-NULL link
	else {
	  // the last character pair of prefix sits on a node with NULL link
	  // all NULL links are final
	  if (!((*surf_word && surf_word[1]) || (*lex_word && lex_word[1]))) {
	    // this is the final letter pair of the prefix
	    common_prefix->already_there = TRUE;
	  }
	}//if arc with a NULL link
      }
      break;	// no further arcs to be considered
    }
  }//for

  // we get here only when start_node is the last node in common prefix path
  common_prefix->arc_no[length] = i;	// this is the place where the arc
                                        // should be inserted
  if (start_node->get_hit_count() > 1)
    common_prefix->first = length;
  return common_prefix->length = length;
}//find_common_prefix


/* Name:	build_fsa
 * Class:	transducer
 * Purpose:	Reads a list of sorted words and builds a final state
 *		transducer that recognizes them.
 * Parameters:	infile	- (i) file to be read.
 * Returns:	TRUE if transducer built, FALSE otherwise.
 * Remarks:	There is a room for improvements here.
 */
int
transducer::build_fsa(istream &infile)
{
  char		*lex_word, *surf_word;
  char		*lex_rest, *surf_rest;
  prefix	common_prefix;
  tnode		*new_node;
  tnode		*next_node;
  tnode		*prev_node;
  int		node_modified = TRUE;
  transd_inp	input_line;
  int		i, l;
  int		total_len;
  int		hc;
  char		null_string[1] = {0};

  while (infile >> input_line) {
    lex_word = input_line.get_lex_word();
    surf_word = input_line.get_surf_word();
//    cerr << surf_word << " / " << lex_word << "\n";
    if (*lex_word == '\0' || *surf_word == '\0')
      continue;

    l = find_common_prefix(root, surf_word, lex_word, &common_prefix, 0);
    if (common_prefix.already_there) {
      continue;
    }

    // the rest is word - common_prefix
    surf_rest = input_line.surf_len() >= l ? surf_word + l : null_string;
    lex_rest = input_line.lex_len() >= l ? lex_word + l : null_string;
    total_len = (input_line.surf_len() >= input_line.lex_len() ?
		 input_line.surf_len() : input_line.lex_len());

    if (common_prefix.first) {
      // There is a node in the common prefix path that has hit count
      // greater than one, i.e. it is pointed to by more than one node.
      // Since modifying anything in the common prefix path after
      // that node means also modifying other parts of the transducer,
      // a copy of all nodes in the common prefix path from that node
      // must be created.

      new_node = new tnode(common_prefix.path[common_prefix.length]);
      prev_node = next_node = new_node;

      // If the rest of word pair (after prefix) exists make a chain of nodes
      // with its consecutive letters, and attach it to the last node
      // found in prefix.
      if (*surf_rest || *lex_rest) {
	new_node = next_node->add_postfix(surf_rest, lex_rest);
	// Because add_suffix() may have introduced new reentrant states
	// earlier in the common prefix path, rescan the common prefix path
	for (int j = common_prefix.first - 1; j > 0; --j) {
	  if (common_prefix.path[j]->get_hit_count() > 1) {
	    common_prefix.first = j;
	  }
	}
      }

      for (i = common_prefix.length-1; i >= common_prefix.first; --i) {
	// comp_or_reg should take care of hit_count as well
	// note that next_node is not registered yet,
	// as it is only a copy, and its hit count is 0
	new_node = comp_or_reg(next_node);
	next_node = new_node;

	// create a new node
	prev_node = new tnode(common_prefix.path[i]);

	// attach `next_node' to it
	// note that this is a copy of an existing node, so there is no need
	// to unregister it
	mod_child(prev_node, next_node, common_prefix.arc_no[i],
		  i == input_line.surf_len() - 1, i == total_len - 1);
	next_node = prev_node;
      }//for

      // Modify the first node with hit_count > 1
      // note that now i = common_prefix.first - 1
      prev_node = common_prefix.path[i];
      new_node = comp_or_reg(next_node);
      next_node = new_node;
      // the node will always be modified here
      node_modified = TRUE;
      if (i) {
	// root is never registered
	unregister(prev_node);
	prev_node->hit_node(-1); // comp_or_reg will increase it again
      }
      mod_child(prev_node, next_node, common_prefix.arc_no[i],
		i == input_line.surf_len() - 1, i == total_len - 1);
      next_node = prev_node;

      // now the first confluence (reentrant) state is modified,
      // the node immediately preceding it - is not (yet),
      // i.e. it will need mod_child to redirect the arc,
      // and the previous node is not unregistered yet,
      // and it must be unregistered (unless it is the root)
    }//if path contains a node pointed to more than once
    else {
      // This is probably an early stage in the building process.
      // There is no node in the common prefix path with hit_count
      // greater than 1, i.e. a node that is pointed to by more than
      // one node.
      // This means that there is no need to create any copies of nodes.

      // REMEMBER!!! comp_or_reg changed completely!!!
      i = common_prefix.length;
      next_node = prev_node = common_prefix.path[i];
      node_modified = TRUE;
      if (*surf_rest || *lex_rest) {
	if (i) { // This may be root!
	  unregister(prev_node);
	  prev_node->hit_node(-1); // comp_or_reg will increase it again
	}
	// If the rest of word (after prefix) exists make a chain of nodes
	// with its consecutive letters, and attach it to the last node
	// found in prefix.
	next_node = prev_node->add_postfix(surf_rest, lex_rest);
      }//if there if a postfix to add
      else {
	// there is nothing to add, but we may have to modify
	// the final attribute of an arc, so node_modified = TRUE
	--i;
	prev_node = common_prefix.path[i];
	if (i) {
	  unregister(prev_node);
	}
	mod_child(prev_node, next_node, common_prefix.arc_no[i],
		  i == input_line.surf_len() - 1, i == total_len - 1);
      }
    }
      

    // However, nodes in the path are already registered, so those
    // of them that are modified should be withdrawn from the register
    // and reregistered. In principle, this applies to the last node
    // in the common prefix path. However, by changing that node, a node
    // that is isomorphic to an already registered one can be created,
    // which implies replacement rather than registering, which in turn
    // forces a change in the preceeding node, and so on.
    // This also affects the nodes before the first node pointed to
    // from outside.
    // Life is brutal.
    while (--i > 0 && node_modified) {
      next_node = prev_node;
      prev_node = common_prefix.path[i];
      hc = next_node->get_hit_count();
      new_node = comp_or_reg(next_node);
      if ((node_modified = (new_node != next_node))) {
	next_node = new_node;
	unregister(prev_node);
	prev_node->hit_node(-1); // comp_or_reg should restore it
      }
      if (node_modified && hc == 0) {
	// we deleted the child of prev_node, so we must prevent
	// that mod_child deletes it once more
	prev_node->get_children()[common_prefix.arc_no[i]].child = NULL;
      }
      mod_child(prev_node, next_node, common_prefix.arc_no[i],
		i == input_line.surf_len() - 1, i == total_len - 1);
    }

    // Now we may need to modify root
    if (node_modified && i==0) {
      next_node = prev_node;
      prev_node = common_prefix.path[i];
      hc = next_node->get_hit_count();
      new_node = comp_or_reg(next_node);
      if (new_node != next_node && hc == 0) {
	// we deleted the child of prev_node, so we must prevent
	// that mod_child deletes it once more
	prev_node->get_children()[common_prefix.arc_no[i]].child = NULL;
      }
      mod_child(prev_node, new_node, common_prefix.arc_no[i],
		i == input_line.surf_len() - 1, i == total_len - 1);
    }
#ifdef DEBUG
    show_index(0);
#endif
  }//while


  return TRUE;
}//build_fsa

/* Name:	write_fsa
 * Class:	transducer
 * Purpose:	Writes the transducer in a binary form.
 * Parameters:	outfile	- (o) file to be written.
 * Returns:	TRUE if transducer written, FALSE otherwise.
 * Remarks:	Arcs must first be numbered in correct order.
 *		Arc number 0 represents the first arc of a node
 *		with no children :-). This makes it possible to use
 *		index 0 as a NULL pointer in a table of arcs.
 */
int
transducer::write_fsa(ostream &outfile)
{
#ifndef FLEXIBLE
  tr_arc	output_arc;
#endif
  tnode		*meta_root;
  int		result;
  tr_signature	sig_arc;
#ifdef FLEXIBLE
  char		bytes[16];	/* output buffer for transducer's arc */
  tr_arc_ptr	*dummy;
  int		gtl_calculated = FALSE;
#if defined(STOPBIT) && defined(NEXTBIT)
  int		gtl;
#endif //STOPBIT,NEXTBIT
#endif //FLEXIBLE

  meta_root = new tnode;
  meta_root->add_child('^', FILLER, root, FALSE);
  meta_root->hit_node();
  root->hit_node();		// to "register" it

#ifdef PROGRESS
  cerr << "Counting arcs" << endl;
#endif
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
  meta_root->number_arcs(0);	// only count arcs
  // we need to calculate gtl first, as it is used in numbering arcs
  gtl = 1;
  for (int r = meta_root->no_of_arcs;
       (r * (GOTO_OFFSET + gtl) - meta_root->next_nodes * (gtl - 1))
	 >> ((8 * gtl) - GOTO_SHIFT); ) {
    gtl++;
  }
  dummy->gtl = sig_arc.gtl = gtl;
  dummy->size = gtl + GOTO_OFFSET;
  mark_inner(root, -1);		// pretend arcs were not numbered
				// otherwise number_arcs() would not work again
  root->no_of_arcs = GOTO_OFFSET + gtl
#ifdef NUMBERS
    + dummy->entryl
#endif
    ;
  gtl_calculated = TRUE;
#ifdef NUMBERS
  sig_arc.gtl |= (dummy->entryl << 4);
#endif //NUMBERS
#if defined(STATISTICS ) && defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
  meta_root->print_statistics(meta_root);
#endif
  meta_root->number_arcs(gtl);	// assign addresses to nodes
#else //!(FLEXIBLE,STOPBIT,NEXTBIT)
  meta_root->number_arcs();
#endif //FLEXIBLE,STOPBIT,NEXTBIT
#if defined(STATISTICS) && !(defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT))
  meta_root->print_statistics(meta_root);
#endif //STATISTICS,!(FLEXIBLE,STOPBIT,NEXTBIT)*/
  // write signature (magic number)
  sig_arc.sig[0] = '\\';
  sig_arc.sig[1] = 'F';
  sig_arc.sig[2] = 'S';
  sig_arc.sig[3] = 'T';
#ifdef FLEXIBLE
#ifdef STOPBIT
#ifdef NEXTBIT
  sig_arc.ver = 3;
#else //!NEXTBIT
  sig_arc.ver = 2;
#endif //!NEXTBIT
#else //!STOPBIT
  sig_arc.ver = 1;
#endif //!STOPBIT
#else //!FLEXIBLE
  sig_arc.ver = 0;
#endif //!FLEXIBLE
  sig_arc.filler = FILLER;
  sig_arc.annot_sep = ANNOT_SEPARATOR;
#ifdef FLEXIBLE
  if (!gtl_calculated) {
    sig_arc.gtl = 0;
#ifdef STOPBIT
    for (int r = (meta_root->get_no_of_arcs() << GOTO_SHIFT); r; r >>= 8)
      sig_arc.gtl++;
    dummy->gtl = sig_arc.gtl;
    dummy->size = GOTO_OFFSET + dummy->gtl;
#ifdef NUMBERS
    sig_arc.gtl |= (dummy->entryl << 4);
#endif
#else //!STOPBIT
    /* The extra 2 below account for final and surface final bits */
    for (int r = (meta_root->get_no_of_arcs() << 2); r; r >>= 8)
      sig_arc.gtl++;
    for (int rr = meta_root->get_max_arcs_per_node(); rr; rr >>= 8)
      sig_arc.gtl += 16;
    dummy->gtl = sig_arc.gtl & 0x0f;
    dummy->ctl = (sig_arc.gtl >> 4) & 0x0f;
    dummy->size = dummy->gtl + dummy->ctl + 2;
#endif //!STOPBIT
  }//if !gtl_calculated
#endif //FLEXIBLE
#ifdef PROGRESS
  cerr << "Writing arcs" << endl;
#endif
  if (!(outfile.write((char *)&sig_arc, sizeof sig_arc)))
    return FALSE;
  // sink node
#ifdef FLEXIBLE
  for (int i = 0; i < dummy->size; i++)
    bytes[i] = 0;
  if (!(outfile.write(bytes, dummy->size)))
    return FALSE;
#else
  output_arc.go_to = 0;
  output_arc.surf_letter = 0;
  output_arc.lex_letter = 0;
  output_arc.counter = 0;
  if (!(outfile.write((char *)&output_arc, sizeof output_arc)))
    return FALSE;
#endif
  result = meta_root->write_arcs(outfile);
  delete meta_root;
  return result;
}//transducer::write_fsa

/***	EOF build_tr.cc	***/

