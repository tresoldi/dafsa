/***	prefixt.cc	***/

/*	Copyright (c) Jan Daciuk, 1997	*/


#include	<iostream>
#include	<fstream>
#include	<string.h>
#include	<stdlib.h>
#include	<new>
#include	"tr.h"
#include	"nstr.h"
#include	"commont.h"
#include	"prefixt.h"




/* Name:	prefix_tr
 * Class:	prefix_tr (constructor).
 * Purpose:	Open dictionary files and read automata from them.
 * Parameters:	dict_names	- (i) dictionary file names;
 *		distance	- (i) max edit distance of replacements.
 * Returns:	Nothing.
 * Remarks:	At least one dictionary file must be read.
 */
prefix_tr::prefix_tr(word_list *dict_names)
: tr(dict_names)
{
}//prefix_tr::prefix_tr



/* Name:	complete_file_words
 * Class:	prefix_tr
 * Purpose:	Provide a list of all possible completions of words in a file.
 * Parameters:	io_obj		- (i/o) where to read words, and where
 *					to print them.
 * Returns:	Exit code.
 * Remarks:	The format of output is:
 *		surface_form WORD_SEP lexical_form
 *		where lexical form contains annotations.
 */
int
prefix_tr::complete_file_words(tr_io &io_obj)
{
  char		word_buffer[Max_word_len];
  char		*word = &word_buffer[0];

  while (io_obj >> word) {
    if (!complete_prefix(word, io_obj))
      io_obj.print_not_found();
  }
  return state;
}//prefix_tr::complete_file_words


/* Name:	complete_prefix
 * Class:	prefix_tr
 * Purpose:	Finds all words that begin with a given prefix
 *		in all dictionaries.
 * Parameters:	word_prefix	- (i) prefix of the word;
 *		io_obj		- (o) where to print results.
 * Returns:	Number of completions found.
 * Remarks:	Empty prefix ("") lists contents of all transducers.
 */
int
prefix_tr::complete_prefix(const char *word_prefix, tr_io &io_obj)
{
  dict_list	*dict;
  int		compl_found = 0;

  dictionary.reset();
  for (dict = &dictionary; dict->item(); dict->next()) {
    set_dictionary(dict->item());
    compl_found += compl_prefix(word_prefix, io_obj, 0, 0,
				tr_first_node(current_dict));
  }
  return compl_found;
}//prefix_tr::complete_prefix


/* Name:	compl_prefix
 * Class:	prefix_tr
 * Purpose:	Provides all possible completions of a given prefix in the
 *		current transducer.
 * Parameters:	word_prefix	- (i) prefix to find;
 *		io_obj		- (o) where to print results;
 *		s_depth		- (i) length of surface prefix already found;
 *		l_depth		- (i) length of lexical prefix already found;
 *		start		- (i) look at children of that node.
 * Returns:	Number of completions found.
 * Remarks:	None.
 */
int
prefix_tr::compl_prefix(const char *word_prefix, tr_io &io_obj,
			const int s_depth,
			const int l_depth, tr_arc_ptr start)
{
  tr_arc_ptr	next_node = tr_next_node(current_dict, start);
  int		curr_s_depth, curr_l_depth;
  int		compl_found = 0;
  //  int		kids = tr_get_children(start);

  if (tr_get_goto(start) == 0)
    return 0;

  if (*word_prefix == '\0')
    compl_found += compl_rest(io_obj, s_depth, l_depth, start);

  //  for (int i = 0; i < kids; i++, tr_inc_next(next_node)) {
  forallnodes(i) {
    curr_s_depth = s_depth; curr_l_depth = l_depth;
    candidate[curr_s_depth + 1] = '\0';
    lex_cand[curr_l_depth + 1] = '\0';
    if (*word_prefix == tr_get_surf(next_node)) {
#ifndef SHOW_FILLERS
      if (tr_get_lex(next_node) != FILLER)
#endif
	lex_cand[curr_l_depth++] = tr_get_lex(next_node);
#ifndef SHOW_FILLERS
      if (tr_get_surf(next_node) != FILLER)
#endif
	candidate[curr_s_depth++] = tr_get_surf(next_node);
      if (word_prefix[1] == '\0') {
	if (tr_get_final(next_node)) {
	  char *n = new char [curr_s_depth + curr_l_depth + 2];
	  strcpy(n, candidate);
	  n[curr_s_depth] = WORD_SEP;
	  strcpy(n + curr_s_depth + 1, lex_cand);
	  replacements.insert(n);
	  delete [] n;
	  io_obj.print_repls(&replacements);
	  replacements.empty_list();
	  compl_found++;
	}
	compl_found += compl_rest(io_obj, curr_s_depth, curr_l_depth,
				  next_node);
      }
      else
	compl_found += compl_prefix(word_prefix + 1, io_obj, curr_s_depth,
				    curr_l_depth, next_node);
    }
    else if (tr_get_surf(next_node) == FILLER) {
#ifndef SHOW_FILLER
      if (tr_get_lex(next_node) != FILLER)
#endif
	lex_cand[curr_l_depth++] = tr_get_lex(next_node);
      compl_found += compl_prefix(word_prefix, io_obj, curr_s_depth,
				  curr_l_depth, next_node);
    }
  }
  return compl_found;
}//prefix_tr::compl_prefix


/* Name:	compl_rest
 * Class:	prefix_tr
 * Purpose:	Finds all completions of a given prefix.
 * Parameters:	s_depth		- (i) number of characters already in surface
 *					form;
 *		l_depth		- (i) number of characters already in lexical
 *					form;
 *		start		- (i) look at children of that node.
 * Returns:	Number of completions found.
 * Remarks:	This is invoked from comp_prefix, when prefix has been found.
 */
int
prefix_tr::compl_rest(tr_io &io_obj, const int s_depth, const int l_depth,
		tr_arc_ptr start)
{
  tr_arc_ptr	next_node = tr_next_node(current_dict, start);
  int		curr_s_depth;
  int		curr_l_depth;
  int		compl_found = 0;
  //  int		kids = tr_get_children(start);

  if (tr_get_goto(start) == 0)
    return 0;

  //  for (int i = 0; i < kids; i++, tr_inc_next(next_node)) {
  forallnodes(i) {
    curr_s_depth = s_depth;
    curr_l_depth = l_depth;
    if (tr_get_surf(next_node) != FILLER)
      candidate[curr_s_depth++] = tr_get_surf(next_node);
#ifndef SHOW_FILLER
    if (tr_get_lex(next_node) != FILLER)
#endif
      lex_cand[curr_l_depth++] = tr_get_lex(next_node);
    candidate[curr_s_depth] = '\0';
    lex_cand[curr_l_depth] = '\0';
    if (tr_get_final(next_node)) {
      char *n = new char[curr_s_depth + curr_l_depth + 2];
      strcpy(n, candidate);
      n[curr_s_depth] = WORD_SEP;
      strcpy(n + curr_s_depth + 1, lex_cand);
      replacements.insert(n);
      delete [] n;
      io_obj.print_repls(&replacements);
      replacements.empty_list();
      compl_found++;
    }
    compl_found += compl_rest(io_obj, curr_s_depth, curr_l_depth, next_node);
  }
  return compl_found;
}//prefix_tr::compl_rest


/***	EOF prefixt.cc	***/
