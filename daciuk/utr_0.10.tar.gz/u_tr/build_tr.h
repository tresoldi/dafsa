/***	build_tr.h	***/

/*	Copyright (C) Jan Daciuk, 1996	*/

#ifndef		BUILD_TR_H
#define		BUILD_TR_H

#ifndef		TNODE_H
#include	"tnode.h"
#endif

/* Class name:	transducer
 * Purpose:	Provide methods and common variables for building a transducer.
 * Methods:	transducer	- initiates roots of tranducer and index;
 *		get_root	- returns root node of the transducer;
 *		build_fsa	- build the transducer;
 *		write_fsa	- writes the transducer to a file;
 *		correct_surf_final
 *				- corrects improper arc attribute.
 * Variables:	root		- root of the transducer.
 */
class transducer {
private:
  tnode		*root;
public:
  transducer(void) { root = new tnode(); }
  ~transducer(void) { delete root; }
  tnode *get_root() const { return root; }
  int build_fsa(istream &infile);
  int write_fsa(ostream &out_file);
  void correct_surf_final(prefix *common_prefix, const int s_len);
};/* transducer */



#endif

/***	EOF build_tr.h	***/
