/***	tdump.cc	***/

/*
  A utility for printing the contents of an automaton.
  In contrast to fsa_prefix, this program prints information
  about nodes and arcs, and their constituents.
*/

#include	<iostream.h>
#include	<fstream.h>
#include	<string.h>
#include	<new.h>

#define		TRUE	1
#define		FALSE	0

const char	UNCHAR	= '?';
int		global_gtl;

struct signature {		/* dictionary file signature */
  char          sig[4];         /* automaton identifier (magic number) */
  char          ver;            /* automaton type number */
  char          filler;         /* char used as filler */
  char          annot_sep;      /* char that separates annotations from lex */
  char          gtl;            /* length of go_to field */
};/*struct signature */

/* Name:	bytes2int
 * Class:	None.
 * Purpose:	Convert a sequence of bytes to integer.
 * Parameters:	bytes	- (i) sequence of bytes,
 *		n	- (i) length of the sequence.
 * Returns:	Equivalent integer.
 * Remarks:	Needed for portability of automata.
 */
inline unsigned int
bytes2int(const unsigned char *bytes, const int n)
{
  unsigned int r = 0;
  int i;
  for (i = n - 1; i >= 0; --i) {
    r <<= 8; r |= bytes[i];
  }
  return r;
}

/* Name:	usage
 * Class:	None.
 * Purpose:	Explains invocation syntax.
 * Parameters:	name	- (i) program name.
 * Returns:	Nothing.
 * Remarks:	The description is sent to standard error.
 */
static void
usage(const char *name)
{
  cerr << name << " prints contents of an automaton arc-wise" << endl
       << "Synopsis: " << name << "[<automaton] [>output_file]" << endl
       << "Normally the automaton should be on standard input" << endl;
}

/* Name:	print_sig
 * Class:	None.
 * Parameters:	inp		- (i) input stream,
 *		dict_file_name	- (i) name of input file.
 * Returns:	Version number of the automaton.
 * Remarks:	None.
 */
int
print_sig(ifstream &inp, const char *dict_file_name)
{
  signature	sig_arc;
  unsigned int	tmp;

  if (!inp.read((char *)&sig_arc, sizeof(sig_arc))) {
    cerr << "Cannot read signature" << endl;
    exit(1);
  }
  if (strncmp(sig_arc.sig, "\\FST", (size_t)4)) {
    cerr << "Invalid dictionary file (bad magic number): " << dict_file_name
      << endl;
    return(FALSE);
  }
  tmp = sig_arc.ver;
  cout << "Automaton version: " << dec << tmp << endl;
  cout << "Dictionary was build:" << endl;
  switch (sig_arc.ver) {
  case 0:
    cout << "without FLEXIBLE," << endl 
	 << "without STOPBIT," << endl << "without NEXTBIT" << endl;
    cout << "Version not supported by the tool. Exiting." << endl;
    exit(4);
    break;
  case 1:
    cout << "with FLEXIBLE," << endl
	 << "without STOPBIT," << "without NEXTBIT," << endl;
    cout << "Version not supported by the tool. Exiting." << endl;
    exit(4);
    break;
  case 2:
    cout << "with FLEXIBLE," << endl << "without LARGE_DICTIONARIES," << endl
	 << "with STOPBIT," << "without NEXTBIT," << endl;
    break;
  case 3:
    cout << "with FLEXIBLE," << endl
	 << "with STOPBIT," << endl << "with NEXTBIT," << endl;
    break;
  default:
    cout << "with yet unknown compile options (upgrade your software)"
	 << endl;
    exit(3);
  }
  cout << "Filler is `" << sig_arc.filler << "'" << endl
       << "Annotation separator is `" << sig_arc.annot_sep << "'" << endl;
  global_gtl = (unsigned char)(sig_arc.gtl);
  cout << "Goto length is: " <<  (global_gtl & 0x0f) << endl;
  if (global_gtl & 0xf0) {
    cout << "Entry length is: " << (global_gtl >> 4) << endl;
  }
  return sig_arc.ver;
}

/* Name:	print_arcs
 * Class:	None.
 * Purpose:	Prints arcs of the automaton.
 * Parameters:	inp	- (i) input stream,
 *		ver	- (i) automaton version,
 *		fsize	- (i) automaton file size,
 *		gtl	- (i) length of the goto field,
 *		entryl	- (i) length of the perfect hasing counter.
 * Returns:	Nothing.
 * Remarks:	None.
 */
void
print_arcs(ifstream &inp, const int ver, const long fsize)
{
  unsigned int tmp;
  int autom_size = fsize - 8;
  int flags_shift[] = {0, 2, 3, 4};
  int gtl = global_gtl & 0xf;
  int entryl = (global_gtl >> 4) & 0xf;
  int stopf, nextf, tailf, finf, surff, curr_loc; // flags
  unsigned int gotof;		// goto field
  const char *dict = new char[autom_size];
  
  // Read the automaton
  if (!(inp.read((char *)dict, autom_size))) {
    cerr << "Cannot read dictionary file";
    exit(2);
  }
  for (int curr_loc = 0; curr_loc < autom_size; ) {
    if (curr_loc < (2 * (2 + gtl)))
      stopf = 1;		// sink node and meta_root

    // Handle numbers
    if (entryl && stopf) {
      int hash_count = bytes2int((const unsigned char *)dict + curr_loc,
				 entryl);
      for (int j = 0; j < entryl - 1; j++) {
	tmp = dict[curr_loc];
	cout << "[ " << dec << curr_loc << "] " << hex << tmp << endl;
	curr_loc++;
      }
      tmp = dict[curr_loc];
      cout << "[" << dec << curr_loc << "] " << hex << tmp << " #v:"
	   << dec << hash_count << endl;
      curr_loc++;
    }

    // Process transitions
    // Version compiled with STOPBIT; surface label is first
    cout << "[" << dec << curr_loc << "] " << hex
	 << ((dict[curr_loc] >= ' ') ? dict[curr_loc] : UNCHAR)
	 << endl;
    curr_loc++;
    // lexical label is second
    cout << "[" << dec << curr_loc << "] " << hex
	 << ((dict[curr_loc] >= ' ') ? dict[curr_loc] : UNCHAR)
	 << endl;
    curr_loc++;
    gotof = bytes2int((const unsigned char *)dict + curr_loc, gtl)
      >> flags_shift[ver];
    stopf = nextf = finf = tailf = 0;
    if (ver == 3) {
      nextf = ((dict[curr_loc] & 8) != 0);
    }
    stopf = ((dict[curr_loc] & 4) != 0);
    finf = ((dict[curr_loc] & 1) != 0);
    surff = ((dict[curr_loc] & 2) != 0);
    // Print goto field with flags
    if (!nextf) {
      for (int i = 0; i < gtl - 1; i++) {
	tmp = dict[curr_loc] & 0xff;
	cout << "[" << dec << curr_loc << "] " << hex << tmp << endl;
	curr_loc++;
      }
    }
    tmp = dict[curr_loc] & 0xff;
    cout << "[" << dec << curr_loc << "] " << hex << tmp << " -> (";
    if (nextf)
      cout << "*";
    else
      cout << dec << gotof;
    if (tailf)
      cout << ",t";
    if (nextf)
      cout << ",n";
    if (stopf)
      cout << ",s";
    if (surff)
      cout << ",^";
    if (finf)
      cout << ",f";
    cout << ")" << endl;
    curr_loc++;
    if (stopf) {
      cout << "=====" << endl;
    }
    else {
      cout << "-----" << endl;
    }
  }//for all bytes
}//print_arcs

/* Name:	not_enough_memory
 * Class:	None.
 * Purpose:	Inform the user that there is not enough memory to continue
 *		and finish the program.
 * Parameters:	None.
 * Returns:	Nothing.
 * Remarks:	None.
 */
void
not_enough_memory(void)
{
  cerr << "Not enough memory\n";
  exit(5);
}//not_enough_memory


/* Name:	main
 * Class:	None.
 * Purpose:	Run the program.
 * Parameters:	argc	- (i) number of program parameters,
 *		argv	- (i) parameters.
 * Returns:	Exit code.
 * Remarks:	None.
 */
int
main(const int argc, const char *argv[])
{
  const char *dict_file_name;
  set_new_handler(&not_enough_memory);

  // handle options
  if (argc != 2) {
    usage(argv[0]);
    return 7;
  }
  else {
    dict_file_name = argv[1];
  }
  
  
  ifstream dict(dict_file_name, ios::in | ios::nocreate | ios::ate);
  if (dict.bad()) {
    cerr << "Cannot open dictionary file " << dict_file_name << "\n";
    return(FALSE);
  }
  // There is a bug in libstdc++ distributed in rpms.
  // This is a workaround (thanks to Arnaud Adant <arnaud.adant@supelec.fr>
  // for pointing this out).
  if (!dict.seekg(0,ios::end)) {
    cerr << "Seek on dictionary file failed. File is "
         << dict_file_name << "\n";
    return FALSE;
  }
  streampos file_size = dict.tellg();
  if (!dict.seekg(0L)) {
    cerr << "Seek on dictionary file failed." << endl;
    return 6;
  }
  int version = print_sig(dict, dict_file_name);
  print_arcs(dict, version, file_size);
  return 0;
}

/***	EOF tdump.cc	***/
