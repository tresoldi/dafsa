/***	tindex.cc	***/

/* Copyright (C) Jan Daciuk, 1996 */

#include	<ostream>
#include	<iostream>
#include	<stdlib.h>
#include	<stddef.h>
#include	<string.h>
#include	"tr.h"
#include	"tnode.h"
#include	"tindex.h"


static tree_index	primary_index = { {NULL}, 0, 0 };
static tree_index	secondary_index = { {NULL}, 0, 0 };
extern int		frequency_table[256*256];
extern int		frequency_order[256*256];

#ifndef STOPBIT
#ifdef JOIN_PAIRS
const int       PAIR_REG_LEN = 32;
const int	PAIR_CHUNK = 32;

struct packed_tab {
  tnode		**p;		/* addresses of nodes with the same c?? */
  int		counter;	/* number of such nodes */
  int		allocated;	/* how much space for nodes allocated */
  char          c11, c12;	/* surface & lex chars of first arc */
  char          c21, c22;	/* surface & lex chars of second arc */
};/*packed_tab*/

class pair_registery {          /* friend of tnode */
  int           no_of_pairs;	/* no of pairs in packed */
  int		allocated;	/* space allocated for packed */
  packed_tab    *packed;	/* pairs vector */
  int		c11_index[257];	/* where pairs with c11 begin in packed */

public:
  pair_registery(void);         /*      allocate memory */
  ~pair_registery(void);        /*      deallocate memory */
  void reg(tnode *n);           /*      register a node (with a pair of arcs)*/
  void join_arcs(void);         /*      merges arcs */
  void merge_pairs(void);       /*      launch the process */
#ifdef DEBUG
  void print_reg(void);
#endif
};/*pair_registery*/
#endif //JOIN_PAIRS
#endif //!STOPBIT


/* Name:	get_index_by_name
 * Class:	None
 * Purpose:	Delivers appropriate index.
 * Parameters:	index_name	- (i) index number.
 * Returns:	Root of required index.
 * Remarks:	Currently two indices available: PRIM_INDEX and SECOND_INDEX.
 *		No parameter checking.
 */
tree_index *
get_index_by_name(const int index_name)
{
  return (index_name ? &secondary_index : &primary_index);
}//get_index_by_name


/* Name:	register_at_level
 * Class:	None.
 * Purpose:	Looks for an appropriate entry at the given level.
 *		If not found, then creates it.
 * Parameters:	discriminator	- (i) value that should be matched
 *					against `data';
 *		table_node	- (i/o) a node in the table of the upper
 *					level that points to the table
 *					that is to be searched;
 *		to_register	- (i) TRUE means register, otherwise
 *					find and DO NOT REGISTER;
 *		cluster_size	- (i) table size (in entries) at this level.
 * Returns:	A pointer to a table entry (existing previously or
 *		just created) pointing to the next (the lower) level.
 * Remarks:	None.
 */
tree_index *
register_at_level(const int discriminator, tree_index &table_node,
		  const int to_register, const int cluster_size)
{
  tree_index	*tip;

  if (table_node.counter == 0) {
    if (!to_register)
      return NULL;
    tip = table_node.down.indx = new tree_index[cluster_size + 1];
    table_node.counter = cluster_size + 1;
    memset(tip, 0, (cluster_size + 1) * sizeof(tip[0]));
#ifdef MONITOR_MEMORY
    idx_memory_all += ((cluster_size + 1) * sizeof(tip[0]));
#endif
  }
  tip = table_node.down.indx;
  if (discriminator > cluster_size) {
    cerr << "Too many arcs per node. Increase MAX_ARCS_PER_NODE and recompile"
      << endl;
    exit(13);
  }
  return ((tip[discriminator].counter || to_register) ? tip + discriminator
	                                              : (tree_index *)NULL);
}//register_at_level

/* Name:	cmp_nodes
 * Class:	None (friend of class node).
 * Purpose:	Find if two subgraphs (represented by their root nodes)
 *		are isomorphic.
 * Parameters:	node1		- (i) first node;
 *		node2		- (i) second node;
 * Returns:	0		- if nodes are isomorphic;
 *		negative value	- if `node2' should precede `node1';
 *		positive value	- if `node2' should follow `node1'.
 * Description:	Only the children are compared for letters, being final,
 *		and addresses of the nodes they lead to.
 *		If they are equal, addresses of children are compared.
 * Remarks:	The number of children for the two nodes is not checked,
 *		as it assumed that the function is invoked only when
 *		the tree search has selected nodes of equal number of children
 *		for the comparison.
 *
 *		It is assumed that children are sorted alphabetically.
 *
 *		It is possible to compare addresses of children, because
 *		children are registered first, and all child nodes
 *		of the node to be registered (if any) are already registered.
 *
 *		In previous version, the addresses of children were compared
 *		first.  This should speed up the comparison, and decrease
 *		the number of compared nodes, as a strict order was introduced
 *		among nodes (which was not the case before).
 *
 *		However, this did not work. Arcs were modified, and addresses
 *		of children changed, so that the nodes in the index should
 *		be moved (deregistered and reregistered, or with a special
 *		function) to reflect the changes.
 *
 *		In the version 0.8, I have changed the definition
 *		of comp_or_reg, and I hope it will work with addresses of
 *		children compared first.
 */
int
cmp_nodes(const tnode *node1, const tnode *node2)
{
  int		c;
  arc_node	*p1, *p2;

  // compare children
  p1 = node1->children; p2 = node2->children;
#ifdef DEBUG
  if (node1->no_of_children != node2->no_of_children)
    cerr << "cmp_nodes: no_of_children differ" << endl;
#endif
  for (int i = 0; i < node1->no_of_children; i++, p1++, p2++)
    if (p1->child != p2->child)
      return ((p1->child < p2->child) ? -1 : 1);
    else if ((c = p1->surf_letter - p2->surf_letter) != 0)
      return c;
    else if ((c = p1->get_surf_is_final() - p2->get_surf_is_final()) != 0)
      return c;
    else if ((c = p1->lex_letter - p2->lex_letter) != 0)
      return c;
    else if ((c = p1->get_is_final() - p2->get_is_final()) != 0)
      return c;

  // here nodes are isomorphic
  return 0;
}//cmp_nodes
	
    
/* Name:	part_cmp_nodes
 * Class:	None (friend of class tnode).
 * Purpose:	Compares two subnodes.
 * Parameters:	small_node	- (i) node to be replaced;
 *		big_node	- (i) node that may contain the same arcs;
 *		offset		- (i) (optional) if present, take to comparison
 *					only arcs #offset from small_node;
 *		group_size	- (i) (optional) how many arcs to consider.
 * Returns:	< 0 if small_node < big_node,
 *		= 0 if small_node = big_node,
 *		> 0 if small_node > big_node.
 * Remarks:	Let the small node have arcs (c d f).
 *		If the big node is (b c d f g) we compare:
 *		(b c d f g)  (b c d f g)  (a b c f g)  (a b c f g)
 *		(c d f)        (c d f)<-found!
 *
 *		But for the big node being (b c d e f g):
 *		(b c d e f g)  (b c d e f g)  (b c d e f g)  (b c d e f g)
 *		(c d f)          (c d f)          (c d f)          (c d f)
 *		it does not work.
 *
 *		Maybe by chaging the order of arcs more arcs could be slashed.
 *
 *		It is assumed that both nodes compared
 *		have the same pseudonode. This is achieved
 *		with the index structure.
 */
int
part_cmp_nodes(const tnode *small_node, const tnode *big_node, int offset,
	       int group_size)
{
  arc_node	*sp, *bp;	// small and big node arcs
  int		l;		// number of potential subnodes
  int		big_offset;	// offset of the pseudonode in the big node

  if (offset == -1) {
    offset = 0;
    group_size = small_node->get_no_of_kids();
  }

  // Find out where the pseudonode starts
  sp = small_node->get_children() + offset;
  bp = big_node->get_children();
  l = big_node->get_no_of_kids() - group_size;
  for (big_offset = 0; big_offset <= l; big_offset++, bp++)
    if (sp->surf_letter == bp->surf_letter &&
	sp->lex_letter == bp->lex_letter)
      break;

  // Check for errors
  if (big_offset > l) {
    cerr << "Error in secondary index" << endl
	 << "First arcs do not match" << endl
	 << "Small node: " << endl;
    small_node->print();
    cerr << "Big node: " << endl;
    big_node->print();
    cerr << "Offset was " << offset << ", group_size " << group_size << endl;
    cerr << "Current secondary index:" << endl;
    show_index(1);
    exit(5);			// error in secondary index
  }

  // Now compare arc by arc
  for (int i = 0; i <= group_size; i++, sp++, bp++) {
    if (sp->child != bp->child)
      return (sp->child < bp->child ? -1 : 1);
    else if (sp->surf_letter != bp->surf_letter)
      return (sp->surf_letter - bp->surf_letter);
    else if (sp->lex_letter != bp->lex_letter)
      return (sp->lex_letter - bp->lex_letter);
    else if (sp->get_is_final() != bp->get_is_final())
      return (sp->get_is_final() - bp->get_is_final());
    else if (sp->get_surf_is_final() != bp->get_surf_is_final())
      return (sp->get_surf_is_final() - bp->get_surf_is_final());
  }
  return 0;
}//part_cmp_nodes

/* Name:	cmp_lpairs
 * Class:	None.
 * Purpose:	Seeks a letter pair in the intermediate level of register
 * Parameters:	p1		- (i) pointer to the node to be found;
 *		p2		- (i) pointer to the index structure;
 *		offset		- (i) arc offset in p1;
 * Returns:	0		- if structure found;
 *		negative	- if the structure corresponding to p1 node
 *					should be lower in the register;
 *		positive	- if the structure corresponding to p1 node
 *					should be higher in the register;
 * Remarks:	Last argument is provided for compatibility with other
 *		comparison functions.
 */
int
cmp_lpairs(const void *p1, const void *p2, int offset, int)
{
  int		c;
  arc_node	*a = ((tnode *)p1)->get_children() + offset;
  pair_index	*p = (pair_index *)p2;

  return (((c = (a->surf_letter - p->surf)) == 0) ?
	  (a->lex_letter - p->lex) : c);
}//cmp_lpairs

/* Name:	bpart_cmp
 * Class:	None.
 * Purpose:	Wrapper for part_cmp_nodes.
 * Parameters:	p1		- (i) smaller node;
 *		p2		- (i) bigger node;
 *		offset		- (i) subnode offset;
 *		group_size	- (i) number of nodes in subnode.
 * Returns:	0		- if nodes are isomorphic;
 *		negative value	- if p1 should precede p2;
 *		positive value	- if p1 should follow p2.
 * Remarks:	None.
 */
int
bpart_cmp(const void *p1, const void *p2, int offset, int group_size)
{
  return part_cmp_nodes((const tnode *)p1, *((const tnode **)p2),
			offset, group_size);
}//bpart_cmp


/* Name:	bsearch_ind
 * Class:	None.
 * Purpose:	Finds either a node (or a subnode) or a place where it
 *		should be inserted.
 * Parameters:	n		- (i) node to be found;
 *		low		- (i) first item;
 *		high		- (i) last item;
 *		item_size	- (i) item size (in bytes);
 *		cmp		- (i) comparison function;
 *		offset		- (i) subnode offset in a big node;
 *		group_size	- (i) number of arcs in a subnode.
 * Returns:	Address to either the node or an entry in the index
 *		leading to that node, or a place where it should be,
 *		if it were there.
 * Remarks:	I had to write my own bsearch function for two reasons:
 *		1) comparing subnodes requires additional parameters
 *			to the comparison function;
 *		2) I need to node where to put the node in case where it
 *			is missing in the register.
 */
void *
bsearch_ind(const tnode *n, void *low, void *high,
	    int (*cmp)(const void *, const void *, int, int),
	    const int item_size, const int offset, const int group_size)
{
  char	*mid;
  int	c;

  while ((char *)low <= (char *)high) {
    mid = ((char *)low +
	   ((((char *)high - (char *)low) / 2 / item_size) * item_size));
    if ((c = cmp(n, mid, offset, group_size)) < 0)
      high = (void *)(mid - item_size);
    else if (c > 0)
      low = (void *)(mid + item_size);
    else
      return (void *)mid;
  }
  return (void *)((char *)high + item_size);
}//bsearch_ind


/* Name:	register_at_pair_level
 * Class:	None.
 * Purpose:	Registers a node (or a pseudonode) at the character pair
 *		level.
 * Parameters:	c_node		- (i) the node (or a pseudonode)
 *					to be registered;
 *		table_node	- (i/o) index entry one level up;
 *		to_register	- (i) TRUE means register, FALSE - search only;
 *		offset		- (i) offset of the pseudonode
 *					(0 for a real node);
 *		group_size	- (i) number of arcs in a pseudonode
 *					(number of arcs in a real node).
 * Returns:	A pair_index structure pointing to the lowest level.
 * Remarks:	None.
 */
pair_index *
register_at_pair_level(const tnode *c_node, tree_index &table_node,
		       const int to_register, const int offset,
		       const int group_size)
{
  arc_node	*curr_arc;
  pair_index	*new_tip;
  pair_index	*new_pair_index;
  int		i;

  curr_arc = c_node->get_children() + offset;
  if (table_node.counter == 0) {
    if (!to_register)
      return NULL;
    // New index for this value - create the first entry
    table_node.down.pind = new pair_index[table_node.size = INDEX_SIZE_STEP];
    table_node.down.pind->surf = curr_arc->surf_letter;
    table_node.down.pind->lex = curr_arc->lex_letter;
    table_node.down.pind->down = NULL;
    table_node.down.pind->counter = 0;
    table_node.down.pind->size = 0;
    table_node.counter = 1;
    return table_node.down.pind;
#ifdef MONITOR_MEMORY
    idx_memory_all += (sizeof(pair_index) * INDEX_SIZE_STEP);
#endif
  }
  else {
    new_tip = (pair_index *)bsearch_ind(c_node, table_node.down.pind,
			  table_node.down.pind + table_node.counter - 1,
			  cmp_lpairs, sizeof(pair_index), offset, group_size);
    if (new_tip >= table_node.down.pind + table_node.counter ||
	cmp_lpairs(c_node, new_tip, offset, group_size) != 0) {
      // Entry not found
      if (!to_register)
	return NULL;
      // character pair not found - insert it into the index
      i = new_tip - table_node.down.pind;
      if (table_node.counter >= table_node.size) {
	// no room for it - allocate new space
	new_pair_index = new pair_index[table_node.size += INDEX_SIZE_STEP];
	memcpy(new_pair_index, table_node.down.pind, i * sizeof(*new_tip));
	memcpy(new_pair_index + i + 1, table_node.down.pind + i,
	       (table_node.counter - i) * sizeof(*new_tip));
	delete [] table_node.down.pind;
	table_node.down.pind = new_pair_index;
	new_tip = new_pair_index + i;
#ifdef MONITOR_MEMORY
	idx_memory_all += (INDEX_SIZE_STEP * sizeof(pair_index));
#endif
      }
      else if (i < table_node.counter)
	memmove(new_tip + 1, new_tip,
		(table_node.counter - i) * sizeof(*new_tip));
      new_tip->surf = curr_arc->surf_letter;
      new_tip->lex = curr_arc->lex_letter;
      new_tip->counter = 0;
      new_tip->size = 0;
      new_tip->down = NULL;
      table_node.counter++;
      return new_tip;
    }
    else {
      // Entry found
      return new_tip;
    }
  }
}//register_at_pair_level

/* Name:	register_subnodes
 * Class:	None (friend of class tnode).
 * Purpose:	Registers sets of `group_size' arcs as a pseudonode.
 * Parameters:	c_node		- (i) groups of arcs of c_node are to be
 *					registered as a pseudonode;
 *		group_size	- (i) number of arcs in a group.
 * Returns:	Nothing.
 * Remarks:	A pointer to the original full size node is registered in
 *		the secondary index.
 *
 *		As of version 0.8, I have replaced the number of children level
 *		(here superficial), with two levels corresponding to the
 *		surface and the lexical characters.
 *
 *		Note that for any pseudonode to be equivalent to another node
 *		all nodes being targets of arcs of the pseudonode must also
 *		be targets of arcs of at least one other node.  This means
 *		that their hit count bust be at least 2. There is no point
 *		in registering a pseudonode whose transitions do not
 *		satisfy that condition.
 */
void
register_subnodes(tnode *c_node, const int group_size)
{
  int		i;
  tnode		**current_node;
  tree_index	*tip;
  pair_index	*new_tip;
  tree_index	*index_root;

  index_root = get_index_by_name(SECOND_INDEX);
#ifdef STOPBIT
  int  offset = c_node->no_of_children - group_size; {
#else
  for (int offset=0; offset <= c_node->no_of_children - group_size; offset++){
#endif

    // check if the pseudonode is worth registering
    int drop_cycle = FALSE;
    tnode *child;
    for (int j = offset; j < offset + group_size; j++) {
      if ((child = c_node->get_children()[j].child)
	  && child->get_hit_count() <= 1) {
	drop_cycle = TRUE;
	break;
      }
    }
    if (drop_cycle)
#ifdef STOPBIT
      return;
#else
      continue;
#endif

    // Register in the index of hash function value
    tip = register_at_level(hash(c_node, offset, group_size), *index_root,
			    REGISTER);

    // Register at the level of character pairs
    new_tip = register_at_pair_level(c_node, *tip, REGISTER, offset,
				     group_size);

    // Register in the lowest level table
    if (new_tip->counter == 0) {
      // No nodes yet
      new_tip->down = new tnode *[new_tip->size = INDEX_SIZE_STEP];
      new_tip->down[0] = c_node;
      new_tip->counter = 1;
    }
    else {
      // There are nodes at the lowest level
      current_node = (tnode **)bsearch_ind(c_node, new_tip->down,
				new_tip->down + new_tip->counter - 1,
				bpart_cmp, sizeof(tnode *), offset,
				group_size);
      if (current_node >= new_tip->down + new_tip->counter ||
	  part_cmp_nodes(c_node, *current_node, offset, group_size)) {
	// subnode not found - insert it
	i = current_node - new_tip->down;
	if (new_tip->counter >= new_tip->size) {
	  current_node = new tnode *[new_tip->size += INDEX_SIZE_STEP];
	  memcpy(current_node, new_tip->down, i * sizeof(tnode *));
	  memcpy(current_node + i + 1, new_tip->down + i,
		 (new_tip->counter - i) * sizeof(tnode *));
	  delete [] new_tip->down;
	  new_tip->down = current_node;
	  current_node += i;
	}
	else
	  memmove(current_node + 1, current_node,
		  sizeof(tnode *) * (new_tip->counter - i));
	*current_node = c_node;
	new_tip->counter++;
      }
    }
  }
}//register_subnodes


/* Name:	tget_pseudo_offset
 * Class:	None (friend of class tnode).
 * Purpose:	Looks if it is possible to replace arcs of the smaller node
 *		with a subset of arcs of a larger node. If yes, then
 *		finds the position of the small node as a pseudonode
 *		within the big node.
 * Parameters:	small_node	- (i) node to be replaced;
 *		big_node	- (i) node that may contain the same arcs;
 * Returns:	Number of the arc of big_node that is the first of
 *		small_node->no_of_children arcs that are identical to the arcs
 *		of small_node, or -1 if such arcs not found.
 * Remarks:	Let the small node have arcs (c d f).
 *		If the big node is (b c d f g) we compare:
 *		(b c d f g)  (b c d f g)  (a b c f g)  (a b c f g)
 *		(c d f)        (c d f)<-found!
 *
 *		But for the big node being (b c d e f g):
 *		(b c d e f g)  (b c d e f g)  (b c d e f g)  (b c d e f g)
 *		(c d f)          (c d f)          (c d f)          (c d f)
 *		it does not work.
 *
 *		Maybe by chaging the order of arcs more arcs could be slashed.
 */
int
tget_pseudo_offset(const tnode *small_node, const tnode *big_node)
{
  arc_node	*sp, *bp;	// arcs of the smaller and the bigger node
  int		big_offset;	// where the pseudonode starts

  if (big_node->get_big_brother()) {
    // big node has a bigger brother
    // since we must have looked at that brother earlier we do not waste time
    // on dealing with a node containing only a subset of what he had
    return -1;
  }

  // Find where the pseudonode in the big_node begins
  int l = big_node->get_no_of_kids() - small_node->get_no_of_kids();
  sp = small_node->get_children();
  bp = big_node->get_children();
  for (big_offset = 0; big_offset <= l; big_offset++, bp++) {
    if (sp->surf_letter == bp->surf_letter && sp->lex_letter == bp->lex_letter)
      break;
  }
  return (big_offset <= l ? big_offset : -1);
}//tget_pseudo_offset

#if defined(FLEXIBLE) && defined(STOPBIT) && defined(MORE_COMPR)
/* Name:	match_subset
 * Class:	None.
 * Purpose:	Find if there is a node in the register that consists
 *		of a subset of arcs of the present node. If there is one,
 *		rearrange the arcs of the node so that the arcs corresponding
 *		to the node in the register are grouped at the end
 *		of the node. Then link nodes so that the node becomes
 *		the big brother of the smaller node from the register.
 * Parameters:	n		- (i/o) the node to be analyzed;
 *		kids_tab	- (i) a table with numbers of arcs
 *					of nodes in the automaton,
 *					kids_tab[0] - the biggest no of kids,
 *					kids_tab[1] - the second biggest,etc.;
 *		kids_no_no	- (i) number of entries in kids_tab.
 * Returns:	True if a match found, false otherwise.
 * Remarks:	The arcs in all nodes are ordered in the same way,
 *		so it is sufficient to select arcs.
 *		We must allocate memory for arcs dynamically, as it is
 *		released by the destructor of node.
 */
int
match_subset(tnode *n, const int kids_tab[], const int kids_no_no)
{
  static tnode		node_template;
  arc_node *arc_template =  new arc_node[MAX_ARCS_PER_NODE];
  node_template.children = arc_template;
  for (int i = 1; i < kids_no_no; i++) {
    int subset_size = kids_tab[i];
    node_template.no_of_children = subset_size;
    if (match_part(n, &node_template, subset_size, 0, subset_size))
      return TRUE;
  }
  return FALSE;
}//match_subset


/* Name:	match_part
 * Class:	None.
 * Purpose:	Creates another subset of arcs of a node.
 * Parameters:	n		- (i/o) source of subsets;
 *		nn		- (i/o) temporary node;
 *		to_do		- (i) number of arcs to complete;
 *		start_at	- (i) start selecting arcs from that arc;
 *		subset_size	- (i) number of arcs in the node
 *					to be created.
 * Returns:	TRUE if an isomorphic node found, FALSE otherwise.
 * Remarks:	None.
 */
int
match_part(tnode *n, tnode *nn, const int to_do, const int start_at,
	   const int subset_size)
{
  tnode	*isomorphic;

  if (to_do == 0) {
    // subset complete
    if ((isomorphic = find_or_register(nn, PRIM_INDEX, FALSE)) != NULL) {
      // check if a link can be created
      if (isomorphic->big_brother ||
	  isomorphic->free_end != isomorphic->no_of_children)
	return FALSE;
      // reorder arcs
      int nk = n->no_of_children - subset_size;
      for (int j = 0; j < isomorphic->no_of_children; j++) {
	int k = 0;
	while (n->children[k] != isomorphic->children[j]) k++;
	if (k != nk + j) {
	  // exchange arcs in n
	  arc_node temp = n->children[nk + j];
	  n->children[nk + j] = n->children[k];
	  n->children[k] = temp;
	}
	k++;
      }
      // link nodes
      isomorphic->set_link(n, nk);
      // cerr << "A node linked!\n";
      return TRUE;
    }
    return FALSE;
  }
  if (start_at >= n->no_of_children) return FALSE;
  for (int i = start_at; i <= n->no_of_children - to_do; i++) {
    // the arc must point to a node pointed to by another node
    if (n->children[i].child && n->children[i].child->hit_node(0) > 1) {
      nn->children[subset_size - to_do] = n->children[i];
      if (match_part(n, nn, to_do - 1, i + 1, subset_size))
	return TRUE;
    }
  }
  return FALSE;
}
#endif //FLEXIBLE,STOPBIT,MORE_COMPR


/* Name:	compress_or_register
 * Class:	None.
 * Purpose:	Find if there is subgraph in the transducer that is isomorphic
 *		to the subgraph that begins at the last child of this node.
 * Parameters:	l_node		- (i/o) parent of the node to be compressed
 *					or registered;
 *		cr_node		- (i/o) node to registered or replaced by
 *					an already registered node (optional);
 *					if not specified: take last child.
 * Returns:	TRUE if node compressed, FALSE if registered.
 * Remarks:	Because the node can be deleted, and replaced by a pointer
 *		to another node, the method must be invoked with the parent
 *		of the node in question, so that the pointer can be modified.
 *
 *		hit_count counts the number of (registered) links that lead
 *		to a node. hit_count = 0 means the node is not registered yet.
 *		hit_count is also used to avoid deleting nodes that are
 *		pointed to somewhere else in the transducer.
 */
int
compress_or_register(tnode *l_node, tnode *cr_node)
{
  tnode		*c_node;		// current tnode
  tnode		*new_node;
  int		c_index = 0;
  int		compressed = FALSE;
  arc_node	*kids;

  if (l_node->get_no_of_kids()) {
    if (cr_node) {
      c_node = cr_node;
    }
    else {
      // Last child requested
      c_index = l_node->get_no_of_kids() - 1;
      c_node = l_node->get_children()[c_index].child;
    }
    if (c_node == NULL) {
      // Nothing to be registered. One letter has been previously added
      // to this node, which resulted only in creation of another arc,
      // but there is no new node attached to it.
      return FALSE;
    }
    if (c_node->get_hit_count() == 0) {
      // node has not been registered yet
      if (c_node->get_no_of_kids()) {

	if (cr_node) {
	  // Specific child of this node requested, getting its index
	  kids = l_node->get_children();
	  for (c_index = 0; c_index < l_node->get_no_of_kids();
	       c_index++, kids++)
	    if (kids->child == cr_node)
	      break;
	}
	if (c_index >= l_node->get_no_of_kids())
	  cerr << "c_index out of range\n";

	// compress or register the children (i.e. the line of the youngest)
	// NOTE: the node may have children, but this only means that there
	//       are arcs going from that node; there is no guarrantee
	//       there are nodes at the end of those arcs.
	// Unlike the sorted version, all kids have to be considered
	kids = c_node->get_children();
	for (int i = 0; i < c_node->get_no_of_kids(); i++, kids++)
	  if (kids->child)
	    compress_or_register(c_node, kids->child);

	// Check if there already an isomorphic subgraph in the transducer
	if ((new_node = find_or_register(c_node, PRIM_INDEX, FIND))) {
	  // Isomorphic subgraph found

	  // Delete c_node
	  delete_branch(c_node);

	  // Link found node to parent
	  l_node->get_children()[c_index].child = new_node;

	  compressed = TRUE;
	}
	else {
	  // subgraph is unique, register it
	  find_or_register(c_node, PRIM_INDEX, REGISTER);
	  new_node = c_node;
	}
	new_node->hit_node();	// count number of links to that node
      }
    }//if node not registered previously
  }//if there is a node to register

  return compressed;
}//compress_or_register

/* Name:	comp_or_reg
 * Class:	None.
 * Purpose:	Find if there is subgraph in the transducer that is isomorphic
 *		to the subgraph that begins at the last child of this node.
 * Parameters:	n		- (i/o) node to be registered or replaced by
 *					an already existing node.
 * Returns:	Pointer to n or to the equivalent node that replaced it.
 * Remarks:	hit_count counts the number of (registered) links that lead
 *		to a node. hit_count = 0 means the node is not registered yet.
 *		hit_count is also used to avoid deleting nodes that are
 *		pointed to somewhere else in the transducer.
 *
 *		Note that hit_count is always increased for the unique node,
 *		regardless whether it is the original parameter of comp_or_reg,
 *		or a node found found somewhere else in the transducer.
 *		This means that in the situation where we modify an existing
 *		path in the transducer (path from the start node to
 *		the first reentrant node, 
 *		that is a node with more than one incoming arc), we should
 *		decrease hit_count for that node _before_ calling comp_or_reg.
 *		If an isomorphic node is found, then n can be deleted
 *		by delete_branch (note that delete_branch only deletes nodes
 *		that have hit_count equal to zero). Remember that the node
 *		n _must_ be unregistered first!!!
 *		If an isomorphic node is not found, then comp_or_reg simply
 *		restores the hit_count.
 */
tnode *
comp_or_reg(tnode *n)
{
  tnode		*new_node;

  if ((new_node = find_or_register(n, PRIM_INDEX, FIND))) {
    // isomorphic graph found
    delete_branch(n);
  }
  else {
    // subgraph is unique, register it
    find_or_register(n, PRIM_INDEX, REGISTER);
    new_node = n;
  }
  new_node->hit_node();
  return new_node;
}//comp_or_reg



/* Name:	find_or_register
 * Class:	None.
 * Purpose:	Finds an isomorphic subgraph in the transducer or registers
 *		a new node.
 * Parameters:	c_node		- (i) node to be found or registered;
 *		index_root_name	- (i/o) which index to use;
 *		register_it	- (i) if TRUE, register the node,
 *					if FALSE, find an isomorphic node.
 * Returns:	Pointer to an isomorphic node or NULL.
 * Remarks:	The primary index has levels indexed for:
 *		number of children
 *		hash function
 *		all features of the node
 *
 *		The secondary index has level indexed for:
 *		hash function
 *		character pairs
 *		all features of the node
 *
 *		index_root_name parameter may have two values:
 *		PRIM_INDEX (= 0) - primary index used normally in the program,
 *		SECOND_INDEX (= 1) - secondary index used in optimization.
 *
 *		The force_registration parameter is now abandoned.
 *		The only situation it was used was in appending a suffix,
 *		when a node from the suffix was isomorphic with the node
 *		to which the suffix was appended. The workaround is simply
 *		to unregister that node (the last node in the common prefix),
 *		because it should be unregistered and reregistered anyway.
 */
tnode *
find_or_register(tnode *c_node, const int index_root_name,
		   const int register_it)
{
  tree_index	*tip;		// tree index pointer
  tnode		**current_node;	// subsequent entry in the leaf table
  int		i;
  tree_index	*index_root;
  pair_index	*new_tip;
  int		*size;		// number of places for nodes in  leaf vector
  int		*counter;	// number of nodes in leaf vector
  tnode		***down;	// leaf vector address

  index_root = get_index_by_name(index_root_name);

  if (index_root_name) {
    // Secondary index
    // First compute hash function
    tip = register_at_level(hash(c_node, 0, c_node->get_no_of_kids()),
			    *index_root, register_it);
    if (tip == NULL)
      return NULL;

    // Register at the level of character pairs
    new_tip = register_at_pair_level(c_node, *tip, register_it, 0,
				     c_node->get_no_of_kids());
    if (new_tip == NULL)
      return NULL;
    size = &(new_tip->size);
    counter = &(new_tip->counter);
    down = &(new_tip->down);
  }
  else {
    // Primary index
    // searching for the number of children entry
    tip = register_at_level(c_node->get_no_of_kids(), *index_root,
			    register_it);
    if (tip == NULL)
      return NULL;

    // searching according to hash function value
    tip = register_at_level(hash(c_node, 0, c_node->get_no_of_kids()), *tip,
			    register_it);
    if (tip == NULL)
      return NULL;

    size = &(tip->size);
    counter = &(tip->counter);
    down = &(tip->down.leaf);
  }//if primary index

  // now we search the lowest level, which has entries pointing directly
  if (*counter == 0) {
    // There are no node pointers at the lowest level
    if (!register_it)
      return NULL;
    if (*size <= 0) {		// there may be a room left from unregister
      *down = new tnode *[*size = INDEX_SIZE_STEP];
#ifdef MONITOR_MEMORY
      idx_memory_all += (sizeof(tnode *) * INDEX_SIZE_STEP);
#endif
    }
    **down = c_node;
    *counter = 1;
    return NULL;		// because not found
  }
  else {
    // There are entries at the lowest level
    current_node = (tnode **)bsearch_ind(c_node, *down, *down + *counter - 1,
			      (index_root_name ? bpart_cmp : cmp_bnodes),
			      sizeof(tnode *), 0, c_node->get_no_of_kids());
    if (current_node >= *down + *counter ||
	(index_root_name ?
	 part_cmp_nodes(c_node, *current_node, 0, c_node->get_no_of_kids()) :
	 cmp_nodes(c_node, *current_node))) {
      // Subnode not found
      if (!register_it)
	return NULL;
      // Register it
      i = current_node - *down;	// i is the place where the node should be
      if (*counter >= *size) {
	// No room for new node - allocate new space
	current_node = new tnode *[*size += INDEX_SIZE_STEP];
	// copy current contents up to i
	memcpy(current_node, *down, sizeof(tnode *) * i);
	// copy the rest leaving the space for the new item
	memcpy(current_node + i + 1, *down + i,
	       (*counter - i) * sizeof(tnode *));
	// delete old index vector
	delete [] *down;
	// and replace it with the new copy
	*down = current_node;
	// current_node should point to the newly inserted item
	current_node += i;
#ifdef MONITOR_MEMORY
	idx_memory_all += (sizeof(tnode *) * INDEX_SIZE_STEP);
#endif
      }
      else
	// Shift items above i
	memmove(current_node + 1, current_node,
		(*counter - i) * sizeof(tnode *));
      // Insert the node
      *current_node = c_node;
      (*counter)++;

      // Node registered
      return NULL;		// because not found
    }
    else {
      // Node found
      if (register_it) {
	cerr << "Attempt to register an already registered node" << endl;
	exit(6);		// attempt to register registered node
      }
      return *current_node;
    }
  }
}//tnode::find_or_register


/* Name:	unregister
 * Class:	none
 * Purpose:	Unregisters a node.
 * Parameters:	c_node		- node to unregister.
 * Returns:	TRUE if node unregistered, FALSE otherwise.
 * Remarks:	The primary index has levels indexed for:
 *		number of children
 *		hash function
 *		all features of the node
 *
 *		Unregistering removes the entry from the lowest level,
 *		leaving higher levels untouched (except for counters).
 *
 *		There is no unregistering procedure for the secondary index.
 */
int
unregister(tnode *c_node)
{
  tree_index	*tip;		// tree index pointer
  tnode		**current_node;	// subsequent entry in the leaf table
  tree_index	*index_root;
  int		i;

  index_root = get_index_by_name(PRIM_INDEX);

  // searching for the number of children entry
  tip = register_at_level(c_node->get_no_of_kids(), *index_root, FALSE);
  if (tip == NULL) {
    cerr << "Attempt to unregister a node never registered!\n";
    exit(7);			// unregister never registered node
  }

  // searching according to hash function value
  tip = register_at_level(hash(c_node, 0, c_node->get_no_of_kids()), *tip,
			  FALSE);
  if (tip == NULL) {
    cerr << "Attempt to unregister a node never registered!\n";
    exit(7);			// unregister never registered node
  }


  // now we search the lowest level, which has entries pointing directly
  // to end nodes
  if ((current_node = (tnode **)bsearch_ind(c_node, tip->down.leaf,
				  tip->down.leaf + tip->counter - 1,
				  cmp_bnodes, sizeof(tnode *), 0,
				  c_node->get_no_of_kids())) != NULL) {
    // Node found
    // shorten the vector
    i = current_node - tip->down.leaf;
    if (i < tip->counter - 1)
      memmove(current_node, current_node + 1,
	      (tip->counter - i - 1) * sizeof(tnode *));
    --(tip->counter);
  }
  // else do nothing
  return TRUE;
}//unregister


/* Name:	destroy_index
 * Class:	None.
 * Purpose:	Destroys index structure (releasing memory!).
 * Parameters:	index_root	- (i) index to destroy.
 * Returns:	Nothing.
 * Remarks:	Nodes pointed to in the index are not destroyed.
 *
 *		For the time being, only the secondary index may be distroyed.
 *
 *		The primary index has 3 levels:
 *		number of children
 *		hash function
 *		all features (vector of pointers to nodes, binary search).
 *
 *		The secondary index has 3 different levels:
 *		hash function
 *		character pairs (index item of different structure
 *		all features (vector of pointers to nodes, binary search).
 */
void
destroy_index(tree_index &index_root)
{
  tree_index	*tip1;
  pair_index	*tip2;

  tip1 = index_root.down.indx;	// points to the index on hash function
  for (int i = 0; i < index_root.counter; i++, tip1++) {
    tip2 = tip1->down.pind;	// points to the index on character pairs
    for (int j = 0; j < tip1->counter; j++, tip2++) {
      if (tip2->counter || tip2->size) {	// tip2->size added!!!
	delete [] tip2->down;	// delete vectors of poiters to nodes
#ifdef MONITOR_MEMORY
	idx_memory_all -= (tip2->size * sizeof(tnode *));
#endif
      }
    }
    if (tip1->counter > 0) {
      delete [] tip1->down.pind;	// delete indexed on character pairs
#ifdef MONITOR_MEMORY
      idx_memory_all -= (tip1->size * sizeof(pair_index));
#endif
    }
  }
  delete [] index_root.down.indx;	// delete indexed on hash value
#ifdef MONITOR_MEMORY
  idx_memory_all -= (index_root.counter * sizeof(tree_index));
#endif
  index_root.counter = 0; index_root.size = 0;
}//destroy_index


/* Name:	hash
 * Class:	None.
 * Purpose:	Computes a hash function for the node to be used in index.
 * Parameters:	n		- (i) node for which hash function is to be
 *					computed;
 *		start		- (i) first arc number
 *		how_many	- (i) how many arcs are to be considered.
 * Returns:	Hash function.
 * Remarks:	Value of hash function depends on labels of arcs going
 *		from this node.
 *		Due to problems with unregistering, dependency on addresses
 *		had to be abandoned.
 *		From the version 0.8, it is reintroduced.
 */
int
hash(const tnode *n, const int start, const int how_many)
{
  arc_node	*kids = n->get_children();
  long		h = 0;
  int	finish = start + how_many;
  for (int i = start; i < finish; i++)
    h = ((h * 5) ^ (kids[i].lex_letter * 17)
	  ^ (kids[i].surf_letter) ^ (long(kids[i].child) >> 2));
  return (h & MAX_ARCS_PER_NODE);
}//hash



/* Name:	share_arcs
 * Class:	None.
 * Purpose:	Tries to find if arcs of one node are a subset of another.
 *		If so, a reference to them is replaced by a reference
 *		to a part (a subset) of the other node.
 * Parameters:	root		- (i) root of the automaton.
 * Returns:	Number of suppressed arcs.
 * Remarks:	This must take A LOT of time!
 *
 *              The algorithm:
 *              Let n1 be the second biggest number of children per node
 *              in the automaton.
 *              Take all consecutive sequences of n1 arcs from each of
 *              nodes with the biggest number of arcs and register them
 *              as nodes in the secondary index.
 *              For each node with n1 children, search for an isomorphic
 *              node in the secondary index. If found, set a link
 *              from the smaller node to the bigger one.
 */
int
share_arcs(tnode *root)
{
  tree_index	*prim_index;
  tree_index	*tip1, *tip2, *tip3;
  tnode		**tip4;
  tnode		*new_node;
  int		nodes_knocked, arcs_knocked;
  int		i, j, l, offset;
  int		prime_kids_tab[MAX_ARCS_PER_NODE + 1];
                                /* [0] - biggest no of children per node in
                                         the automaton
                                   [1] - 2nd biggest no of children
                                   ...
                                   [prime_kids-1] - 1 child */
  int		prime_kids;


  nodes_knocked = 0; arcs_knocked = 0;
  prim_index = get_index_by_name(PRIM_INDEX);
#ifdef DEBUG
  show_index(PRIM_INDEX);
#endif

#ifdef  SORT_ON_FREQ
  // sort arcs on frequency
  for (i = 0; i < 256*256; i++) {
    frequency_table[i] = 0;
    frequency_order[i] = i;
  }
  root->count_arcs(frequency_table);
  qsort(frequency_order, 256*256, sizeof(int), freq_count_cmp);
  root->sort_arcs();
#endif


  prime_kids = 0;
  // start from nodes with the biggest number of children
  tip1 = prim_index->down.indx + prim_index->counter - 1;
  for (i = prim_index->counter - 1; i >= 0; --i, --tip1) {
    if (tip1->counter) {
      // Checking the counter is not enough, as traces may be left
      // by deleted entries
      tip3 = tip1->down.indx;
      for (j = 0; j < tip1->counter; j++, tip3++) {
	if (tip3->counter > 0) {
	  prime_kids_tab[prime_kids++] = i;
	  break;
	}
      }
    }
  }

  for (i = 1; i < prime_kids; i++) {
#ifdef PROGRESS
    cerr << "Creating secondary index for nodes with " << prime_kids_tab[i]
	 << " children\n";
#endif
    tip1 = prim_index->down.indx + prime_kids_tab[i];


    // Now register pseudonodes consisting of sets of `prime_kids_tab[i]' arcs
    // taken from the nodes that have more than `prime_kids_tab[i]' arcs
    for (j = 0; j < i; j++) {
      tip2 = prim_index->down.indx + prime_kids_tab[j];

      // We have passed # of children index, now go through hash function
      tip3 = tip2->down.indx;
      for (int k = 0; k < tip2->counter; k++, tip3++) {
	if (tip3->counter == 0)
	  continue;

	// Now we register each set of tip->data arcs
	tip4 = tip3->down.leaf;
	for (l = 0; l < tip3->counter; l++, tip4++) {
	  register_subnodes(*tip4, prime_kids_tab[i]);
	}
      }
    }
#ifdef PROGRESS
    cerr << "Secondary index built" << endl;
#endif

    // Secondary index created, now look for nodes in primary index
#ifdef DEBUG
    cerr << "Pseudonodes of " << prime_kids_tab[i] << " arcs" << endl;
    show_index(SECOND_INDEX);
#endif
    tip3 = tip1->down.indx;
    for (j = 0; j < tip1->counter; j++, tip3++) {
      if (tip3->counter == 0)
	continue;

      tip4 = tip3->down.leaf;
      for (l = 0; l < tip3->counter; l++, tip4++) {
	if ((new_node = find_or_register(*tip4, SECOND_INDEX, FIND))) {
	  // Node *tip4 (taken from primary index) was found in secondary
	  // index (of subnodes), so it can be replaced by a reference
	  // to a set of arcs of the node `new_node'. So we do that.

	  if ((offset = tget_pseudo_offset(*tip4, new_node)) >= 0) {
	    (*tip4)->set_link(new_node, offset);
	    nodes_knocked++;
	    arcs_knocked += prime_kids_tab[i];
	  }
	  else {
	    cerr << "Error in secondary index\n";
	    exit(5);
	  }
	}
      }
    }

    // Now secondary index for tip1->data number of nodes is no longer needed
    // Destroy the index to make room for other data
    tip3 = get_index_by_name(SECOND_INDEX);
    destroy_index(*tip3);
  }
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(MORE_COMPR)
  // Take nodes from the primary index in groups of equal number of arcs.
  // Begin from the biggest nodes.
  // Take subsets of arcs from those nodes, treat them as new nodes,
  // and try to find if there are other nodes in the register that
  // are isomorphic to those new nodes. If so, create links.

#ifdef PROGRESS
  cerr << "Changing the order of transitions" << endl;
#endif

  // Begin with the largest nodes, proceed to smaller
  for (i = 0; i < prime_kids - 1; i++) {
    tip1 = prim_index->down.indx + prime_kids_tab[i];
    // Go through hash level
    tip3 = tip1->down.indx;
    for (j = 0; j < tip1->counter; j++, tip3++) {
      if (tip3->counter == 0)
	continue;

      tip4 = tip3->down.leaf;	// the leaf level
      for (l = 0; l < tip3->counter; l++, tip4++) {
	if ((*tip4)->get_big_brother() == NULL
	    && (*tip4)->free_end == (*tip4)->get_no_of_kids()) {
	  if (match_subset(*tip4, prime_kids_tab + i, prime_kids - i)) {
	    nodes_knocked++;
	    arcs_knocked += prime_kids_tab[i];
	  }
	}
      }
    }
  }
#endif



#ifdef DEBUG
  cerr << "Got out of the loop!" << endl;
#endif
#ifndef STOPBIT
#ifdef JOIN_PAIRS
#ifdef PROGRESS
  cerr << "Merging pairs" << endl;
#endif
  pair_registery        pr;
  pr.merge_pairs();
#ifdef PROGRESS
  cerr << "Pairs merged" << endl;
#endif
#endif
#endif
#ifdef DEBUG
  cerr << "Slashed " << nodes_knocked << " nodes and " << arcs_knocked
       << " arcs\n";
#endif
  return arcs_knocked;
}//share_arcs


#ifndef STOPBIT
#ifdef JOIN_PAIRS
/* Name:        pair_registery
 * Class:       pair_registery
 * Purpose:     Create a table of pointers to nodes with two arcs.
 * Parameters:  None.
 * Returns:     Nothing (constructor).
 * Remarks:     c11_index must have 257 because one needs the i+1 entry
 *		to count nodes that have the same c11.
 */
pair_registery::pair_registery(void)
{
  packed = new packed_tab[allocated = PAIR_CHUNK];
  no_of_pairs = 0;
  for (int i = 0; i < 257; i++)
    c11_index[i] = 0;
}//pair_registery::pair_registery



/* Name:        ~pair_registery
 * Class:       pair_registery
 * Purpose:     Deallocate memory (destructor).
 * Parameters:  None.
 * Returns:     Nothing.
 * Remarks:     None.
 */
pair_registery::~pair_registery(void)
{
  for (int i = 0; i < no_of_pairs; i++)
    if (packed[i].p)
      delete packed[i].p;
  delete packed;
}//pair_registery::~pair_registery


/* Name:        reg
 * Class:       pair_registery
 * Purpose:     Register a two arc node.
 * Parameters:  n       - (i) the node to be registered.
 * Returns:     Nothing.
 * Remarks:     It is assumed that n has two children.
 *		Nodes are put into a register.
 *		The register is indexed on the surface character of
 *		the first arc. This is done in order to speed up searches.
 *		However, no further indices are added because of the
 *		enormous space they would take.
 *
 *		It is assumed here that characters are signed.
 *		If it is not so, "x + 128" should be replaced by "unsigned(x)".
 */
void
pair_registery::reg(tnode *n)
{
  packed_tab	*p1;
  tnode  	**p2;
  long		v1, v2;
  packed_tab	*entry;
  int		entry_index;
  int		i;
  arc_node	*kids;

  kids = n->get_children();
  if (kids[0].child && kids[1].child && kids[0].child->get_hit_count() < 2 &&
      kids[1].child->get_hit_count() < 2)
    return;
  unsigned char c11 = kids[0].surf_letter + 128;
  unsigned char c12 = kids[0].lex_letter + 128;
  unsigned char c21 = kids[1].surf_letter + 128;
  unsigned char c22 = kids[1].lex_letter + 128;

  int found = FALSE;
  v2 = (((c12 << 8) + c21) << 8) + c22;
  for (i = c11_index[c11]; i < c11_index[c11 + 1]; i++) {
    v1 = (((packed[i].c12 << 8) + packed[i].c21) << 8) + packed[i].c22;
    if (v1 == v2) {
      found = TRUE;
      break;
    }
    else if (v1 > v2)
      break;
  }
  entry_index = i;

  // Now entry_index is the index of the entry to be added.
  // If found is FALSE, a new item must be inserted in the packed vector
  // at index_entry, else index_entry item must be modified
  if (!found) {
    // make room for a new entry
    if (++no_of_pairs > allocated) {
      // no space for a new entry - allocate more
      allocated += PAIR_CHUNK;
      p1 = new packed_tab[allocated];
      for (int ij = 0; ij < entry_index; ij++)
	p1[ij] = packed[ij];
      for (int ij1 = entry_index + 1; ij1 < no_of_pairs; ij1++)
	p1[ij1] = packed[ij1-1];
      delete [] packed;
      packed = p1;
    }
    else {
      // there is a room for the entry, just relocate items
      for (int ij = no_of_pairs - 1; ij > entry_index; --ij)
	packed[ij] = packed[ij-1];
    }

    // set up new entry
    entry = packed + entry_index;
    entry->c11 = c11;
    entry->c12 = c12;
    entry->c21 = c21;
    entry->c22 = c22;
    entry->counter = 0;
    entry->allocated = PAIR_REG_LEN;
    entry->p = new tnode *[entry->allocated];

    // update c11_index
    for (int ix = c11+1; ix < 257; ix++)
      c11_index[ix]++;
  }

  // put the node into registery
  entry = packed + entry_index;
  if (entry->counter >= entry->allocated) {
    // allocate more memory
    entry->allocated += PAIR_REG_LEN;
    p2 = new tnode *[entry->allocated];
    for (int ix = 0; ix < entry->counter; ix++)
      p2[ix] = entry->p[ix];
    delete [] entry->p;
    entry->p = p2;
  }
  entry->p[entry->counter++] = n;
}//pair_registery::reg



/* Name:        join_arcs
 * Class:       pair_registery
 * Purpose:     Joins nodes that have two arcs, and one arc is identical.
 * Parameters:  None.
 * Returns:     Nothing.
 * Remarks:     Nodes are already in a vector.
 *              Only pairs are merged. For future versions:
 *              It is possible to join more than two arcs in this way, e.g.
 *
 *              (a, b)(c, d)
 *                 (b, c)(d, e)		(letters refer to arcs, not labels)
 *
 *              etc. In that case, the big_brother pointer in the first node
 *              (i.e. the big brother of the other nodes that are merged)
 *              should point to a table of pointers to nodes, and the offset
 *              of the big brother should be the number of nodes in that
 *              table with minus (to indicate it is a big brother).
 *
 *		It is assumed here that characters are signed.
 *		If it is not so, replace "x + 128" with "unsigned(x)".
 */
void
pair_registery::join_arcs(void)
{
  int           nop1 = no_of_pairs - 1;

#ifdef PROGRESS
  cerr << "Matching pairs" << endl;
#endif
  for (int i = 0; i < nop1; i++) {
    long c2 = ((packed[i].c21 + 128) << 8) + (packed[i].c22 + 128);

    // choose a node with (c2,c3)
    for (int j = i + 1; j < no_of_pairs; j++)
        if ((((packed[j].c11 + 128) << 8) + (packed[j].c12 + 128)) == c2) {
          /* Now 2 vectors of nodes have been found that have arcs labelled
             (c1, c2), (c2, c3). Having the same labels
             is not sufficient: the arcs must be identical, i.e.
             they must lead to the same nodes, and have the same
             "final" property.
             */
	  packed_tab *p1 = packed + i;
          tnode **pp1 = p1->p;
          for (int i1 = 0; i1 < p1->counter; i1++, pp1++) {
            tnode *pc2 = (*pp1)->children[1].child;
            int f2 = (*pp1)->children[1].fin_status;

	    packed_tab *p2 = packed + j;
            tnode **pp2 = p2->p;
            for (int j1 = 0; j1 < p2->counter; j1++, pp2++) {
              if ((*pp2)->children[0].child != pc2)
                continue;
              if ((*pp2)->children[0].fin_status != f2)
                continue;

              /* Now we have 2 nodes that can be merged:
                 (c1, c2)
                     (c2, c3)
                 in a bigger node: (c1, c2, c3).
                 Node (c2, c3) has the node (c1, c2) as its big brother.
                 brother_offset is set to 1.
                 Node (c1, c2) receives brother_offset = -1, which indicates
                 that it is the big brother.
                 */

              if ((*pp1)->big_brother)
                cerr << "Node 1 has already a big brother!\n";
              if ((*pp2)->big_brother)
                cerr << "Node 2 has already a big brother!\n";
              (*pp1)->set_link(*pp2, -1);
              (*pp2)->set_link(*pp1, 1);

              /* Nodes are merged, but pp2 must be removed from the register,
                 in order not to be considered for joining once again.
                 Removing pp1 is also needed; it would be considered
                 again after choosing different c3.
                 */
              for (int k = j1 + 1; k < packed[j].counter; k++, pp2++)
                pp2[0] = pp2[1];
              --(packed[j].counter);

              tnode **ppp = pp1;
              for (int l = i1 + 1; l < packed[i].counter; l++, ppp++)
                ppp[0] = ppp[1];
              --(packed[i].counter);
              break;
            }//for j1
          }//for i1
        }//if node (c2, c3) found
  }//for i
}//pair_registery::join_arcs


/* Name:        merge_pairs
 * Class:       pair_registery
 * Purpose:     Launches the process of merging arcs.
 * Parameters:  None.
 * Returns:     Nothing.
 * Remarks:     Use primary index to find nodes that have exactly 2 children,
 *		and do not have big brothers. Register them in the secondary
 *		index. Call other functions to do the rest.
 */
void
pair_registery::merge_pairs(void)
{
  tree_index    *prim_index;
  tnode          **tip3;

#ifdef PROGRESS
  cerr << "Registering pairs" << endl;
#endif
  prim_index = get_index_by_name(PRIM_INDEX);
  // get a subtree of nodes having two children
  tree_index *tip1 = prim_index->down.indx + 2;
  if (tip1 == NULL)
    return;
  tree_index *tip2 = tip1->down.indx;
  for (int i = 0; i < tip1->counter; i++, tip2++) {
    tip3 = tip2->down.leaf;
    for (int j = 0; j < tip2->counter; j++, tip3++)
      // register those that do not have big brothers
      // Note: they can be big brothers themselves
      if ((*tip3)->big_brother == NULL)
        reg((*tip3));
  }
#ifdef DEBUG
  print_reg();
#endif
  join_arcs();
}//pair_registery::merge_pairs

#ifdef DEBUG
/* Name:	print_reg
 * Class:	pair_registery
 * Purpose:	Prints the contents of the pair registery.
 * Parameters:	None.
 * Returns:	Nothing.
 * Remarks:	For debugging only.
 */
void
pair_registery::print_reg(void)
{
  cerr << "no_of_pairs = " << no_of_pairs << ", allocated = " << allocated
    << endl;
  for (int i = 0; i < no_of_pairs; i++) {
    packed_tab *entry = packed + i;
    cerr << "[" << i << "] " << entry->counter << "/" << entry->allocated
      << " " << entry->c11 << "/" << entry->c12 << ", " << entry->c21
      << "/" << entry->c22 << endl;
    for (int j = 0; j < entry->counter; j++) {
      cerr << " +-- "; entry->p[j]->print();
    }
  }
}//pair_registery::print_reg
#endif //DEBUG
#endif //MERGE_PAIRS
#endif //!STOPBIT

//#ifdef DEBUG

/* Name:	show_index
 * Class:	None (friend of class tnode).
 * Purpose:	Show index contents.
 * Parameters:	index_name	- (i) index number.
 * Returns:	Nothing.
 * Remarks:	I hate optimization.
 */
void
show_index(const int index_name)
{
  int		kids_tab[MAX_ARCS_PER_NODE + 1];
  int		hash_tab[MAX_ARCS_PER_NODE + 1];
  int		kids, hashes;
  int		i, j, k, l;
  tree_index	*tip1;
  tnode		**tip2;
  arc_node	*tip3;

  tree_index *index_root = get_index_by_name(index_name);
  kids = 0;
  hashes = 0;
  if (index_name) {
    // secondary index
    cerr << "Secondary index" << endl;
    for (i = 0; i < index_root->counter; i++)
      if (index_root->down.indx[i].counter)
	hash_tab[hashes++] = i;
    for (i = 0; i < hashes; i++) {
      tip1 = index_root->down.indx + hash_tab[i]; // hash entry
      kids = 0;
      cerr << "+-hash: " << hash_tab[i] << " (";
      for (j = 0; j < tip1->counter; j++)
	if (tip1->down.pind[j].counter)
	  kids_tab[kids++] = j;
      cerr << kids << " entries)" << endl;
      for (j = 0; j < kids; j++) {
	cerr << (i < hashes - 1 ? "| " : "  ") << "+-pair: "
	     << tip1->down.pind[kids_tab[j]].surf << "/"
	     << tip1->down.pind[kids_tab[j]].lex
	     << " (" << tip1->down.pind[kids_tab[j]].counter
	     << " entries)" << endl;
	tip2 = tip1->down.pind[kids_tab[j]].down;
	for (k = 0; k < tip1->down.pind[kids_tab[j]].counter; k++, tip2++) {
	  cerr << (i < hashes - 1 ? "| " : "  ")
	       << (j < kids - 1 ? "| " : "  ")
	       << "+-node: " << hex << (long)(*tip2) << dec << endl;
	  tip3 = (*tip2)->get_children();
	  for (l = 0; l < (*tip2)->get_no_of_kids(); l++, tip3++) {
	    cerr << (i < hashes - 1 ? "| " : "  ")
		 << (j < kids - 1 ? "| " : "  ")
		 << (k < tip1->down.indx[kids_tab[j]].counter - 1 ?
		     "| " : "  ")
		 << "+-" << tip3->surf_letter
		 << (tip3->get_surf_is_final() ? "!/" : "/")
		 << tip3->lex_letter << (tip3->get_is_final() ? "! " : " ")
		 << hex << (long)(tip3->child) << dec
		 << endl;
	  }
	}
      }
    }
  }
  else {
    // primary index
    cerr << "Primary index" << endl;
    // first count entries to know when to use |
    for (i = 0; i < index_root->counter; i++)
      if (index_root->down.indx[i].counter)
	kids_tab[kids++] = i;
    for (i = 0; i < kids; i++) {
      tip1 = index_root->down.indx + kids_tab[i];
      hashes = 0;
      cerr << "+-children: " << kids_tab[i] << " (";
      for (j = 0; j < tip1->counter; j++)
	if (tip1->down.indx[j].counter)
	  hash_tab[hashes++] = j;
      cerr << hashes << " entries)\n";
      for (j = 0; j < hashes; j++) {
	cerr << (i < kids - 1 ? "| " : "  ") << "+-hash: " << hash_tab[j]
	     << " (" << tip1->down.indx[hash_tab[j]].counter << " entries)\n";
	tip2 = tip1->down.indx[hash_tab[j]].down.leaf;
	for (k = 0; k < tip1->down.indx[hash_tab[j]].counter; k++, tip2++) {
	  cerr << (i < kids - 1 ? "| " : "  ")
	       << (j < hashes - 1 ? "| " : "  ")
	       << "+-node: " << hex << (long)(*tip2) << dec << "\n";
	  tip3 = (*tip2)->get_children();
	  for (l = 0; l < (*tip2)->get_no_of_kids(); l++, tip3++) {
	    cerr << (i < kids - 1 ? "| " : "  ")
		 << (j < hashes - 1 ? "| " : "  ")
		 << (k < tip1->down.indx[hash_tab[j]].counter - 1 ?
		     "| " : "  ")
		 << "+-" << tip3->surf_letter
		 << (tip3->get_surf_is_final() ? "!/" : "/")
		 << tip3->lex_letter << (tip3->get_is_final() ? "! " : " ")
		 << hex << (long)(tip3->child) << dec
		 << "\n";
	  }
	}
      }
    }
  }
}//show_index
//#endif

/***	EOF nindex.cc	***/
