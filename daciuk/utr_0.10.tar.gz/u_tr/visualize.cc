/***	visualize.cc	***/

/*	Copyright (c) Jan Daciuk, 1998	*/


#include	<iostream>
#include	<fstream>
#include	<string.h>
#include	<stdlib.h>
#include	<new>
#include	"tr.h"
#include	"nstr.h"
#include	"commont.h"
#include	"visualize.h"



/* bit operations */
int is_set(const int bit_no, const unsigned char *vector)
   { return ((vector[bit_no / 8] >> (bit_no & 7)) & 1); }
/* set particular bit */
void set_bit(const int bit_no, unsigned char *vector)
   { vector[bit_no / 8] |= (1 << (bit_no & 7)); }


/* Name:	visual_tr
 * Class:	visual_tr (constructor).
 * Purpose:	Open dictionary files and read automata from them.
 * Parameters:	dict_names	- (i) dictionary file names;
 *		distance	- (i) max edit distance of replacements.
 * Returns:	Nothing.
 * Remarks:	At least one dictionary file must be read.
 */
visual_tr::visual_tr(word_list *dict_names)
: tr(dict_names)
{
}//visual_tr::visual_tr




/* Name:	create_graphs
 * Class:	visual_tr
 * Purpose:	Creates graphs for all automata (all dictionaries).
 * Parameters:	None.
 * Returns:	TRUE if OK, FALSE otherwise.
 * Remarks:	None.
 */
int
visual_tr::create_graphs(void)
{
  dict_list	*dict;
  int		g;
  tr_arc_ptr	start_node, next_node;

  dictionary.reset(); g = 0;
  for (dict = &dictionary; dict->item(); dict->next()) {
    set_dictionary(dict->item());
    no_of_arcs = dict->item()->no_of_arcs;
    arc_size = 1;
    if (arc_size == 1)
      compressed = 1;
    if (compressed) {
      visited = new unsigned char[no_of_arcs / 8 + 1];
      memset(visited, 0, no_of_arcs / 8 + 1);
    }
    cout << "graph: {" << endl
	 << "  title: \"g" << g << "\"" << endl
	 << "  orientation: left_to_right"
	 << "  display_edge_labels: yes" << endl
	 << "  node.shape: ellipse" << endl << endl;
    // last node
    cout << "  node: {" << endl
	 << "    title: \"n0\"" << endl
	 << "  }" << endl << endl;
    start_node = tr_first_node(current_dict);
    next_node = tr_next_node(current_dict, start_node);
#ifdef FLEXIBLE
    current_offset = next_node.arc - current_dict;
#else
    current_offset = (tr_arc_pointer)next_node - current_dict;
#endif
    create_node(start_node);
    if (compressed)
      memset(visited, 0, no_of_arcs / 8 + 1); // clear marks
#ifdef FLEXIBLE
    current_offset = next_node.arc - current_dict;
#else
    current_offset = (tr_arc_pointer)next_node - current_dict;
#endif
    create_edges(start_node);
    cout << "}" << endl;
    if (compressed)
      delete [] visited;
    g++;
  }
  return TRUE;
}//visual_tr::create_graphs


/* Name:	create_node
 * Class:	visual_tr
 * Purpose:	Creates a description of a node for one automaton.
 * Parameters:	start		- (i) look at children of that node.
 * Returns:	TRUE.
 * Remarks:	None.
 */
int
visual_tr::create_node(tr_arc_ptr start)
{
  tr_arc_ptr	next_node = tr_next_node(current_dict, start);
  tr_arc_ptr	next_start;
  //  int		kids = tr_get_children(start);

  if (tr_get_goto(start) == 0)
    return 0;

  // Handle only states that were not handled before
#ifdef FLEXIBLE
  if (compressed ?
      !is_set((next_node.arc - current_dict) / arc_size, visited)
      : next_node.arc - current_dict >= current_offset) {
#else
  if (next_node - current_dict >= current_offset) {
#endif

    // Print node
    cout << " node: {" << endl
	 << "   title: \"n"
#ifdef FLEXIBLE
	 << next_node.arc - current_dict
#else
	 << next_node - current_dict
#endif
	 << "\"" << endl
	 << " }" << endl << endl;

    // Increase current offset
    next_start = tr_next_node(current_dict, start);
    //    for (int i = 0; i < kids; i++, tr_inc_next(next_start))
    forallnodes(i)
      ;
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
    // see if we are not too far because of the next bit
    if (*(next_node.arc - next_node.size + GOTO_OFFSET) & NEXT_BIT_MASK) {
      // correct current_offset
      next_node.arc -= (next_node.gtl - 1);
    }
#endif
#ifdef FLEXIBLE
    current_offset = next_node.arc - current_dict;
#else
    current_offset = next_node - current_dict;
#endif
    next_node = next_start;
    if (compressed)
      set_bit((next_node.arc - current_dict) / arc_size, visited);

    // Print child nodes
    //    for (int i = 0; i < kids; i++, tr_inc_next(next_node)) {
    forallnodes(j) {
      create_node(next_node);
    }
  }
  return TRUE;
}//visual_tr::create_node

/* Name:	create_edges
 * Class:	visual_tr
 * Purpose:	Creates descritpions of all edges going out from this node.
 * Parameters:	start		- look at children of that node.
 * Returns:	TRUE.
 * Remarks:	None.
 */
int
visual_tr::create_edges(tr_arc_ptr start)
{
  tr_arc_ptr	next_node = tr_next_node(current_dict, start);
  tr_arc_ptr	start_node;
  //  int		kids = tr_get_children(start);

  if (tr_get_goto(start) == 0)
    return 0;

  // Handle only states that were not handled before
#ifdef FLEXIBLE
  if (compressed ?
      !is_set((next_node.arc - current_dict) / arc_size, visited)
      : next_node.arc - current_dict >= current_offset) {
#else
  if (next_node - current_dict >= current_offset) {
#endif

    start_node = next_node;
    //    for (int i = 0; i < kids; i++, tr_inc_next(next_node)) {
    forallnodes(i) {
      cout << "  edge: {" << endl
	   << "    sourcename: \"n"
#ifdef FLEXIBLE
	   << start_node.arc - current_dict
#else
	   << start_node - current_dict
#endif
	   << "\""
	   << endl
	   << "    targetname: \"n"
#ifdef FLEXIBLE
	   << tr_next_node(current_dict, next_node).arc - current_dict
#else
	   << tr_next_node(current_dict, next_node) - current_dict
#endif
	   << "\""
	   << endl
	   << "    label: \"" << tr_get_surf(next_node) << "/"
	   << tr_get_lex(next_node) << (tr_get_final(next_node) ? "!" : "")
	   << "\"" << endl
	   << "  }" << endl << endl;
    }
#if defined(FLEXIBLE) && defined(STOPBIT) && defined(NEXTBIT)
    // see if we are not too far because of the next bit
    if (*(next_node.arc - next_node.size + GOTO_OFFSET) & NEXT_BIT_MASK) {
      // correct current_offset
      next_node.arc -= (next_node.gtl - 1);
    }
#endif
#ifdef FLEXIBLE
    current_offset = next_node.arc - current_dict;
#else
    current_offset = next_node - current_dict;
#endif
    if (compressed)
      set_bit((start_node.arc - current_dict) / arc_size, visited);

    // Print edges of children
    next_node = tr_next_node(current_dict, start);
    //    for (int i = 0; i < kids; i++, tr_inc_next(next_node)) {
    forallnodes(j) {
      create_edges(next_node);
    }
  }
  return TRUE;
}//visual_tr::create_edges


/***	EOF visualize.cc	***/
