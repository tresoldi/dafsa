/***	commont.h	***/

/*	Copyright (c) Jan Daciuk, 1997	*/


const int	Max_word_len = 512;        /* max word length in input file */


const char	WORD_SEP		= '\t';
enum Bool	{FALSE, TRUE};

using namespace std;


const int	LIST_INIT_SIZE = 16;	/* initial list capacity */
const int	LIST_STEP_SIZE = 8;	/* list size increment */

struct dict_desc {
  tr_arc_ptr	dict;
  int		no_of_arcs;	/* number of arcs in the dictionary */
  int		gtl;		/* length of the goto field */
#ifndef STOPBIT
  int		ctl;		/* length of the counter field */
#endif
  int		size;		/* size of the arc */
  char		filler;		/* filler character */
  char		annot_sep;	/* annotation separator */
};/*dict_desc*/

/* Name:	comp
 * Class:	None.
 * Purpose:	Compare two list items.
 * Parameters:	it1		- (i) first item;
 *		it2		- (i) second item.
 * Returns:	< 0 if it1 < it2;
 *		= 0 if it1 = it2;
 *		> 0 if it1 > it2.
 * Remarks:	None.
 */
inline int
comp(const char *it1, const char *it2)
{
  return strcmp(it1, it2);
}/*comp*/

/* Name:	comp
 * Class:	None.
 * Purpose:	Compare two list items.
 * Parameters:	it1		- (i) first item;
 *		it2		- (i) second item.
 * Returns:	< 0 if it1 < it2;
 *		= 0 if it1 = it2;
 *		> 0 if it1 > it2.
 * Remarks:	Provided because needed by template.
 */
inline int
comp(const dict_desc *it1, const dict_desc *it2)
{
#if defined(FLEXIBLE)
  return (it1->dict.arc - it2->dict.arc);
#else
  return (it1->dict - it2->dict);
#endif
}/*comp*/


/* Name:	new_copy
 * Class:	None.
 * Purpose:	makes a copy of the item in dynamic memory.
 * Parameters:	it		- (i) item to be copied.
 * Returns:	The copy in dynamic memory.
 * Remarks:	None.
 */
inline char *
new_copy(const char *it)
{
  return nstrdup(it);
}/*new_copy*/

/* Name:	new_copy
 * Class:	None.
 * Purpose:	Makes a copy of the item in dynamic memory.
 * Parameters:	it		- (i) item to be copied.
 * Returns:	The copy in dynamic memory.
 * Remarks:	Actually, no copy is made here. It is not needed, as
 *		the copy is prepared before putting the item on the list.
 */
inline dict_desc *
new_copy(const dict_desc *it)
{
  dict_desc *dd = new dict_desc;
  memcpy(dd, it, sizeof(dict_desc));
  return dd;
}/*new_copy*/

/* Class name:	list
 * Purpose:	Implements basic list facility template.
 * Remarks:	Copies of items are put onto the list.
 */
template <class T>
class list {
protected:
  T	**items;	/* list items */
  T	**next_item;	/* current item */
  int	no_of_items;	/* number of items on the list */
  int	allocated;	/* max number of items allowed without reallocation*/
  int	c;		/* this must be declared here - bugs in compilers */

  void add_item(const T *new_item, T **where_to_add) {
    if (no_of_items >= allocated) {
      allocated += LIST_STEP_SIZE;
      next_item = new T *[allocated];
      memcpy(next_item, items, no_of_items * sizeof(T *));
      where_to_add = (where_to_add - items) + next_item;
      delete [] items;
      items = next_item;
    }
    for (next_item = items + no_of_items - 1; next_item >= where_to_add;
	 --next_item)
      next_item[1] = *next_item;
    next_item = where_to_add;
    no_of_items++;
    *next_item = new_copy(new_item);
  }
public:
  list(void) { next_item = items = new T *[allocated = LIST_INIT_SIZE];
	       no_of_items = 0; }
  ~list(void) { delete [] items; }
  operator int(void) const { return (no_of_items != 0); }
  void insert(const T *new_item) { add_item(new_item, items + no_of_items); }
  int insert_sorted(const T *new_item) {
    for (next_item = items; next_item < items + no_of_items; next_item++) {
      if ((c = comp(new_item, *next_item)) > 0) {
	/* item not on the list - add a new one */
	add_item(new_item, next_item);
	return TRUE;
      }
      else if (c == 0) {
	/* item found, no need to insert it */
	return FALSE;
      }
    }
    /* item not found, insert it */
    add_item(new_item, next_item);
    return TRUE;
  }
  T **start(void) const { return items; }
  void reset(void) { next_item = items; }
  void empty_list(void) {
    delete [] items; next_item = items = new T *[allocated = LIST_INIT_SIZE];
    no_of_items = 0;
  }
  T *item(void) const { return ((next_item < items + no_of_items) ?
				*next_item : ((T *)NULL)); }
  T *next(void) {
    if (next_item++ < items + no_of_items-1) {
      return *next_item;
    }
    else
      return (T *)NULL;
  }
  int how_many(void) const { return no_of_items; }
};/*class list*/

typedef		list<dict_desc>		dict_list;
typedef		list<char>		word_list;


/* Class name:	tr_io
 * Purpose:	Provide a class for input and output handling.
 * Methods:	tr_io		- initialize;
 *		~tr_io		- deallocate memory;
 *		>>		- read word from input;
 *		print_OK	- do something when word found (in spelling);
 *		print_not_found	- do something when word (& replacements)
 *					not found;
 *		print_repls	- print replacements for the word;
 *		print_morph	- print word morphology;
 *		int		- return state of the last stream used;
 * Fields:	input		- input stream;
 *		output		- output stream;
 *		proc_state	- state of input processing;
 *		stream_state	- state of i/o;
 *		buffer		- input buffer;
 *		word_syntax	- which characters constitute a part of word;
 *		Max_line_len	- max length of input lines.
 * Remarks:	Operator>> must make sure that the returned string does not
 *		exceed Max_word_len.
 */
class tr_io {
  istream	*input;
  ostream	&output;
  int		proc_state;
  int		stream_state;
  char		*buffer;
  /*  const char	*word_syntax;*/
  int		Max_line_len;
public:
  tr_io(istream *in_file, ostream &out_file, const int max_line_length,
	const char *word_chars = NULL);
  ~tr_io(void);
  tr_io &operator>>(char *s);
  tr_io &print_OK(void);
  tr_io &print_not_found(void);
  tr_io &print_repls(word_list *r);
  tr_io &print_morph(word_list *s);
  operator int(void) const { return stream_state; }
};/*tr_io*/



/* Class name:	tr
 * Purpose:	Provide an environment for programs using transducers.
 * Remarks:	This class is a base for more sophisticated classes.
 */
class tr {
protected:
  /* List of dictionaries (transducers) used by the program */
  dict_list		dictionary;

  /* Currently used dictionary (transducer) from dict_list */
  tr_arc_pointer		current_dict;

  /* List of words found in the dictionary (transducer), e.g. replacements
     in the spelling or diacritic restoration process, lexemes and tags
     for morphology program, etc. */
  word_list		replacements;

  /* State of the process */
  int			state;

  /* Buffer for composing words found in the dictionary */
  char			candidate[Max_word_len];

  /* Buffer to build lexical string */
  char			lex_cand[Max_word_len];

  /* Length of the word that is search for in the dictionary */
  int			word_length;

  /* Word that is searched */
  char			*word_ff;

  /* Case conversion table */
  char			casetab[256];	/* case conversion table */

  /* Description of characters (what forms a word) */
  char                  *word_syntax;

  /* "Empty" character, a character that is ignored, i.e. deleted when
     constructing a list of words from the dictionary. It is used because
     the strings from different levels may be of different length, so
     padding is needed. Sometimes it is better to pad inside words. */
  char			FILLER;

  /* A character than separates lexical entry from annotations (tags).
     Not used here, i.e. the character may be present at the lexical
     level, but it is printed as is - no processing is done. */
  char			annot_sep;



  /* Read dictionary (transducer) from a file dict_file_name */
  int read_fsa(const char *dict_file_name);

  /* Returns TRUE if the word is in a dictionary (all dictionaries) */
  int word_in_dictionary(const char *word, tr_arc_ptr start);
  int word_in_dictionaries(const char *word);
  void set_dictionary(dict_desc *dict);
  int read_language_file(const char *file_name);
public:
  /* Initialize */
  tr(word_list *dict_names, const char *language_file = NULL);
  /* Delete unused memory */
  ~tr(void) { }
  /* Return state of the transducer processing process */
  operator int(void) const {return state; }
};/*tr*/


/***	EOF commont.h	***/
