/***	visualize.h	***/

/*	Copyright (c) Jan Daciuk, 1998	*/


/* Class name:	prefix_tr
 * Purpose:	Provides an environment for programs creating graphs
 *		from dictionaries.
 * Remarks:
 */
class visual_tr : public tr {
protected:
  int current_offset;		/* what arcs already processed */
  int compressed;		/* whether dictionary produced with -O */
  int no_of_arcs;		/* number of arcs in the transducer */
  unsigned char *visited;	/* what arcs visited so far (only for
				   compressed dictionaries) */
  int arc_size;			/* 1 for not flexible, arc size for flexible */

#ifdef NUMBERS
  int words_in_node(fsa_arc_ptr start);
#endif
  int create_node(tr_arc_ptr start);
  int create_edges(tr_arc_ptr start);
public:
  visual_tr(word_list *dict_names);
  ~visual_tr(void) {};
  int create_graphs(void);
};/*class visual_tr*/

/***	EOF visualize.h	***/
