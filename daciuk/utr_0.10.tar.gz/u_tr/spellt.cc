/***	spell.cc	***/

/* Copyright (C) Jan Daciuk, 1996 */


#include	<iostream>
#include	<fstream>
#include	<string.h>
#include	<stdlib.h>
#include	<new>
#include	"tr.h"
#include	"nstr.h"
#include	"commont.h"
#include	"spellt.h"

static const int        Buf_len = 256;  // Buffer length for chclass file

/*	simple inline utilities	*/

inline int
min(const int a, const int b);
inline int
min(const int a, const int b)
{
  return ((a < b) ? a : b);
}//min
inline int
min(const int a, const int b, const int c);
inline int
min(const int a, const int b, const int c)
{
  return min(a, min(b, c));
}//min
inline int
max(const int a, const int b);
inline int
max(const int a, const int b)
{
  return (a > b ? a : b);
}//max
int
m_abs(const int x);
int
m_abs(const int x)
{
  return (x < 0 ? -x : x);
}//m_abs



typedef		list<ranked_hits>	hit_list;





/* Name:	H_matrix
 * Class:	H_matrix
 * Purpose:	Allocates memory and initializes matrix (constructor).
 * Parameters:	distance	- (i) max edit distance allowed for candidates;
 *		max_length	- (i) max length of words.
 * Returns:	Nothing.
 * Remarks:	See Oflazer. To save space, the matrix is stored as a vector.
 *		To save time, additional raws and columns are added.
 *		They are initialized to their distance in the matrix, so
 *		that no bound checking is necessary during access.
 */
H_matrix::H_matrix(const int distance, const int max_length)
{
  row_length = max_length + 2;
  column_height = 4 * distance + 1;
  edit_distance = distance;
  int size = row_length * column_height;
  p = new int[size];
  // Initialize edges of the diagonal band to distance + 1 (i.e. distance
  // too big)
  for (int i = 0; i < row_length - distance - 1; i++) {
    p[i] = distance + 1;		// H(distance + j, j) = distance + 1
    p[size - i - 1] = distance + 1;	// H(i, distance + i) = distance + 1
  }
  // Initialize items H(i,j) with at least one index equal to zero to |i - j|
  for (int j = 0; j < 4 * distance; j++) {
    p[j * row_length] = distance + 1 - j;	// H(i=0..distance+1,0)=i
    p[(j + distance + 1) * row_length + j] = j;	// H(0,j=0..distance+1)=j
  }
#ifdef DEBUG
  cerr << "Edit distance is " << edit_distance << "\n";
#endif
}//H_matrix::H_matrix

/* Name:	operator()
 * Class:	H_matrix
 * Purpose:	Provide an item of H_matrix indexed by indices.
 * Parameters:	i		- (i) row number;
 *		j		- (i) column number.
 * Returns:	Item H[i][j].
 * Remarks:	H matrix is really simulated. What is needed is only
 *		2 * edit_distance + 1 wide band around the diagonal.
 *		In fact this diagonal has been pushed up to the upper border
 *		of the matrix.
 */
int
H_matrix::operator()(const int i, const int j)
{
  return p[(j - i + edit_distance + 1) * row_length + j];
}//H_matrix::operator()

/* Name:	set
 * Class:	H_matrix
 * Purpose:	Set an item in H_matrix.
 * Parameters:	i		- (i) row number;
 *		j		- (i) column number;
 *		val		- (i) value to put there.
 * Returns:	Nothing.
 * Remarks:	Previously operator() returned int &, but the problem was
 *		that sometimes the values returned were computed,
 *		so one item in the matrix was chosen to store them.
 *		However, if they appeared in one expression, they were
 *		all the same variable. So now we have get & set.
 *
 *		No checking for i & j is done. They must be correct.
 */
void
H_matrix::set(const int i, const int j, const int val)
{
  p[(j - i + edit_distance + 1) * row_length + j] = val;
}//H_matrix::set



/* Name:	comp_cost
 * Class:	None.
 * Purpose:	Compares two ranked_hits structures on cost.
 * Parameters:	rh1		- (i) first structure;
 *		rh2		- (i) second structure.
 * Returns:	< 0 if rh1 < rh2
 *		= 0 if rh1 = rh2
 *		> 0 if rh1 > rh2.
 * Remarks:	Parameters must have the void pointer type for compatibility.
 */
int
comp_cost(const void *rh1, const void *rh2)
{
  return (((ranked_hits **)(rh1))[0]->cost - ((ranked_hits **)(rh2))[0]->cost);
}/*comp_cost*/

/* Name:	spell_tr
 * Class:	spell_tr (constructor).
 * Purpose:	Open dictionary files and read automata from them.
 * Parameters:	dict_names	- (i) dictionary file names;
 *		distance	- (i) max edit distance of replacements;
 *		language_file	- (i) file containing information about
 *					characters forming words, esp.
 *					about their case;
 *		chsub_file	- (i) file containing information about
 *					equivalent character sequences.
 * Returns:	Nothing.
 * Remarks:	At least one dictionary file must be read.
 *		If language file not present, standard case conversions
 *		(i.e. those for English and Latin) are used.
 *		If chsub_file not present, only typos are corrected.
 */
spell_tr::spell_tr(word_list *dict_names, const int distance,
		   const char *language_file, const char *chsub_file)
: tr(dict_names, language_file), H(distance, Max_word_len)
{
  edit_dist = distance;
#ifdef CHCLASS
  read_ch_seq_equiv(chsub_file);
#endif
}//spell_tr::spell_tr

/* Name:	spell_file
 * Class:	spell_tr
 * Purpose:	Launch a spelling process for a given file.
 * Parameters:	distance	- (i) edit distance;
 *		io_obj		- (i/o) where to read words,
 *					and where to print them.
 * Returns:	Exit code.
 * Remarks:	Edit distance is reduced for shorter words.
 *		No attempt is being made to correct one-letter words.
 */
int
spell_tr::spell_file(const int distance, tr_io &io_obj)
{
  char		word_buffer[Max_word_len];
  char		*word = &word_buffer[0];

  edit_dist = distance;
  while (io_obj >> word) {
    word_length = strlen(word); word_ff = word;
    if (word_length < 1) {
      cerr << " not checked (too short)\n";
      continue;
    }
    e_d = (word_length <= distance ? (word_length - 1) : distance);
    if (spell_word(word))
      io_obj.print_OK();
    else if (replacements) {
      io_obj.print_repls(&replacements);
      replacements.empty_list();
    }
    else
      io_obj.print_not_found();
  }
  return state;
}//spell_tr::spell_file

      
/* Name:	spell_word
 * Class:	spell_tr
 * Purpose:	Finds if a word is in the dictionary, and if not, provides
 *		replacements.
 * Parameters:	word	- (i) word to be checked.
 * Returns:	TRUE	- if word found, FALSE otherwise.
 * Remarks:	Class variable `replacements' is set to list of replacements.
 *		current_dict + 1 means  we start from arc #1, which is
 *		meta root, i.e. it contains the address and the number of
 *		arcs of the fsa's root.
 *		The list of replacements may contain words of identical
 *		spellings. This is because they are derived from different
 *		cannonical (lexical) forms.
 */
int
spell_tr::spell_word(const char * word)
{
  dict_list		*dict;
#ifdef CASECONV
  char			saved_char;
#endif

  if (word_in_dictionaries(word))
    return TRUE;

  for (dict = &dictionary; dict->item(); dict->next()) {
    set_dictionary(dict->item());
#ifdef CHCLASS
    find_repl(0, tr_first_node(current_dict), 0, 0);
#else
    find_repl(0, tr_first_node(current_dict));
#endif
#ifdef CASECONV
    if (word_syntax[(unsigned char)*word] == 2) {
      saved_char = *word;
      *((char *)word) = casetab[(unsigned char)*word];
#ifdef CHCLASS
      find_repl(0, tr_first_node(current_dict), 0, 0);
#else
      find_repl(0, tr_first_node(current_dict));
#endif
      *((char *)word) = saved_char;
    }
#endif
  }

#ifdef RUNON_WORDS
  find_runon(word);
#endif

  if (results) {
    rank_replacements();
  }

#ifdef CASECONV
  // Convert case of replacements to uppercase if the original was uppercase
  if (word_syntax[(unsigned char)*word] == 2) {
    replacements.reset();
    for (;replacements.item(); replacements.next()) {
      if (word_syntax[(unsigned char)(replacements.item()[0])] == 3) {
	// Word is lowercase - convert to uppercase
	replacements.item()[0] =
          casetab[(unsigned char)(replacements.item()[0])];
      }
    }
  }
#endif
  return FALSE;
}//spell_tr::spell_word


#ifdef RUNON_WORDS
/* Name:	find_runon
 * Class:	spell_tr
 * Purpose:	Split the word in two, and check if the resulting words
 *		are in the dictionary.
 * Parameters:	word		- (i) the word to be checked.
 * Returns:	Results.
 * Remarks:	This could be simpler, but speed was at stake.
 *		The present version does not check the case.
 *		It is assumed that no fillers are used.
 */
hit_list *
spell_tr::find_runon(const char *word)
{
  ranked_hits	word_found;
  tr_arc_ptr	start_node;
  tr_arc_ptr	next_node;
  int		kids;
  tr_arc_ptr	*dummy;		// to get to static fields
  tr_arc_ptr	local_dict;	// local to this function,
  				// as word_in_dictionary could change it

  if (word_length > 1 && e_d > 0) {
    for (int i = 0; i < dictionary.how_many(); i++) {
      // Prepare dictionary
      dictionary.reset();
      for (int ii = 0; ii < i; ii++)
	dictionary.next();
      local_dict = dictionary.item()->dict;
      FILLER = dictionary.item()->filler;
#ifdef FLEXIBLE
      dummy->gtl = dictionary.item()->gtl;
      dummy->size = dummy->gtl + 2;
#endif
      next_runon(word, tr_first_node(local_dict), 1);
#ifdef CASECONV
      if (word_syntax[(unsigned char)*word] == 2) {
	saved_char = *word;
	*((char *)word) = casetab[(unsigned char)*word];
	next_runon(word, tr_first_node(local_dict), 1);
	*((char *)word) = saved_char;
      }
#endif

    }
  }
  return &results;
}//spell_tr::find_runon

/* Name:	next_runon
 * Class:	spell_tr
 * Purpose:	Try next letter in the first word of the pair of words
 *		allegedly concatenated.
 * Parameters:	word		- (i) the whole word (consisting of two);
 *		start		- (i) the starting node of the search
 *					for the first word;
 *		ind		- (i) how many letters of `word' belong
 *					to the first word.
 * Returns:	Nothing.
 * Remarks:	None.
 */
void
spell_tr::next_runon(const char *word, tr_arc_ptr start, const int ind)
{
  int 		kids;
  tr_arc_ptr	next_node;

  next_node = tr_next_node(local_dict, start);
  kids = fsa_children(start);
  // Find last letter of the first word
  // (all previous letters must have already been found)
  for (int k = 0; k < kids; k++, tr_inc_next(next_node)) {
    if (tr_get_letter(next_node) == word[j - 1]) {
      if (tr_is_final(next_node) &&
	  word_in_dictionary(word + j, tr_first_node(local_dict))) {
	// Prepare words
	// candidate contains two words formed by inserting a space into
	// the word
	strcpy(candidate + j + 1, word + j);
	strncpy(candidate, word, j);
	candidate[j] = ' ';
	word_found.list_item = nstrdup(candidate);
	word_found.dist = 1;
	word_found.cost = 1;		// for the moment
	results.insert_sorted(&word_found);
      }
      if (j < word_length - 1)
	next_runon(word, next_node, j + 1);
    }
    else if (tr_get_letter(next_node) == FILLER) {
      next_runon(word, next_node, j);
    }
  }
}
	
  
#endif

#ifdef CHCLASS
/* Name:	read_ch_seq_equiv
 * Class:	spell_tr
 * Purpose:	Read file with character classes and prepare tables.
 * Parameters:	a_file		- (i) name of file with class descriptions.
 * Returns:	TRUE if file read successfully, FALSE otherwise.
 * Remarks:	The format of the character class file is as follows:
 *			The first character in the first line is a comment
 *			character. Each line that begins with that character
 *			is a comment.
 *			Note: it is usually `#' or ';'.
 *
 *			Data lines contain two columns. The columns contain
 *			one or two characters. The sum of the characters
 *			from both columns must be 3 (1+2 or 2+1). The columns
 *			must be separated by spaces or tabs.
 *			The first column represents what may occur in text.
 *			The second column represents what should be there.
 *			Those definitions do not affect recognition of errors.
 *			They make the list of possible replacements longer.
 *			Characters are represented by themselves, the file
 *			is binary.
 *		The format of the character class tables:
 *			A table contains 256 pointers to strings. One letter
 *			column character is the index to a string of pairs
 *			of characters taken from the other column.
 *
 *			If the length of the first column in the file is 1,
 *			the data for that line is written into first_column
 *			table, otherwise it is written into second_column
 *			table.
 *			All other characters are represented by themselves.
 *
 *		It is possible to invoke the function with empty (NULL)
 *		file name. This creates empty, but valid first_column and
 *		second_column.
 *
 *		Note: Line length is not checked, though buffer overflow
 *		is not a danger here.
 */
int
spell_tr::read_ch_seq_equiv(const char *file_name)
{
  int		i, j, k;
  char		comment_char;
  char		junk;
  unsigned char	buffer[Buf_len];
  char		seq_buf[Buf_len];

  // allocate memory for character class tables and initialize them
  first_column = new char *[256];
  second_column = new char *[256];
  for (i = 0; i < 256; i++) {
    first_column[i] = NULL; second_column[i] = NULL;
  }

  // See if a file is specified
  if (file_name == NULL)
    return FALSE;

  // open character class file
  ifstream chcl_f(file_name, ios::in /*| ios::nocreate */);
  if (chcl_f.bad()) {
    cerr << "Cannot open character class file `" << file_name << "'\n";
    return FALSE;
  }

  // Recognize comment character
  if (chcl_f.get((char *)buffer, Buf_len, '\n'))
    comment_char = buffer[0];
  else
    return FALSE;
  chcl_f.get(junk);

  // Process lines
  while (chcl_f.get((char *)buffer, Buf_len, '\n')) {
    chcl_f.get(junk);
    if (buffer[0] != comment_char) {	// Data line
      // first column
      for (i = 0; buffer[i] != ' ' && buffer[i] != '\t' && buffer[i]; i++)
	;
      // now i points to the character imediately behind the first column
      for (j = i; buffer[j] == ' ' || buffer[j] == '\t'; j++)
	;
      // now j points to the first character of the second column
      for (k = j; buffer[k] && buffer[k] != ' ' && buffer[k] != '\t'; k++)
	;
      // now k points to the first character behind the second column
      if (i == 1 && k - j == 2) {
	seq_buf[0] = buffer[j];
	seq_buf[1] = buffer[j+1];
	if (first_column[buffer[0]]) {
	  if (strlen(first_column[buffer[0]]) < Buf_len - 3) {
	    strcpy(seq_buf + 2, first_column[buffer[0]]);
	    delete [] first_column[buffer[0]];
	  }
	  else {
	    cerr << "Too many equivalent sequences. Ignored" << endl;
	  }
	}
	else
	  seq_buf[2] = '\0';
	first_column[buffer[0]] = nstrdup(seq_buf);
      }
      else if (i == 2 && k - j == 1) {
	seq_buf[0] = buffer[0];
	seq_buf[1] = buffer[1];
	if (second_column[buffer[j]]) {
	  if (strlen(second_column[buffer[j]]) < Buf_len - 3) {
	    strcpy(seq_buf + 2, second_column[buffer[j]]);
	    delete [] first_column[buffer[j]];
	  }
	  else {
	    cerr << "Too many equivalent sequences. Ignored" << endl;
	  }
	}
	else
	  seq_buf[2] = '\0';
	second_column[buffer[j]] = nstrdup(seq_buf);
      }
      else {
	cerr << "Illegal format in the following line from " << file_name
	  << endl << buffer << endl;
      }
    }
  }
  return TRUE;
}//spell_tr::read_ch_seq_equiv



/* Name:	match_candidate
 * Class:	spell_tr
 * Purpose:	Match two last letters of the candidate against the penultimate
 *		letter of the word.
 * Parameters:	i		- (i) current index of the word;
 *		j		- (j) current index of the candidate.
 * Result:	TRUE if letters match, FALSE otherwise.
 * Remarks:	first_column is a vector of strings with indices being
 *		characters. The strings are normally empty, but for single
 *		letters specified in the first column in the character class
 *		files, they contain one or more equivalent pairs of characters.
 */
int
spell_tr::match_candidate(const int i, const int j)
{
  char	*c;
  char	c0, c1;

  if (i > 0 && (c = first_column[(unsigned char)(word_ff[i-1])]) && j > 0)
    for (c0 = candidate[j-1], c1 = candidate[j]; *c; c+= 2)
      if (c[0] == c0 && c[1] == c1)
	return TRUE;
  return FALSE;
}//spell_tr::match_candidate

/* Name:	match_word
 * Class:	spell_tr
 * Purpose:	Match this and the next letter of the word against the last
 *		letter of the candidate.
 * Parameters:	i		- (i) current index of the word;
 *		j		- (i) current index of the candidate.
 * Result:	TRUE if letters match, FALSE otherwise.
 * Remarks:	second_column is a vector of strings with indices being
 *		characters. The strings are normally empty, but for single
 *		letters specified in the second column in the character class
 *		files, they contain one or more equivalent pairs of characters.
 */
int
spell_tr::match_word(const int i, const int j)
{
  char	*c;
  char	c0, c1;

  if ((c = second_column[(unsigned char)(candidate[j])]))
    for (c0 = word_ff[i], c1 = word_ff[i+1]; *c; c += 2)
      if (c[0] == c0 && c[1] == c1)
	return TRUE;
  return FALSE;
}//spell_tr::match_word


/* Name:	find_repl
 * Class:	spell_tr
 * Purpose:	Create a list of candidates for a misspelled word.
 * Parameters:	depth		- (i) current length of replacements;
 *		start		- (i) look at children of that node;
 *		word_index	- (i) index of the next character to be
 *					considered in word_ff;
 *		cand_index	- (i) index of the next character in candidate
 *					to be considered.
 * Returns:	TRUE if candidates found, FALSE otherwise.
 * Remarks:	A (partial) list of candidates is stored in results.
 *		See Kemal Oflazer - "Error-tolerant Finite State Recognition
 *		with Applications to Morphological Analysis and Spelling
 *		Correction", cmp-lg/9504031. Modified.
 *		This contains modifications for classes of strings.
 *		The idea is to treat replacing one string of characters for
 *		another string representing the same (or very similar) sound
 *		as a simple (one-character) replacement. This constitutes an
 *		orthographic (not typographic) error.
 *		Typos happen when one knows how to spell the word,
 *		but hits the wrong key. Orthographic errors happen when
 *		one does not know how to spell the word. E.g. in Polish,
 *		`rz' and `\.z' (z with a dot above - one letter) sound exactly
 *		the same, and one must remember the correct spelling.
 *		As the number of people with their brains damaged by the TV
 *		increases, this type of errors must be taken into
 *		consideration.
 */
hit_list *
spell_tr::find_repl(const int depth, tr_arc_ptr start,
		     const int word_index, const int cand_index)
{
  tr_arc_ptr next_node = tr_next_node(current_dict, start);
  int		dist = 0;
  ranked_hits	word_found;
  //  int		kids = tr_get_children(start);

  //  for (int i = 0; i < kids; i++, tr_inc_next(next_node)) {
  forallnodes(i) {
    candidate[cand_index] = tr_get_surf(next_node);
    if (match_candidate(word_index, cand_index)) {
      // The last two letters from candidate, and the previous letter
      // from word_ff match
      find_repl(depth, next_node, word_index, cand_index + 1);
      if (m_abs(word_length - 1 - depth) <= e_d &&
	  tr_get_surf_final(next_node) &&
	  (dist = ed(word_length - 2 - (word_index - depth), depth - 2,
		     word_length - 2, cand_index - 2)) + 1 <= e_d) {
	candidate[cand_index + 1] = '\0';	// restore candidate's length
	word_found.list_item = nstrdup(candidate);
	word_found.dist = dist;
	word_found.cost = dist;		// for the moment
	results.insert_sorted(&word_found);
      }
    }
    if (cuted(depth, word_index, cand_index) <= e_d) {
      find_repl(depth + 1, next_node, word_index + 1, cand_index + 1);
      if (match_word(word_index, cand_index)) {
	find_repl(depth + 1, next_node, word_index + 2, cand_index + 1);
	if (m_abs(word_length - 1 - depth) <= e_d &&
	    tr_get_surf_final(next_node) &&
	    (word_length > 2 && match_word(word_length - 2, cand_index) &&
	     (dist = ed(word_length - 3 - (word_index - depth), depth - 1,
			word_length - 3, cand_index -1) + 1) <= e_d)) {
	  word_found.list_item = nstrdup(candidate);
	  word_found.dist = dist;
	  word_found.cost = dist;		// for the moment
	  results.insert_sorted(&word_found);
	}
      }
      candidate[cand_index + 1] = '\0';		// restore candidate's length
      if (m_abs(word_length - 1 - depth) <= e_d &&
	  tr_get_surf_final(next_node) &&
	  (dist = ed(word_length - 1 - (word_index - depth), depth,
		     word_length - 1, cand_index) <= e_d)) {
	word_found.list_item = nstrdup(candidate);
	word_found.dist = dist;
	word_found.cost = dist;		// for the moment
	results.insert_sorted(&word_found);
      }
    }
  }
  return &results;
}//spell_tr::find_repl


/* Name:	ed
 * Class:	spell_tr
 * Purpose:	Calculates edit distance.
 * Parameters:	i		-(i) length of first word (here: misspelled)-1;
 *		j		-(i) length of second word (here: candidate)-1;
 *		word_index	-(i) first word character index;
 *		cand_index	-(i) second word character index
 * Returns:	Edit distance between the two words.
 * Remarks:	See Oflazer.
 */
int
spell_tr::ed(const int i, const int j, const int word_index,
	      const int cand_index)
{
  int	result;
  int	a, b, c;	// not really necessary: tradition int &H::operator()

#ifdef DEBUG
  cerr << "Calculating ed(" << i << ", " << j << ")\n";
#endif
  if (word_ff[word_index] == candidate[cand_index]) {
    // last characters are the same
    result = H(i, j);
  }
  else if (word_index > 0 && cand_index > 0 &&
	   word_ff[word_index] == candidate[cand_index - 1] &&
	   word_ff[word_index - 1] == candidate[cand_index]) {
    // last two characters are transposed
    a = H(i - 1, j - 1);	// transposition, e.g. ababab, ababba
    b = H(i + 1, j);		// deletion,      e.g. abab,   aba
    c = H(i, j + 1);		// insertion      e.g. aba,    abab
    result = 1 + min(a, b, c);
  }
  else {
    // otherwise
    a = H(i, j);		// replacement,   e.g. ababa,  ababb
    b = H(i + 1, j);		// deletion,      e.g. ab,     a
    c = H(i, j + 1);		// insertion      e.g. a,      ab
    result = 1 + min(a, b, c);
  }

#ifdef DEBUG
  cerr << "ed(" << i << ", " << j << ") = " << result << "\n";
#endif
  H.set(i + 1, j + 1, result);
  return result;
}//spell_tr::ed

/* Name:	cuted
 * Class:	spell_tr
 * Purpose:	Calculates cut-off edit distance.
 * Parameters:	depth		- (i) current length of candidates;
 *		word_index	- (i) index of the next character in word;
 *		cand_index	- (i) index of the next character in candidate.
 * Returns:	Cut-off edit distance.
 * Remarks:	See Oflazer.
 */
int
spell_tr::cuted(const int depth, const int word_index, const int cand_index)
{
  int l = max(0, depth - e_d);		// min chars from word to consider - 1
  int u = min(word_length-1 - (word_index - depth),
	      depth + e_d);		// max chars from word to consider - 1
  int min_ed = e_d + 1;			// what is to be computed
  int wi = word_index + l - depth;
  int d;

#ifdef DEBUG
  cerr << "cuted(" << depth << ")\n";
#endif
  for (int i = l; i <= u; i++, wi++) {
    if ((d = ed(i, depth, wi, cand_index)) < min_ed)
      min_ed = d;
  }

#ifdef DEBUG
  cerr << "cuted(" << depth << ") = " << min_ed << "\n";
#endif
  return min_ed;
}//spell_tr::cuted

#else

/* Name:	find_repl
 * Class:	spell_tr
 * Purpose:	Create a list of candidates for a misspelled word.
 * Parameters:	depth		- (i) current length of replacements;
 *		start		- (i) look at children of that node.
 * Returns:	(Partial) list of candidates.
 * Remarks:	See Kemal Oflazer - "Error-tolerant Finite State Recognition
 *		with Applications to Morphological Analysis and Spelling
 *		Correction", cmp-lg/9504031. Modified.
 */
hit_list *
spell_tr::find_repl(const int depth, tr_arc_ptr start)
{
  tr_arc_ptr	next_node = tr_next_node(current_dict, start);
  int		dist = 0;	// = 0 only to get rid of annoying compiler msg
  ranked_hits	word_found;
  int 		kids = tr_get_children(start);

#ifdef DEBUG
  cerr << "Level " << depth << "\n";
#endif
  for (int i = 0; i < kids; i++, tr_inc_next(next_node)) {
    if (tr_get_surf(next_node) == FILLER) {
      find_repl(depth, next_node);
    }
    else {
      candidate[depth] = tr_get_surf(next_node);
      candidate[depth + 1] = '\0';
#ifdef DEBUG
      cerr << "Candidate is `" << candidate << "'\n";
#endif
      if (cuted(depth) <= e_d) {
	find_repl(depth + 1, next_node);
	candidate[depth + 1] = '\0';	// restore candidate's length

	if (m_abs(word_length - 1 - depth) <= e_d &&
	    (dist = ed(word_length - 1, depth)) <= e_d &&
	    tr_get_surf_final(next_node)) {
#ifdef DEBUG
	  cerr << "Found: `" << candidate << "'\n";
#endif
	  word_found.list_item = nstrdup(candidate);
	  word_found.dist = dist;
	  word_found.cost = dist;		// for the moment
	  results.insert_sorted(&word_found);
	}
      }
    }
  }
  return &results;
}//spell_tr::find_repl

/* Name:	ed
 * Class:	spell_tr
 * Purpose:	Calculates edit distance.
 * Parameters:	i		-(i) length of first word (here: misspelled)-1;
 *		j		-(i) length of second word (here: candidate)-1.
 * Returns:	Edit distance between the two words.
 * Remarks:	See Oflazer.
 */
int
spell_tr::ed(const int i, const int j)
{
  int	result;
  int	a, b, c;	// not really necessary: tradition int &H::operator()

#ifdef DEBUG
  cerr << "Calculating ed(" << i << ", " << j << ")\n";
#endif
  if (word_ff[i] == candidate[j]) {
    // last characters are the same
    result = H(i, j);
  }
  else if (i > 0 && j > 0 && word_ff[i] == candidate[j - 1] &&
	   word_ff[i - 1] == candidate[j]) {
    // last two characters are transposed
    a = H(i - 1, j - 1);	// transposition, e.g. ababab, ababba
    b = H(i + 1, j);		// deletion,      e.g. aba,    abab
    c = H(i, j + 1);		// insertion      e.g. abab,   aba
    result = 1 + min(a, b, c);
  }
  else {
    // otherwise
    a = H(i, j),		// replacement,   e.g. ababa,  ababb
    b = H(i + 1, j);		// deletion,      e.g. a,      ab
    c = H(i, j + 1);		// insertion      e.g. ab,     a
    result = 1 + min(a, b, c);
  }

#ifdef DEBUG
  cerr << "ed(" << i << ", " << j << ") = " << result << "\n";
#endif
  H.set(i + 1, j + 1, result);
  return result;
}//spell_tr::ed

/* Name:	cuted
 * Class:	spell_tr
 * Purpose:	Calculates cut-off edit distance.
 * Parameters:	depth		- (i) current length of candidates.
 * Returns:	Cut-off edit distance.
 * Remarks:	See Oflazer.
 */
int
spell_tr::cuted(const int depth)
{
  int l = max(0, depth - e_d);		// min chars from word to consider - 1
  int u = min(word_length-1, depth+e_d);// max chars from word to consider - 1
  int min_ed = e_d + 1;			// what is to be computed
  int d;

#ifdef DEBUG
  cerr << "cuted(" << depth << ")\n";
#endif
  for (int i = l; i <= u; i++) {
    if ((d = ed(i, depth)) < min_ed)
      min_ed = d;
  }

#ifdef DEBUG
  cerr << "cuted(" << depth << ") = " << min_ed << "\n";
#endif
  return min_ed;
}//spell_tr::cuted
#endif


/* Name:	rank_replacements
 * Class:	spell_tr
 * Purpose:	Sort the list of candidates according to their cost.
 * Parameters:	None.
 * Returns:	TRUE if replacements found, FALSE otherwise.
 * Remarks:	Cost is neglected. To be corrected later.
 *		Cost should reflect relative frequency of errors.
 */
int
spell_tr::rank_replacements(void)
{
  if (results.how_many()) {
    results.reset();
    /* sort list of possible replacements */
    qsort(results.start(), results.how_many(), sizeof(ranked_hits *),
	  comp_cost);
    for (int i = 0; i < results.how_many(); results.next(), i++)
      replacements.insert(results.item()->list_item);

    results.empty_list();
    return TRUE;
  }
  return FALSE;
}//spell_tr::rank_replacements

/***	EOF spell.cc	***/
