/***	accentt.h	***/

/*	Copyright (c) Jan Daciuk, 1997	*/

/* Class name:	accent_tr
 * Purpose:	Provide an environment for diacritic restoration programs
 * Remarks:
 */
class accent_tr : public tr {
protected:
  /* For each character gives a character without diacritics */
  const char		*char_eq;
public:
  accent_tr(word_list *dict_names, const char *language_file = NULL);
  ~accent_tr(void) {};
  int accent_word(const char *word, const char *equiv);
  int word_accents(const char *word, const int level,
		   tr_arc_ptr start);
  int accent_file(tr_io &io_obj, const char *equiv);

};/*class accent_tr*/

/***	EOF accentt.h	***/
