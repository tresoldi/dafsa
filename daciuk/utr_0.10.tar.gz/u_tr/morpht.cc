/***	morpht.cc	***/

/*	Copyright (c) Jan Daciuk, 1997	*/


#include	<iostream>
#include	<fstream>
#include	<string.h>
#include	<stdlib.h>
#include	<new>
#include	"tr.h"
#include	"nstr.h"
#include	"commont.h"
#include	"morpht.h"




/* Name:	morph_tr
 * Class:	morph_tr (constructor).
 * Purpose:	Open dictionary files and read automata from them.
 * Parameters:	dict_names	- (i) dictionary file names;
 *		language_file	- (i) file with information about
 *					letter, esp. case.
 * Returns:	Nothing.
 * Remarks:	At least one dictionary file must be read.
 */
morph_tr::morph_tr(word_list *dict_names, const char *language_file)
: tr(dict_names, language_file)
{
}//morph_tr::morph_tr


/* Name:	morph_file
 * Class:	morph_tr
 * Purpose:	For each word in the file prints its morphology.
 * Parameters:	io_obj		- (i/o) where to read words,
 *					and where to print them.
 * Returns:	Exit code.
 * Remarks:	None.
 */
int
morph_tr::morph_file(tr_io &io_obj)
{
  char		word_buffer[Max_word_len];
  char		*word = &word_buffer[0];

  while (io_obj >> word) {
    if (morph_word(word)) {
      io_obj.print_morph(&replacements);
      replacements.empty_list();
    }
    else
      io_obj.print_not_found();
  }
  return state;
}//morph_tr::morph_file


/* Name:	gen_words_from_file
 * Class:	morph_tr
 * Purpose:	For each (lexem, category set) in file print inflected forms.
 * Parameters:	io_obj		- (i/o) where to read (lexeme, category set),
 *					and where to print them;
 *		ext_a_sep	- (i) character that separates lexeme from
 *					category set (tag) in the file read.
 * Returns:	Exit code.
 * Remarks:	None.
 */
int
morph_tr::gen_words_from_file(tr_io &io_obj, const char ext_a_sep)
{
  char		word_buffer[Max_word_len];
  char		*lextag = &word_buffer[0];

  while (io_obj >> lextag) {
    if (gen_word(lextag, ext_a_sep)) {
      io_obj.print_morph(&replacements);
      replacements.empty_list();
    }
    else
      io_obj.print_not_found();
  }
  return state;
}//morph_tr::gen_words_from_file



/* Name:	morph_word
 * Class:	morph_tr
 * Purpose:	Provides morphological information for the word from all
 *		dictionaries.
 * Parameters:	word	- (i) word of which we seek morphology.
 * Returns:	TRUE if morphological information for the word found,
 *		FALSE otherwise.
 * Remarks:	Morphological information is returned via replacements.
 */
int
morph_tr::morph_word(const char *word)
{
  dict_list		*dict;
#ifdef CASECONV
  char			saved_char;
#endif

  dictionary.reset();
  for (dict = &dictionary; dict->item(); dict->next()) {
    set_dictionary(dict->item());
    word_morphology(word, 0, tr_first_node(current_dict));
#ifdef CASECONV
    if (word_syntax[(unsigned char)*word] == 2) {
      // word is uppercase - try lowercase
      saved_char = *word;
      *((char *)word) = casetab[(unsigned char)*word]; // change to lowercase
      word_morphology(word, 0, tr_first_node(current_dict));
      *((char *)word) = saved_char; // restore original word
    }
#endif

  }

  return replacements.how_many();
}//morph_tr::morph_word



/* Name:	gen_word
 * Class:	morph_tr
 * Purpose:	Generates an inflected word given its lexeme and categories.
 * Parameters:	lextag		- (i) lexeme and a set of categories;
 *		ext_a_sep	- (i) separates lexeme from categories.
 * Returns:	TRUE ifan inlected form for the lexeme and categories found,
 *		FALSE otherwise.
 * Remarks:	Inflected form is returned via replacements.
 *		There may be more than one inflected form.
 *		In lextag, the lexeme is separated from the set of categories
 *		with a separator (ext_a_sep).
 */
int
morph_tr::gen_word(const char *lextag, const char ext_a_sep)
{
  dict_list		*dict;
  char			a_sep;
  char			*char_pos; // position of separator in lextag

  dictionary.reset();
  if ((char_pos = strchr(lextag, ext_a_sep)) == NULL) {
    cerr << "No tag separator in: `" << lextag << "'" << endl;
  }
  for (dict = &dictionary; dict->item(); dict->next()) {
    set_dictionary(dict->item());
    a_sep = dict->item()->annot_sep;
    if (char_pos)
      *char_pos = a_sep;		// change separator for this dictionary
    gen_word_char(lextag, 0, tr_first_node(current_dict));
  }

  return replacements.how_many();
}//morph_tr::gen_word



/* Name:	word_morphology
 * Class:	morph_tr
 * Purpose:	Provides morphological information associated with given word.
 * Parameters:	word		- (i) word to check;
 *		depth		- (i) current depth of search on lexical side;
 *		start		- (i) look at children of that node.
 * Returns:	TRUE if any morphological information found, FALSE otherwise.
 * Remarks:	What is returned is a list, because different lexical forms
 *		may give the same surface form. In other words, the same
 *		word can sometimes be interpreted as a noun, a verb, etc.
 */
int
morph_tr::word_morphology(const char *word, const int depth,
			  tr_arc_ptr start)
{
  tr_arc_ptr	next_node = tr_next_node(current_dict, start);
  int		curr_depth;
  //  int		kids = tr_get_children(start);

  //  for (int i = 0; i < kids; i++, tr_inc_next(next_node)) {
  forallnodes(i) {
    curr_depth = depth;
    candidate[curr_depth + 1] = '\0';
    if (*word == tr_get_surf(next_node)) {
      if (tr_get_lex(next_node) != FILLER)
	candidate[curr_depth++] = tr_get_lex(next_node);
      if (word[1] == '\0' && tr_get_surf_final(next_node))
	if (tr_get_final(next_node))
	  replacements.insert_sorted(candidate);
	else
	  rest_of_word_morphology(curr_depth, next_node);
      else
	word_morphology(word + 1, curr_depth, next_node);
    }
    else if (tr_get_surf(next_node) == FILLER) {
      if (tr_get_lex(next_node) != FILLER)
	candidate[curr_depth++] = tr_get_lex(next_node);
      word_morphology(word, curr_depth, next_node);
    }
  }
  return replacements.how_many();
}//morph_tr::word_morphology

/* Name:	rest_of_word_morphology
 * Class:	morph_tr
 * Purpose:	Find the rest of morphological information associated with
 *		a certain word.
 * Parameters:	depth		- (i) current length of morphological
 *					information;
 *		start		- (i) look at children of that node.
 * Returns:	TRUE if any information found, FALSE otherwise.
 * Remarks:	This is called when lexical word is longer then surface word.
 *		Results returned in replacements.
 */
int
morph_tr::rest_of_word_morphology(const int depth, tr_arc_ptr start)
{
  tr_arc_ptr	next_node = tr_next_node(current_dict, start);
  //  int		kids = tr_get_children(start);

  //  for (int i = 0; i < kids; i++, tr_inc_next(next_node)) {
  forallnodes(i) {
    candidate[depth + 1] = '\0';
    candidate[depth] = tr_get_lex(next_node);
    if (tr_get_surf(next_node) == FILLER) {
      if (tr_get_final(next_node))
	replacements.insert(candidate);
      else
	rest_of_word_morphology(depth + 1, next_node);
    }
  }
  return replacements.how_many();
}//morph_tr::rest_of_word_morphology



/* Name:	gen_word_char
 * Class:	morph_tr
 * Purpose:	Generates the next character of an inflected word
 *		given the lexeme and categories.
 * Parameters:	lextag		- (i) lexeme with categories;
 *		depth		- (i) current depth of search on surface side;
 *		start		- (i) look at children of that node.
 * Returns:	TRUE if any inlected form information found, FALSE otherwise.
 * Remarks:	What is returned is a list, because one lexeme with a given
 *		set of categories may have more than one inflected form.
 *		lextag has the form lexemeSEPtag, where lexee is the lexeme
 *		of the form to be generated, the tag is a set of categories
 *		the form to be generated must have, and SEP is a character
 *		that separates the lexeme from the categories.
 */
int
morph_tr::gen_word_char(const char *lextag, const int depth,
			tr_arc_ptr start)
{
  tr_arc_ptr	next_node = tr_next_node(current_dict, start);
  int		curr_depth;
  //  int		kids = tr_get_children(start);

  //  for (int i = 0; i < kids; i++, tr_inc_next(next_node)) {
  forallnodes(i) {
    curr_depth = depth;
    //    candidate[curr_depth + 1] = '\0';
    if (*lextag == tr_get_lex(next_node)) {
      if (tr_get_surf(next_node) != FILLER)
	candidate[curr_depth++] = tr_get_surf(next_node);
      if (lextag[1] == '\0' && tr_get_final(next_node)) {
	candidate[curr_depth] = '\0';
	replacements.insert_sorted(candidate);
      }
      else
	gen_word_char(lextag + 1, curr_depth, next_node);
    }
    else if (tr_get_lex(next_node) == FILLER) {
      if (tr_get_surf(next_node) != FILLER)
	candidate[curr_depth++] = tr_get_surf(next_node);
      if (lextag[1] == '\0' && tr_get_final(next_node)) {
	candidate[curr_depth] = '\0';
	replacements.insert_sorted(candidate);
      }
      else
	gen_word_char(lextag, curr_depth, next_node);
    }
  }
  return replacements.how_many();
}//morph_tr::gen_word_char

/***	EOF morpht.cc	***/
