#ifdef	CASECONV
      cout << "Compiled with CASECONV" << endl;
#endif
#ifdef	CHCLASS
      cout << "Compiled with CHCLASS" << endl;
#endif
#ifdef	FLEXIBLE
      cout << "compiled with FLEXIBLE" << endl;
#endif
#ifdef	JOIN_PAIRS
      cout << "Compiled with JOIN_PAIRS" << endl;
#endif
#ifdef	LOOSING_RPM
      cout << "Compiled with LOOSING_RPM" << endl;
#endif
#ifdef MONITOR_MEMORY
      cout << "Compiled with MONITOR_MEMORY" << endl;
#endif
#ifdef	MORE_COMPR
      cout << "Compiled with MORE_COMPR" << endl;
#endif
#ifdef	PROGRESS
      cout << "Compiled with PROGRESS" << endl;
#endif
#ifdef	RUNON
      cout << "Compiled with RUNON" << endl;
#endif
#ifdef SHOW_FILLERS
      cout << "Compiled with SHOW_FILLERS" << endl;
#endif
#ifdef	SORT_ON_FREQ
      cout << "Compiled with SORT_ON_FREQ" << endl;
#endif
#ifdef	STATISTICS
      cout << "Compiled with STATISTICS" << endl;
#endif
#ifdef	STOPBIT
      cout << "Compiled with STOPBIT" << endl;
#endif
