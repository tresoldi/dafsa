/***	prefixt.h	***/

/*	Copyright (c) Jan Daciuk, 1997	*/


/* Class name:	prefix_tr
 * Purpose:	Provides an environment for programs completing words
 *		from dictionaries.
 * Remarks:
 */
class prefix_tr : public tr {
public:
  prefix_tr(word_list *dict_names);
  ~prefix_tr(void) {};
  int complete_file_words(tr_io &io_obj);
  int complete_prefix(const char *word_prefix, tr_io &io_obj);
  int compl_prefix(const char *word_prefix, tr_io &io_obj, const int s_depth,
		   const int l_depth, tr_arc_ptr start);
  int compl_rest(tr_io &io_obj, const int s_depth, const int l_depth,
		 tr_arc_ptr start);
};/*class prefix_tr*/

/***	EOF prefixt.h	***/
