/***	tr_inp.h	***/

/*	Copyright (C) Jan Daciuk, 1996	*/

#ifndef		TR_INP_H
#define		TR_INP_H

/* Class name:	transd_inp
 * Purpose:	Handle input for building a transducer.
 * Methods:	transd_inp	- allocate memory;
 *		~transd_inp	- deallocate memory;
 *		get_surf_word	- returns surface string read (trailing FILLER
 *				  characters stripped off);
 *		get_lex_word	- returns lexical string read (trailing FILLER
 *				  characters stripped off);
 *		operator>>	- reads one line, and gets both strings.
 * Fields:	input_buffer	- where characters from input are read;
 *		surf_buffer	- where surface string is stored;
 *		lex_buffer	- where lexical string is stored.
 * Remarks:	It is possible to use differently formated data by simply
 *		changing the implementation of this class.
 */
using namespace std;

class transd_inp {
  char		*input_buffer;
  char		*surf_buffer;
  char		*lex_buffer;
  int		s_len;
  int		l_len;
  int		buf_len;	/* buffer length */
public:
  transd_inp(void);
  ~transd_inp(void);
  char *get_surf_word(void) const { return surf_buffer; }
  char *get_lex_word(void) const { return lex_buffer; }
  int surf_len(void) const { return s_len; }
  int lex_len(void) const { return l_len; }
  friend istream & operator>>(istream &in_file, transd_inp &tr_inp);
};/*class transd_inp*/

#endif

/***	EOF tr_inp.h	***/
