/***	build_main.cc	***/

/*	Copyright (C) Jan Daciuk, 1996	*/

/*

This program builds a transducer that recognizes words from
the dictionary that is an argument to the program.

See man page tr_ubuild(1) for details.
*/

#include	<new>
#include	<string.h>
#include	<iostream>
#include	<fstream>
#include	<stdlib.h>
#include	"tindex.h"
#include	"build_tr.h"
#include	"tr_version.h"

extern int idx_memory_all;
char	FILLER;			// fills empty spaces, default: '_'
char	INPUT_SEPARATOR;	// separates input items, default: '\t'
char	ANNOT_SEPARATOR;	// separates lex & annotations, default: '+'


/*	internal prototypes	*/
void
not_enough_memory(void);
int
main(const int argc, const char *argv[]);


/* Name:	not_enough_memory
 * Class:	None.
 * Purpose:	Inform the user that there is not enough memory to continue
 *		and finish the program.
 * Parameters:	None.
 * Returns:	Nothing.
 * Remarks:	None.
 */
void
not_enough_memory(void)
{
  cerr << "Not enough memory for the transducer\n";
  exit(4);
}//not_enough_memory

/* Name:	usage
 * Class:	None.
 * Purpose:	Prints program synopsis.
 * Parameters:	prog_name	- (i) program name.
 * Returns:	Nothing.
 * Remarks:	None.
 */
void
usage(const char *prog_name)
{
  cerr << prog_name
       << " is a filter.\nSynopsis:\n"
       << prog_name << " [options] [<infile] [>outfile]\nOptions:\n"
       << "-O\toptimization (smaller transducer, longer creation),\n"
       << "-F char\tfiller (to align entries)\n\t[default: '_'],\n"
       << "-I char\tinput separator (separates surface, lexical "
       << "and annotations in input)\n\t[default: '\\t'],\n"
       << "-S char\tannotation separator (separates lexical form "
       << "and annotations in output)\n\t[default: '+'].\n"
       << "-i input_file\tinput file name\n\t[default: standard input]\n"
       << "-o output_file\toutput file name\n\t[default: standard output]\n"
       << "-v\t- version details\n"
       << "Example:\n"
       << prog_name << " -O < input_data.txt > dict1.tr\n";
}//usage

/* Name:	main
 * Class:	None.
 * Purpose:	Launches the program.
 * Parameters:	argc	- (i) number of program arguments;
 *		argv	- (i) program arguments.
 * Returns:	0	- if OK;
 *		1	- if invalid options;
 *		2	- if transducer could not be built;
 *		3	- if transducer could not be written to a file;
 *		4	- if there is not enough memory to build the tranducer.
 * Remarks:	None.
 */
int
main(const int argc, const char *argv[])
{
  int		optimize = FALSE;
  const char *input_file_name = NULL;
  const char *output_file_name = NULL;

  FILLER = '_'; INPUT_SEPARATOR = '\t'; ANNOT_SEPARATOR = '+';
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "-O")) {
      optimize = TRUE;
    }
    else if (!strcmp(argv[i], "-F")) {
      FILLER = *(argv[++i]);
    }
    else if (!strcmp(argv[i], "-I")) {
      INPUT_SEPARATOR = *(argv[++i]);
    }
    else if (!strcmp(argv[i], "-S")) {
      ANNOT_SEPARATOR = *(argv[++i]);
    }
    else if (!strcmp(argv[i], "-i")) {
      if (input_file_name) {
	cerr << argv[0] << ": Multiple input files not supported" << endl;
	cerr << "Ignoring earlier input files" << endl;
      }
      if (++i < argc)
	input_file_name = argv[i];
      else {
	cerr << argv[0] << ": -i without file name" << endl;
	usage(argv[0]);
	return 1;
      }
    }
    else if (!strcmp(argv[i], "-o")) {
      if (output_file_name) {
	cerr << argv[0] << ": Multiple output files not supported" << endl;
	cerr << "Ignoring earlier output files" << endl;
      }
      if (++i < argc)
	output_file_name = argv[i];
      else {
	cerr << argv[0] << ": -o without file name" << endl;
	usage(argv[0]);
	return 1;
      }
    }
    else if (!strcmp(argv[i], "-v")) {
      cout << VERSION << endl;
#include "comp_options.h"
      return 0;
    }
    else {
      usage(argv[0]);
      return 1;
    }
  }

  set_new_handler(&not_enough_memory);

  transducer autom;
  if (input_file_name) {
    ifstream inpf(input_file_name);
    if (!inpf) {
      cerr << argv[0] << ": Could not open input file " << input_file_name
	   << endl;
      usage(argv[0]);
      exit(1);
    }
    if (!autom.build_fsa(inpf)) {
      cerr << argv[0] << ": Could not build the transducer" << endl;
      return 2;
    }
  }
  else if (!autom.build_fsa(cin)) {
    cerr << argv[0] << ": Could not build the transducer\n";
    return 2;
  }

  if (optimize) {
#ifdef PROGRESS
    cerr << "Optimization" << endl;
#endif
    share_arcs(autom.get_root());
  }

#ifdef MONITOR_MEMORY
  cerr << "Transducer size: " << tr_memory
       << ", index size: " << idx_memory_all << endl;
#endif

  if (output_file_name) {
    ofstream outf(output_file_name);
    if (!outf) {
      cerr << argv[0] << ": Could not create file " << output_file_name
           << endl;
      usage(argv[0]);
      return 1;
    }
    if (autom.write_fsa(outf))
      return 0;         // OK
  }
  else if (autom.write_fsa(cout))
    return 0;		// OK

  cerr << argv[0] << ": Could not write the transducer\n";
  return 3;
}//main
