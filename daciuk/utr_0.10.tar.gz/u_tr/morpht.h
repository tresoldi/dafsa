/***	morpht.h	***/

/*	Copyright (c) Jan Daciuk, 1997	*/


/* Class name:	morph_tr
 * Purpose:	Provide an environment for programs using transducers
 *		to do morphological analysis or something that can use
 *		the same mechanism (pronunciation etc.).
 * Remarks:
 */
class morph_tr : public tr {
protected:
  int rest_of_word_morphology(const int depth, tr_arc_ptr start);
public:
  morph_tr(word_list *dict_names, const char *language_file = NULL);
  ~morph_tr(void) {};
  int word_morphology(const char *word, const int depth,
		      const tr_arc_ptr start);
  int morph_file(tr_io &io_obj);
  int morph_word(const char *word);
  int gen_words_from_file(tr_io &io_obj, const char ext_a_sep);
  int gen_word(const char *lextag, const char ext_a_sep);
  int gen_word_char(const char *lextag, const int depth, tr_arc_ptr start);
};/*class morph_tr*/


/***	EOF morpht.h	***/
